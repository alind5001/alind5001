// Generates supabase/seed.sql from the launch content in src/lib/content.
// Run: npm run seed:generate
import { writeFileSync } from "node:fs";
import { SEED_PROJECTS } from "../src/lib/content/brands";
import { SEED_POSTS, BLOG_CATEGORIES } from "../src/lib/content/posts";

const q = (v: unknown) => (v === null || v === undefined ? "null" : `'${String(v).replace(/'/g, "''")}'`);
const arr = (a: string[]) => `array[${a.map(q).join(",")}]::text[]`;
const js = (v: unknown) => `${q(JSON.stringify(v))}::jsonb`;

let sql = `-- Launch content for Inboxora Digital. Safe to re-run: existing rows are left untouched.\n\n`;

sql += `insert into public.blog_categories (name, slug) values\n${BLOG_CATEGORIES.map((c) => `  (${q(c.name)}, ${q(c.slug)})`).join(",\n")}\non conflict (slug) do nothing;\n\n`;

for (const p of SEED_PROJECTS) {
  sql += `insert into public.portfolio_projects (slug, brand_name, website, industry, country, description, services, categories, images, verified_results, case_study, attribution, publication_status, sort_order)
values (${q(p.slug)}, ${q(p.brand_name)}, ${q(p.website)}, ${q(p.industry)}, ${q(p.country)}, ${q(p.description)}, ${arr(p.services)}, ${arr(p.categories)}, '[]'::jsonb, null, ${js(p.case_study)}, ${q(p.attribution)}, 'published', ${p.sort_order})
on conflict (slug) do nothing;\n\n`;
}

for (const p of SEED_POSTS) {
  sql += `insert into public.blog_posts (title, slug, excerpt, content, category, author, featured, meta_description, publication_status, published_at)
values (${q(p.title)}, ${q(p.slug)}, ${q(p.excerpt)}, ${q(p.content)}, ${q(p.category)}, ${q(p.author)}, ${p.featured}, ${q(p.meta_description)}, 'published', ${q(p.published_at)})
on conflict (slug) do nothing;\n\n`;
}

writeFileSync(new URL("../supabase/seed.sql", import.meta.url), sql);
console.log(`Wrote supabase/seed.sql (${SEED_PROJECTS.length} projects, ${SEED_POSTS.length} posts, ${BLOG_CATEGORIES.length} categories)`);
