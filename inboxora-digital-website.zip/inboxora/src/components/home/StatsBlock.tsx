import type { StatsSettings } from "@/lib/types";

export function StatsBlock({ stats, dark = true }: { stats: StatsSettings; dark?: boolean }) {
  return (
    <div>
      <dl className={`grid gap-px overflow-hidden rounded-[var(--radius-card)] md:grid-cols-3 ${dark ? "bg-white/10" : "bg-line"}`}>
        {stats.items.map((s) => (
          <div key={s.label} className={`p-7 md:p-9 ${dark ? "bg-navy" : "bg-white"}`}>
            <dt className="sr-only">{s.label}</dt>
            <dd>
              <span className={`block font-display text-[clamp(2.75rem,6vw,4.5rem)] font-extrabold leading-none tracking-[-0.05em] ${dark ? "text-white" : "text-navy"}`}>
                {s.value}
              </span>
              <span className={`mt-4 block font-semibold ${dark ? "text-white" : "text-ink"}`}>{s.label}</span>
              <span className={`mt-1.5 block text-[0.92rem] leading-relaxed ${dark ? "text-white/60" : "text-muted"}`}>{s.detail}</span>
            </dd>
          </div>
        ))}
      </dl>
      <p className={`mt-8 max-w-3xl text-lg leading-relaxed ${dark ? "text-white/80" : "text-ink/80"}`}>{stats.summary}</p>
      <p className={`mt-4 max-w-3xl border-l-2 pl-4 text-sm leading-relaxed ${dark ? "border-violet text-white/55" : "border-violet text-muted"}`}>
        <strong className={dark ? "text-white/75" : "text-ink"}>Methodology: </strong>
        {stats.disclosure}
      </p>
    </div>
  );
}
