import { EmailMockup } from "@/components/ui/EmailMockup";

// ly = label baseline offset from the node; labels sit on the side away from the path.
const nodes = [
  { x: 40, y: 200, ly: 36, anchor: "start", lx: -18, label: "First click", sub: "Signup form" },
  { x: 150, y: 120, ly: -42, anchor: "middle", lx: 0, label: "Welcome", sub: "3-email series" },
  { x: 265, y: 175, ly: 36, anchor: "middle", lx: 0, label: "Browse", sub: "Product interest" },
  { x: 370, y: 95, ly: 36, anchor: "middle", lx: 0, label: "First order", sub: "Post-purchase" },
  { x: 470, y: 40, ly: 36, anchor: "end", lx: 30, label: "Repeat purchase", sub: "Replenish + winback" },
] as const;

/** Illustrative dashboard: a lifecycle journey and campaign activity. Contains no performance figures. */
export function HeroVisual() {
  return (
    <div className="relative mx-auto w-full max-w-[36rem] lg:max-w-none" aria-label="Illustration of an email lifecycle journey dashboard" role="img">
      <div className="relative">
      <div className="relative rounded-[var(--radius-panel)] bg-navy p-4 text-white shadow-[var(--shadow-lift)] sm:p-6">
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5" aria-hidden>
            <span className="size-2.5 rounded-full bg-white/20" />
            <span className="size-2.5 rounded-full bg-white/20" />
            <span className="size-2.5 rounded-full bg-white/20" />
          </div>
          <span className="rounded-full bg-white/10 px-2.5 py-1 text-[0.68rem] text-white/70">Lifecycle journey</span>
        </div>

        <svg viewBox="0 0 520 260" className="mt-3 w-full" aria-hidden>
          <defs>
            <linearGradient id="hero-line" x1="0" x2="1">
              <stop offset="0" stopColor="#3B82F6" />
              <stop offset="1" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>
          {[60, 120, 180, 240].map((y) => (
            <line key={y} x1="0" x2="520" y1={y} y2={y} stroke="white" strokeOpacity=".06" />
          ))}
          <path
            className="hero-path"
            d="M40 200 C 90 200, 100 120, 150 120 S 220 175, 265 175 S 330 95, 370 95 S 430 40, 470 40"
            fill="none"
            stroke="url(#hero-line)"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {nodes.map((n, i) => (
            <g key={n.label} className="hero-node" style={{ animationDelay: `${0.5 + i * 0.35}s` }}>
              <circle cx={n.x} cy={n.y} r="14" fill="#172554" stroke={i === nodes.length - 1 ? "#8B5CF6" : "#3B82F6"} strokeWidth="2.5" />
              <circle cx={n.x} cy={n.y} r="4.5" fill="white" />
              <text x={n.x + n.lx} y={n.y + n.ly} textAnchor={n.anchor} fill="white" fontSize="12.5" fontWeight="700" fontFamily="Manrope Variable, sans-serif">
                {n.label}
              </text>
              <text x={n.x + n.lx} y={n.y + n.ly + 14} textAnchor={n.anchor} fill="white" fillOpacity=".5" fontSize="10.5" fontFamily="Inter Variable, sans-serif">
                {n.sub}
              </text>
            </g>
          ))}
        </svg>

        <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3">
          <div className="col-span-2 rounded-xl bg-white/[0.06] p-3.5">
            <p className="text-[0.7rem] text-white/60">Campaign activity</p>
            <div className="mt-3 flex h-14 items-end gap-1.5" aria-hidden>
              {[38, 52, 44, 70, 58, 82, 64, 90, 76, 96, 72, 88].map((h, i) => (
                <span key={i} className="flex-1 rounded-sm bg-gradient-to-t from-blue/70 to-violet/80" style={{ height: `${h}%`, opacity: 0.45 + i * 0.045 }} />
              ))}
            </div>
          </div>
          <div className="hidden rounded-xl bg-white/[0.06] p-3.5 sm:block">
            <p className="text-[0.7rem] text-white/60">Active flows</p>
            <ul className="mt-2.5 space-y-1.5 text-[0.72rem]">
              {["Welcome", "Cart", "Post-purchase", "Winback"].map((f) => (
                <li key={f} className="flex items-center gap-1.5 text-white/85">
                  <span className="size-1.5 rounded-full bg-emerald-400" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div aria-hidden className="absolute right-6 top-full hidden w-32 -translate-y-14 rotate-[4deg] md:block">
        <EmailMockup variant="promo" compact showLabel={false} />
      </div>
      <div aria-hidden className="absolute left-12 top-full hidden w-32 -translate-y-20 -rotate-[5deg] md:block">
        <EmailMockup variant="newsletter" compact showLabel={false} />
      </div>
      </div>
      <p className="mt-4 text-center text-xs text-muted md:mt-64">Illustrative dashboard. No real client data shown.</p>
    </div>
  );
}
