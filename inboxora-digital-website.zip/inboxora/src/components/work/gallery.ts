export type GalleryItem =
  | { kind: "image"; url: string; caption: string; concept: boolean }
  | { kind: "concept"; category: string; caption: string };

export function galleryFor(
  images: { url: string; caption: string; category: string; concept: boolean }[],
  categories: string[],
  brand: string
): GalleryItem[] {
  if (images.length) return images.map((i) => ({ kind: "image", url: i.url, caption: i.caption || `${brand}: ${i.category}`, concept: i.concept }));
  return categories.map((c) => ({ kind: "concept", category: c, caption: `${c}: illustrative concept` }));
}
