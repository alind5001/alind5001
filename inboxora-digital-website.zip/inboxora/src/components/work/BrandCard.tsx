import Link from "next/link";
import { Icon } from "@/components/ui/Icon";
import type { PortfolioProject } from "@/lib/types";

const COUNTRY_TINT: Record<string, string> = {
  USA: "from-blue/12 to-violet/8",
  Australia: "from-emerald-500/10 to-blue/8",
  UAE: "from-amber-500/12 to-violet/8",
};

export function BrandCard({ project }: { project: PortfolioProject }) {
  const cover = project.images.find((i) => !i.concept) ?? null;
  return (
    <article className="flex flex-col overflow-hidden rounded-[var(--radius-card)] border border-line bg-white">
      <div className={`relative flex h-36 items-end bg-gradient-to-br p-5 ${COUNTRY_TINT[project.country] ?? "from-blue/10 to-violet/10"}`}>
        {cover && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={cover.url} alt={cover.caption || `${project.brand_name} email work`} className="absolute inset-0 size-full object-cover" loading="lazy" />
        )}
        <div className="relative flex flex-wrap gap-1.5">
          <span className="rounded-full bg-white/90 px-2.5 py-1 text-xs font-medium text-ink">{project.industry}</span>
          <span className="rounded-full bg-white/90 px-2.5 py-1 text-xs font-medium text-ink">{project.country}</span>
        </div>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-display text-xl font-bold tracking-tight">{project.brand_name}</h3>
        <ul className="mt-4 flex flex-wrap gap-1.5">
          {project.services.map((s) => (
            <li key={s} className="rounded-md bg-mist px-2 py-1 text-[0.78rem] text-ink/80">{s}</li>
          ))}
        </ul>
        <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-6">
          <Link href={`/work/${project.slug}`} className="btn btn-dark !px-4 !py-2.5 text-sm">View Experience</Link>
          <a href={project.website} target="_blank" rel="noopener noreferrer nofollow" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-navy">
            Visit website <Icon name="external" className="size-4" />
            <span className="sr-only">(opens in a new tab)</span>
          </a>
        </div>
      </div>
    </article>
  );
}
