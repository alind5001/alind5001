"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { EmailMockup, CATEGORY_VARIANT } from "@/components/ui/EmailMockup";
import { Icon } from "@/components/ui/Icon";
import { Lightbox } from "@/components/work/Lightbox";
import { galleryFor, type GalleryItem } from "@/components/work/gallery";
import type { PortfolioProject } from "@/lib/types";

export function PortfolioGrid({ projects, categories }: { projects: PortfolioProject[]; categories: string[] }) {
  const [active, setActive] = useState<string>("All");
  const [q, setQ] = useState("");
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [index, setIndex] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return projects.filter((p) => {
      const inCat = active === "All" || p.categories.includes(active);
      const hay = [p.brand_name, p.industry, p.country, p.description, ...p.services, ...p.categories].join(" ").toLowerCase();
      return inCat && (!needle || hay.includes(needle));
    });
  }, [projects, active, q]);

  return (
    <div>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div role="group" aria-label="Filter by category" className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] lg:flex-wrap">
          {["All", ...categories].map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={active === c}
              onClick={() => setActive(c)}
              className={`shrink-0 rounded-full px-3.5 py-2 text-sm font-medium transition-colors ${
                active === c ? "bg-navy text-white" : "border border-line bg-white text-muted hover:text-navy"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <label className="relative block w-full lg:w-72">
          <span className="sr-only">Search work</span>
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search brands, industries, work" className="field !rounded-full !pl-10" />
        </label>
      </div>

      <p className="mt-6 text-sm text-muted" aria-live="polite">
        Showing {filtered.length} of {projects.length} projects
      </p>

      {filtered.length === 0 ? (
        <div className="mt-6 rounded-[var(--radius-card)] border border-dashed border-line bg-white p-12 text-center">
          <p className="font-display text-lg font-bold">No projects match that filter.</p>
          <button type="button" className="btn btn-ghost mt-4" onClick={() => { setActive("All"); setQ(""); }}>Clear filters</button>
        </div>
      ) : (
        <ul className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => {
            const items = galleryFor(p.images, p.categories, p.brand_name);
            const first = p.images[0];
            const previewCat = active !== "All" ? active : p.categories[0];
            return (
              <li key={p.id} className="flex flex-col overflow-hidden rounded-[var(--radius-card)] border border-line bg-white">
                <button
                  type="button"
                  onClick={() => { setGallery(items); setIndex(0); }}
                  className="group relative block h-56 overflow-hidden bg-gradient-to-br from-blue/8 to-violet/10"
                  aria-label={`View ${items.length} image${items.length === 1 ? "" : "s"} for ${p.brand_name}`}
                >
                  {first ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={first.url} alt={first.caption || p.brand_name} loading="lazy" className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                  ) : (
                    <div className="absolute inset-x-0 top-5 mx-auto w-44 transition-transform duration-300 group-hover:-translate-y-1">
                      <EmailMockup variant={CATEGORY_VARIANT[previewCat] ?? "promo"} compact />
                    </div>
                  )}
                  <span className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 rounded-full bg-white/95 px-2.5 py-1 text-xs font-medium text-ink shadow-sm">
                    <Icon name="image" className="size-3.5" /> {items.length}
                  </span>
                </button>
                <div className="flex flex-1 flex-col p-6">
                  <p className="text-sm text-muted">{p.industry}, {p.country}</p>
                  <h2 className="mt-1 font-display text-xl font-bold tracking-tight">{p.brand_name}</h2>
                  <ul className="mt-3 flex flex-wrap gap-1.5">
                    {p.categories.map((c) => (
                      <li key={c} className="rounded-md bg-mist px-2 py-1 text-[0.78rem] text-ink/80">{c}</li>
                    ))}
                  </ul>
                  <div className="mt-auto flex items-center justify-between gap-3 pt-6">
                    <Link href={`/work/${p.slug}`} className="btn btn-dark !px-4 !py-2.5 text-sm">View Experience</Link>
                    <a href={p.website} target="_blank" rel="noopener noreferrer nofollow" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-navy">
                      Website <Icon name="external" className="size-4" /><span className="sr-only">(opens in a new tab)</span>
                    </a>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <Lightbox items={gallery} index={index} onIndex={setIndex} onClose={() => setIndex(null)} />
    </div>
  );
}
