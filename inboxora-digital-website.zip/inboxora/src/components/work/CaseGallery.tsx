"use client";

import { useState } from "react";
import { EmailMockup, CATEGORY_VARIANT } from "@/components/ui/EmailMockup";
import { Lightbox } from "@/components/work/Lightbox";
import type { GalleryItem } from "@/components/work/gallery";

export function CaseGallery({ items }: { items: GalleryItem[] }) {
  const [index, setIndex] = useState<number | null>(null);
  return (
    <>
      <ul className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {items.map((it, i) => (
          <li key={i}>
            <button type="button" onClick={() => setIndex(i)} className="group block w-full text-left" aria-label={`Open ${it.caption}`}>
              <div className="grid h-60 place-items-center overflow-hidden rounded-[var(--radius-card)] border border-line bg-gradient-to-br from-blue/6 to-violet/10 p-4">
                {it.kind === "image" ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={it.url} alt={it.caption} loading="lazy" className="max-h-full w-auto rounded-md object-contain transition-transform group-hover:scale-[1.02]" />
                ) : (
                  <EmailMockup variant={CATEGORY_VARIANT[it.category] ?? "promo"} compact className="w-40" />
                )}
              </div>
              <p className="mt-2 text-sm text-muted">{it.caption}</p>
            </button>
          </li>
        ))}
      </ul>
      <Lightbox items={items} index={index} onIndex={setIndex} onClose={() => setIndex(null)} />
    </>
  );
}
