"use client";

import { useCallback, useEffect, useRef } from "react";
import { EmailMockup, CATEGORY_VARIANT } from "@/components/ui/EmailMockup";
import { Icon } from "@/components/ui/Icon";

import type { GalleryItem } from "./gallery";
export type { GalleryItem };

export function Lightbox({
  items,
  index,
  onClose,
  onIndex,
}: {
  items: GalleryItem[];
  index: number | null;
  onClose: () => void;
  onIndex: (i: number) => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const open = index !== null;

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  const step = useCallback(
    (dir: 1 | -1) => {
      if (index === null) return;
      onIndex((index + dir + items.length) % items.length);
    },
    [index, items.length, onIndex]
  );

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, step]);

  const item = index !== null ? items[index] : null;

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => e.target === ref.current && onClose()}
      className="m-auto max-h-[92vh] w-[min(56rem,94vw)] rounded-[var(--radius-card)] bg-white p-0 backdrop:bg-navy/80 backdrop:backdrop-blur-sm"
      aria-label="Image viewer"
    >
      {item && (
        <div className="flex max-h-[92vh] flex-col">
          <div className="flex items-center justify-between gap-4 border-b border-line px-5 py-3">
            <p className="truncate text-sm font-medium">
              {item.caption}
              {(item.kind === "concept" || item.concept) && (
                <span className="ml-2 rounded-full bg-navy px-2 py-0.5 text-[0.7rem] font-medium text-white">Concept design</span>
              )}
            </p>
            <button type="button" onClick={onClose} className="grid size-9 place-items-center rounded-full hover:bg-mist" aria-label="Close viewer">
              <Icon name="close" />
            </button>
          </div>
          <div className="relative grid min-h-0 flex-1 place-items-center overflow-auto bg-mist p-6">
            {item.kind === "image" ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={item.url} alt={item.caption} className="max-h-[72vh] w-auto rounded-lg object-contain" />
            ) : (
              <EmailMockup variant={CATEGORY_VARIANT[item.category] ?? "promo"} className="w-full max-w-xs" />
            )}
          </div>
          {items.length > 1 && (
            <div className="flex items-center justify-between border-t border-line px-5 py-3 text-sm">
              <button type="button" className="btn btn-ghost !py-2" onClick={() => step(-1)}>Previous</button>
              <span className="text-muted">{(index ?? 0) + 1} of {items.length}</span>
              <button type="button" className="btn btn-ghost !py-2" onClick={() => step(1)}>Next</button>
            </div>
          )}
        </div>
      )}
    </dialog>
  );
}

