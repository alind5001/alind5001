"use client";

import { useRef, useState } from "react";
import { uploadImage } from "@/app/admin/actions";

export function ImageUpload({ folder, onUploaded, label = "Upload image" }: { folder: string; onUploaded: (url: string) => void; label?: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  return (
    <div>
      <input
        ref={ref}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="sr-only"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          setErr("");
          if (file.size > 5 * 1024 * 1024) { setErr("Images must be 5 MB or smaller."); return; }
          setBusy(true);
          const fd = new FormData();
          fd.set("file", file);
          fd.set("folder", folder);
          const r = await uploadImage(fd);
          setBusy(false);
          if (ref.current) ref.current.value = "";
          if (r.ok) onUploaded(r.url); else setErr(r.error);
        }}
      />
      <button type="button" className="btn btn-ghost !py-2 text-sm" disabled={busy} onClick={() => ref.current?.click()}>
        {busy ? "Uploading…" : label}
      </button>
      <p className="mt-1.5 text-xs text-muted">PNG, JPEG, WebP or GIF, up to 5 MB.</p>
      {err && <p role="alert" className="mt-1 text-sm text-red-700">{err}</p>}
    </div>
  );
}
