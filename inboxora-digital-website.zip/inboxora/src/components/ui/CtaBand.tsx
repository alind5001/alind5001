import Link from "next/link";

export function CtaBand({
  title = "Your Customers Are Already There. Let's Build Better Conversations.",
  copy = "Let's create an email marketing strategy that keeps your brand connected with customers and supports sustainable business growth.",
  primary = { href: "/free-email-audit", label: "Get Your Free Email Audit" },
  secondary = { href: "/book-a-call", label: "Book a Discovery Call" },
}: {
  title?: string;
  copy?: string;
  primary?: { href: string; label: string };
  secondary?: { href: string; label: string };
}) {
  return (
    <section className="container-x py-20 md:py-28">
      <div className="relative overflow-hidden rounded-[var(--radius-panel)] bg-navy px-6 py-14 text-white md:px-14 md:py-20">
        <div aria-hidden className="absolute inset-0 bg-[radial-gradient(60%_80%_at_100%_0%,rgb(139_92_246/0.45),transparent_60%),radial-gradient(50%_70%_at_0%_100%,rgb(59_130_246/0.35),transparent_60%)]" />
        <div aria-hidden className="absolute inset-0 opacity-[0.07] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:44px_44px]" />
        <div className="relative max-w-3xl">
          <h2 className="display-lg">{title}</h2>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-white/70">{copy}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href={primary.href} className="btn btn-primary">{primary.label}</Link>
            <Link href={secondary.href} className="btn btn-on-dark">{secondary.label}</Link>
          </div>
        </div>
      </div>
    </section>
  );
}
