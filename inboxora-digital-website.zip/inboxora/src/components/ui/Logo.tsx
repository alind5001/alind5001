import Link from "next/link";

export function LogoMark({ className = "size-8" }: { className?: string }) {
  // Original mark: an envelope flap folding into an upward path.
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="ibx-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3B82F6" />
          <stop offset="1" stopColor="#8B5CF6" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#ibx-g)" />
      <path d="M10 14.5 20 22l10-7.5" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M10 26.5h8.5L30 15" fill="none" stroke="#fff" strokeOpacity=".55" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <Link href="/" className="flex shrink-0 items-center gap-2.5 whitespace-nowrap" aria-label="Inboxora Digital home">
      <LogoMark />
      <span className={`font-display text-[1.02rem] font-extrabold tracking-[0.08em] ${dark ? "text-white" : "text-navy"}`}>
        INBOXORA <span className={dark ? "text-white/60" : "text-muted"}>DIGITAL</span>
      </span>
    </Link>
  );
}
