import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

// Raw HTML in markdown is ignored (react-markdown default), so admin content cannot inject scripts.
export function Markdown({ children }: { children: string }) {
  return (
    <div className="prose-article">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href = "", children }) => {
            const external = /^https?:\/\//.test(href);
            return (
              <a href={href} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{children}</a>
            );
          },
          table: ({ children }) => <div className="overflow-x-auto"><table>{children}</table></div>,
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
