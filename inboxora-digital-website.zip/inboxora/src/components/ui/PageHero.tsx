import Link from "next/link";

type Crumb = { href: string; label: string };

export function PageHero({
  title,
  lede,
  crumbs,
  children,
  aside,
}: {
  title: string;
  lede?: string;
  crumbs?: Crumb[];
  children?: React.ReactNode;
  aside?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-line bg-white">
      <div aria-hidden className="pointer-events-none absolute -right-40 -top-40 size-[34rem] rounded-full bg-[radial-gradient(closest-side,rgb(139_92_246/0.13),transparent)]" />
      <div className="container-x relative grid gap-10 py-16 md:py-24 lg:grid-cols-12 lg:items-end">
        <div className={aside ? "lg:col-span-7" : "lg:col-span-9"}>
          {crumbs && (
            <nav aria-label="Breadcrumb" className="mb-6 text-sm text-muted">
              <ol className="flex flex-wrap items-center gap-1.5">
                <li><Link href="/" className="hover:text-navy">Home</Link></li>
                {crumbs.map((c) => (
                  <li key={c.href} className="flex items-center gap-1.5">
                    <span aria-hidden>/</span>
                    <Link href={c.href} className="hover:text-navy">{c.label}</Link>
                  </li>
                ))}
              </ol>
            </nav>
          )}
          <h1 className="display-xl">{title}</h1>
          {lede && <p className="lede mt-6">{lede}</p>}
          {children && <div className="mt-8 flex flex-wrap gap-3">{children}</div>}
        </div>
        {aside && <div className="lg:col-span-5">{aside}</div>}
      </div>
    </section>
  );
}
