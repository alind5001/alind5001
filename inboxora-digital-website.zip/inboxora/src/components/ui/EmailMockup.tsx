type Variant = "promo" | "newsletter" | "welcome" | "cart" | "launch" | "seasonal";

const themes: Record<Variant, { tint: string; ink: string; subject: string; headline: string; cta: string }> = {
  promo: { tint: "#EEF2FF", ink: "#3B82F6", subject: "A little something for the weekend", headline: "The weekend edit", cta: "Shop the edit" },
  newsletter: { tint: "#F5F3FF", ink: "#8B5CF6", subject: "This month: new ideas and old favourites", headline: "Notes from the studio", cta: "Read more" },
  welcome: { tint: "#ECFDF5", ink: "#059669", subject: "Welcome, we're glad you're here", headline: "Welcome to the family", cta: "Find your first favourite" },
  cart: { tint: "#FFF7ED", ink: "#EA580C", subject: "You left something behind", headline: "Still thinking it over?", cta: "Return to your cart" },
  launch: { tint: "#EFF6FF", ink: "#172554", subject: "Just landed: the new collection", headline: "Meet the new collection", cta: "Explore the collection" },
  seasonal: { tint: "#FDF2F8", ink: "#BE185D", subject: "Gifts they'll actually love", headline: "The gifting guide", cta: "Find the perfect gift" },
};

export const CATEGORY_VARIANT: Record<string, Variant> = {
  "Promotional Campaigns": "promo",
  "Welcome Emails": "welcome",
  "Abandoned Cart": "cart",
  "Browse Abandonment": "cart",
  "Product Launches": "launch",
  Newsletters: "newsletter",
  "Seasonal Campaigns": "seasonal",
  "Email Automation": "welcome",
};

/**
 * Concept email illustration. Uses a neutral placeholder brand — never a client's
 * name, logo or real campaign — and always carries a visible "Concept design" label.
 */
export function EmailMockup({
  variant = "promo",
  className = "",
  showLabel = true,
  compact = false,
}: {
  variant?: Variant;
  className?: string;
  showLabel?: boolean;
  compact?: boolean;
}) {
  const t = themes[variant];
  return (
    <figure
      className={`relative overflow-hidden rounded-[1rem] border border-line bg-white shadow-[var(--shadow-float)] ${className}`}
      aria-label={`Concept email design: ${t.headline}`}
    >
      <div className="flex items-center gap-2 border-b border-line px-3.5 py-2.5">
        <span className="size-6 shrink-0 rounded-full" style={{ background: t.tint, boxShadow: `inset 0 0 0 1.5px ${t.ink}33` }} />
        <div className="min-w-0 text-[0.68rem] leading-tight">
          <p className="font-semibold text-ink">Your Brand</p>
          <p className="truncate text-muted">{t.subject}</p>
        </div>
      </div>
      <div className="p-3.5">
        <div className="relative grid place-items-center overflow-hidden rounded-lg" style={{ background: t.tint, height: compact ? 74 : 110 }}>
          <svg viewBox="0 0 120 60" className="h-3/4 w-auto" aria-hidden>
            <circle cx="40" cy="32" r="18" fill={t.ink} fillOpacity=".14" />
            <rect x="58" y="16" width="34" height="34" rx="8" fill={t.ink} fillOpacity=".22" />
            <path d="M22 50h76" stroke={t.ink} strokeOpacity=".25" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
        <p className="mt-3 font-display text-[0.95rem] font-bold tracking-tight text-ink">{t.headline}</p>
        <div className="mt-2 space-y-1.5" aria-hidden>
          <div className="h-1.5 w-full rounded-full bg-line" />
          <div className="h-1.5 w-4/5 rounded-full bg-line" />
          {!compact && <div className="h-1.5 w-3/5 rounded-full bg-line" />}
        </div>
        {!compact && (
          <div className="mt-3 grid grid-cols-3 gap-1.5" aria-hidden>
            {[0, 1, 2].map((i) => (
              <div key={i} className="aspect-square rounded-md" style={{ background: t.tint }} />
            ))}
          </div>
        )}
        <div className="mt-3 inline-flex rounded-md px-3 py-1.5 text-[0.65rem] font-semibold text-white" style={{ background: t.ink }}>
          {t.cta}
        </div>
      </div>
      {showLabel && (
        <figcaption className="absolute right-2 top-2 rounded-full bg-navy/80 px-2 py-0.5 text-[0.6rem] font-medium text-white backdrop-blur">
          Concept design
        </figcaption>
      )}
    </figure>
  );
}
