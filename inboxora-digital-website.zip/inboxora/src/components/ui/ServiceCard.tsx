import Link from "next/link";
import { Icon, type IconName } from "@/components/ui/Icon";
import type { ServiceSummary } from "@/lib/types";

export const SERVICE_ICONS: Record<string, IconName> = {
  "email-campaign-management": "mail",
  "email-automation": "flow",
  "email-design-development": "pen",
  "email-marketing-strategy": "compass",
  "segmentation-personalisation": "users",
  "deliverability-list-management": "shield",
  "analytics-performance-reporting": "chart",
};

export function ServiceCard({ service }: { service: ServiceSummary }) {
  return (
    <article className="group flex flex-col rounded-[var(--radius-card)] border border-line bg-white p-6 transition-shadow hover:shadow-[var(--shadow-float)] md:p-7">
      <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-blue/10 to-violet/15 text-blue">
        <Icon name={SERVICE_ICONS[service.slug] ?? "spark"} className="size-[1.35rem]" />
      </span>
      <h3 className="mt-5 font-display text-xl font-bold tracking-tight">{service.shortTitle}</h3>
      <p className="mt-2 text-[0.95rem] leading-relaxed text-muted">{service.summary}</p>
      <ul className="mt-5 grid gap-2 text-[0.9rem] text-ink/85">
        {service.bullets.map((b) => (
          <li key={b} className="flex gap-2.5">
            <Icon name="check" className="mt-0.5 size-4 shrink-0 text-violet" />
            {b}
          </li>
        ))}
      </ul>
      <div className="mt-auto pt-7">
        <Link
          href={`/services/${service.slug}`}
          className="inline-flex items-center gap-1.5 text-[0.92rem] font-semibold text-blue hover:text-navy"
          aria-label={`Learn more about ${service.title}`}
        >
          Learn More
        </Link>
      </div>
    </article>
  );
}
