"use client";

import { useCallback, useRef, useState } from "react";

export type SubmitState = "idle" | "submitting" | "success" | "error";

export function useFormSubmit(endpoint: string) {
  const [state, setState] = useState<SubmitState>("idle");
  const [error, setError] = useState<string>("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [token, setToken] = useState("");
  const [resetKey, setResetKey] = useState(0);
  const startedAt = useRef<number>(Date.now());
  const inFlight = useRef(false);

  const submit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>, extra: Record<string, unknown> = {}) => {
      e.preventDefault();
      if (inFlight.current) return; // prevents double submits
      const form = e.currentTarget;
      const fd = new FormData(form);
      const body: Record<string, unknown> = {};
      fd.forEach((v, k) => (body[k] = typeof v === "string" ? v : ""));
      body.marketing_consent = fd.get("marketing_consent") === "on";
      body.started_at = startedAt.current;
      body.turnstile_token = token;
      Object.assign(body, extra);

      inFlight.current = true;
      setState("submitting");
      setError("");
      setFieldErrors({});
      try {
        const res = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        const data = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string; fieldErrors?: Record<string, string> };
        if (res.ok && data.ok) {
          setState("success");
          form.reset();
          window.scrollTo({ top: Math.max(0, form.getBoundingClientRect().top + window.scrollY - 120), behavior: "smooth" });
        } else {
          setState("error");
          setError(data.error || "Something went wrong. Please try again.");
          setFieldErrors(data.fieldErrors || {});
          setResetKey((k) => k + 1);
          const first = data.fieldErrors && Object.keys(data.fieldErrors)[0];
          if (first) (form.elements.namedItem(first) as HTMLElement | null)?.focus();
        }
      } catch {
        setState("error");
        setError("We couldn't reach the server. Check your connection and try again.");
      } finally {
        inFlight.current = false;
      }
    },
    [endpoint, token]
  );

  return { state, error, fieldErrors, submit, setToken, resetKey };
}
