"use client";

import { Icon } from "@/components/ui/Icon";

export function FormError({ message }: { message: string }) {
  if (!message) return null;
  return (
    <div role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">{message}</div>
  );
}

export function FormSuccess({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div role="status" className="rounded-[var(--radius-card)] border border-emerald-200 bg-emerald-50/70 p-8">
      <span className="grid size-11 place-items-center rounded-full bg-emerald-600 text-white"><Icon name="check" /></span>
      <h2 className="mt-5 font-display text-2xl font-bold tracking-tight">{title}</h2>
      <div className="mt-3 space-y-2 leading-relaxed text-ink/80">{children}</div>
    </div>
  );
}
