"use client";

import Link from "next/link";
import { Field, Honeypot, MarketingConsent, SelectField, TextArea, Turnstile } from "./fields";
import { FormError, FormSuccess } from "./FormStatus";
import { useFormSubmit } from "./useFormSubmit";
import { COUNTRIES, INDUSTRY_OPTIONS, PLATFORM_OPTIONS, SUBSCRIBER_OPTIONS } from "@/lib/content/site";

export function AuditForm() {
  const { state, error, fieldErrors: fe, submit, setToken, resetKey } = useFormSubmit("/api/audit");

  if (state === "success") {
    return (
      <FormSuccess title="Your audit request is in.">
        <p>We&apos;ll review your setup and get back to you within two business days. Check your inbox for a confirmation.</p>
        <p>In the meantime, you can <Link href="/work" className="font-semibold text-blue underline underline-offset-2">explore our work</Link> or <Link href="/book-a-call" className="font-semibold text-blue underline underline-offset-2">book a discovery call</Link>.</p>
      </FormSuccess>
    );
  }

  return (
    <form onSubmit={(e) => submit(e)} noValidate className="relative grid gap-5 sm:grid-cols-2">
      <Honeypot />
      <Field label="Full Name" name="name" required autoComplete="name" error={fe.name} />
      <Field label="Business Email" name="email" type="email" required autoComplete="email" error={fe.email} />
      <Field label="Company Name" name="company" required autoComplete="organization" error={fe.company} />
      <Field label="Website URL" name="website" required inputMode="url" placeholder="yourstore.com" autoComplete="url" error={fe.website} />
      <SelectField label="Country" name="country" required options={COUNTRIES} error={fe.country} />
      <SelectField label="Industry" name="industry" required options={INDUSTRY_OPTIONS} error={fe.industry} />
      <SelectField label="Current Email Marketing Platform" name="email_platform" required options={PLATFORM_OPTIONS} error={fe.email_platform} />
      <SelectField label="Approximate Subscriber Count" name="subscriber_count" required options={SUBSCRIBER_OPTIONS} error={fe.subscriber_count} />
      <TextArea label="Main Marketing Challenge" name="marketing_challenge" required rows={3} placeholder="For example: low repeat purchases, no automated flows, emails landing in spam." error={fe.marketing_challenge} className="sm:col-span-2" />
      <TextArea label="Additional Information" name="additional_information" required rows={4} placeholder="Anything else that would help: your goals, recent changes, what you've tried." error={fe.additional_information} className="sm:col-span-2" />
      <p className="rounded-xl bg-navy/[0.04] px-4 py-3 text-sm leading-relaxed text-ink/80 sm:col-span-2">
        <strong>We never ask for passwords.</strong> Please don&apos;t include login details or your customers&apos; personal data. If we need access later, we&apos;ll explain how to add us through your platform&apos;s own team settings.
      </p>
      <div className="sm:col-span-2"><MarketingConsent /></div>
      <div className="sm:col-span-2"><Turnstile onToken={setToken} resetKey={resetKey} /></div>
      <div className="sm:col-span-2"><FormError message={error} /></div>
      <div className="flex flex-col gap-3 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs leading-relaxed text-muted">By submitting, you agree to our <Link href="/legal/privacy" className="underline">Privacy Policy</Link>.</p>
        <button type="submit" className="btn btn-primary" disabled={state === "submitting"}>
          {state === "submitting" ? "Sending…" : "REQUEST MY FREE AUDIT"}
        </button>
      </div>
    </form>
  );
}
