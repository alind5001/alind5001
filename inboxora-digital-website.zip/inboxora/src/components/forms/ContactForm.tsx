"use client";

import Link from "next/link";
import { Field, Honeypot, MarketingConsent, SelectField, TextArea, Turnstile } from "./fields";
import { FormError, FormSuccess } from "./FormStatus";
import { useFormSubmit } from "./useFormSubmit";
import { BUDGET_OPTIONS, COUNTRIES } from "@/lib/content/site";

export function ContactForm({ services, plan }: { services: string[]; plan?: string }) {
  const { state, error, fieldErrors: fe, submit, setToken, resetKey } = useFormSubmit("/api/contact");

  if (state === "success") {
    return (
      <FormSuccess title="Thanks, your enquiry is with us.">
        <p>We&apos;ll reply within one business day. A confirmation has been sent to your inbox.</p>
        <p>Want to move faster? <Link href="/book-a-call" className="font-semibold text-blue underline underline-offset-2">Book a discovery call</Link>.</p>
      </FormSuccess>
    );
  }

  return (
    <form onSubmit={(e) => submit(e)} noValidate className="relative grid gap-5 sm:grid-cols-2">
      <Honeypot />
      <input type="hidden" name="plan" value={plan ?? ""} />
      <Field label="Full Name" name="name" required autoComplete="name" error={fe.name} />
      <Field label="Work Email" name="email" type="email" required autoComplete="email" error={fe.email} />
      <Field label="Company Name" name="company" required autoComplete="organization" error={fe.company} />
      <Field label="Website URL" name="website" inputMode="url" placeholder="yourstore.com" autoComplete="url" error={fe.website} />
      <SelectField label="Country" name="country" required options={COUNTRIES} error={fe.country} />
      <SelectField label="Service Interested In" name="service" required options={[...services, "Not sure yet"]} error={fe.service} />
      <SelectField label="Monthly Marketing Budget" name="budget" required options={BUDGET_OPTIONS} error={fe.budget} className="sm:col-span-2" />
      <TextArea label="Message" name="message" required placeholder="Tell us about your store, your goals and what you'd like help with." error={fe.message} className="sm:col-span-2" defaultValue={plan ? `I'm interested in the ${plan} package.\n\n` : undefined} />
      <div className="sm:col-span-2"><MarketingConsent /></div>
      <div className="sm:col-span-2"><Turnstile onToken={setToken} resetKey={resetKey} /></div>
      <div className="sm:col-span-2"><FormError message={error} /></div>
      <div className="flex flex-col gap-3 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs leading-relaxed text-muted">By sending, you agree to our <Link href="/legal/privacy" className="underline">Privacy Policy</Link>. We only use your details to reply.</p>
        <button type="submit" className="btn btn-primary" disabled={state === "submitting"}>
          {state === "submitting" ? "Sending…" : "SEND ENQUIRY"}
        </button>
      </div>
    </form>
  );
}
