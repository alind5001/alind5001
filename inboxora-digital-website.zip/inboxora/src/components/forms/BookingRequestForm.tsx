"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Field, Honeypot, MarketingConsent, SelectField, TextArea, Turnstile } from "./fields";
import { FormError, FormSuccess } from "./FormStatus";
import { useFormSubmit } from "./useFormSubmit";

const TIMES = ["Morning (9am–12pm)", "Afternoon (12pm–4pm)", "Evening (4pm–7pm)"];

/** Used when Calendly is not configured. Collects a preferred window; no availability is shown or implied. */
export function BookingRequestForm() {
  const { state, error, fieldErrors: fe, submit, setToken, resetKey } = useFormSubmit("/api/booking");
  const [tz, setTz] = useState("UTC");
  const zones = useMemo(() => {
    try {
      return (Intl as unknown as { supportedValuesOf: (k: string) => string[] }).supportedValuesOf("timeZone");
    } catch {
      return ["UTC", "Asia/Kolkata", "America/New_York", "America/Los_Angeles", "Europe/London", "Australia/Sydney", "Asia/Dubai"];
    }
  }, []);
  const [today, setToday] = useState("");
  useEffect(() => {
    setTz(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    setToday(new Date().toISOString().slice(0, 10));
  }, []);

  if (state === "success") {
    return (
      <FormSuccess title="Request received.">
        <p>This isn&apos;t a confirmed booking yet. We&apos;ll email you within one business day to confirm a time and send a calendar invitation.</p>
        <p>Prefer to chat now? <Link href="/contact" className="font-semibold text-blue underline underline-offset-2">See our contact options</Link>.</p>
      </FormSuccess>
    );
  }

  return (
    <form onSubmit={(e) => submit(e)} noValidate className="relative grid gap-5 sm:grid-cols-2">
      <Honeypot />
      <Field label="Full Name" name="name" required autoComplete="name" error={fe.name} />
      <Field label="Email" name="email" type="email" required autoComplete="email" error={fe.email} />
      <Field label="Company Name" name="company" required autoComplete="organization" error={fe.company} />
      <Field label="Website URL" name="website" required inputMode="url" placeholder="yourstore.com" error={fe.website} />
      <Field label="Preferred Date" name="preferred_date" type="date" required min={today || undefined} error={fe.preferred_date} />
      <SelectField label="Preferred Time" name="preferred_time" required options={TIMES} error={fe.preferred_time} />
      <div className="sm:col-span-2">
        <label htmlFor="tz" className="field-label">Your Time Zone<span className="text-violet"> *</span></label>
        <select id="tz" name="timezone" className="field" value={tz} onChange={(e) => setTz(e.target.value)} aria-invalid={Boolean(fe.timezone)}>
          {zones.map((z) => <option key={z} value={z}>{z.replace(/_/g, " ")}</option>)}
        </select>
        {fe.timezone && <p className="field-error">{fe.timezone}</p>}
      </div>
      <TextArea label="Business Requirements" name="requirements" required rows={4} placeholder="What would you like to cover on the call?" error={fe.requirements} className="sm:col-span-2" />
      <div className="sm:col-span-2"><MarketingConsent /></div>
      <div className="sm:col-span-2"><Turnstile onToken={setToken} resetKey={resetKey} /></div>
      <div className="sm:col-span-2"><FormError message={error} /></div>
      <div className="flex justify-end sm:col-span-2">
        <button type="submit" className="btn btn-primary" disabled={state === "submitting"}>
          {state === "submitting" ? "Sending…" : "Request a Call"}
        </button>
      </div>
    </form>
  );
}
