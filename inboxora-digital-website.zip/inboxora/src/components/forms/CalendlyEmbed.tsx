"use client";

import Script from "next/script";
import { useEffect, useState } from "react";
import { Icon } from "@/components/ui/Icon";

type CalMsg = { event?: string; payload?: { event?: { uri?: string }; invitee?: { uri?: string } } };

/**
 * Calendly inline embed. Calendly shows live availability, the visitor's time zone
 * and collects contact details, then emails its own confirmation. When a booking is
 * made we ask our server to verify it with Calendly's API and store it.
 */
export function CalendlyEmbed({ url }: { url: string }) {
  const [booked, setBooked] = useState(false);

  useEffect(() => {
    const onMsg = (e: MessageEvent<CalMsg>) => {
      if (e.origin !== "https://calendly.com") return;
      if (e.data?.event !== "calendly.event_scheduled") return;
      setBooked(true);
      const event_uri = e.data.payload?.event?.uri;
      const invitee_uri = e.data.payload?.invitee?.uri;
      if (event_uri && invitee_uri) {
        fetch("/api/calendly/scheduled", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ event_uri, invitee_uri }) }).catch(() => {});
      }
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const src = `${url}${url.includes("?") ? "&" : "?"}hide_gdpr_banner=1&primary_color=3b82f6`;

  return (
    <div>
      {booked && (
        <div role="status" className="mb-4 flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
          <Icon name="check" className="size-5" /> Your call is booked. A calendar invitation is on its way to your inbox.
        </div>
      )}
      <div className="calendly-inline-widget min-h-[700px] overflow-hidden rounded-[var(--radius-card)] border border-line bg-white" data-url={src} />
      <Script src="https://assets.calendly.com/assets/external/widget.js" strategy="lazyOnload" />
    </div>
  );
}
