"use client";

import Script from "next/script";
import { useEffect, useId, useRef, useState } from "react";

type Common = { label: string; name: string; error?: string; required?: boolean; hint?: string; className?: string };

export function Field({ label, name, error, required, hint, className = "", ...rest }: Common & React.InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">{label}{required && <span className="text-violet"> *</span>}</label>
      <input id={id} name={name} required={required} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-e` : hint ? `${id}-h` : undefined} className="field" {...rest} />
      {hint && !error && <p id={`${id}-h`} className="mt-1.5 text-xs text-muted">{hint}</p>}
      {error && <p id={`${id}-e`} className="field-error">{error}</p>}
    </div>
  );
}

export function SelectField({ label, name, error, required, options, className = "", placeholder = "Select…", ...rest }: Common & { options: string[]; placeholder?: string } & React.SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">{label}{required && <span className="text-violet"> *</span>}</label>
      <select id={id} name={name} required={required} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-e` : undefined} className="field" defaultValue="" {...rest}>
        <option value="" disabled>{placeholder}</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
      {error && <p id={`${id}-e`} className="field-error">{error}</p>}
    </div>
  );
}

export function TextArea({ label, name, error, required, hint, className = "", ...rest }: Common & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">{label}{required && <span className="text-violet"> *</span>}</label>
      <textarea id={id} name={name} required={required} rows={5} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-e` : hint ? `${id}-h` : undefined} className="field resize-y" {...rest} />
      {hint && !error && <p id={`${id}-h`} className="mt-1.5 text-xs text-muted">{hint}</p>}
      {error && <p id={`${id}-e`} className="field-error">{error}</p>}
    </div>
  );
}

/** Hidden from people, tempting to bots. Must stay empty. */
export function Honeypot() {
  return (
    <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
      <label>Company fax<input type="text" name="company_fax" tabIndex={-1} autoComplete="off" /></label>
    </div>
  );
}

export function MarketingConsent() {
  return (
    <label className="flex items-start gap-3 text-sm leading-relaxed text-muted">
      <input type="checkbox" name="marketing_consent" className="mt-1 size-4 shrink-0 accent-violet" />
      <span>Optional: send me occasional email marketing tips and agency updates. You can unsubscribe at any time. Leaving this unticked means we&apos;ll only contact you about this request.</span>
    </label>
  );
}

declare global {
  interface Window {
    turnstile?: { render: (el: HTMLElement, opts: Record<string, unknown>) => string; reset: (id?: string) => void };
  }
}

export function Turnstile({ onToken, resetKey }: { onToken: (t: string) => void; resetKey: number }) {
  const siteKey = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
  const ref = useRef<HTMLDivElement>(null);
  const widget = useRef<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!siteKey || !loaded || !ref.current || !window.turnstile || widget.current) return;
    widget.current = window.turnstile.render(ref.current, {
      sitekey: siteKey,
      callback: onToken,
      "expired-callback": () => onToken(""),
      theme: "light",
    });
  }, [siteKey, loaded, onToken]);

  useEffect(() => {
    if (resetKey && widget.current) window.turnstile?.reset(widget.current);
  }, [resetKey]);

  if (!siteKey) return null;
  return (
    <>
      <Script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" strategy="afterInteractive" onLoad={() => setLoaded(true)} onReady={() => setLoaded(true)} />
      <div ref={ref} />
    </>
  );
}
