import Link from "next/link";
import { Logo } from "@/components/ui/Logo";
import { Icon } from "@/components/ui/Icon";
import { CookieSettingsButton } from "@/components/layout/CookieConsent";
import { SITE, telHref, whatsappHref } from "@/lib/content/site";
import { getActiveServices, getSettings } from "@/lib/data";

export async function Footer() {
  const [settings, services] = await Promise.all([getSettings(), getActiveServices()]);
  const { contact, social } = settings;
  const socials = [
    { label: "LinkedIn", href: social.linkedin },
    { label: "Instagram", href: social.instagram },
    { label: "X", href: social.x },
    { label: "Facebook", href: social.facebook },
  ].filter((s) => s.href);

  return (
    <footer className="bg-navy text-white">
      <div className="container-x grid gap-12 py-16 md:grid-cols-12">
        <div className="md:col-span-4">
          <Logo dark />
          <p className="mt-5 max-w-xs text-white/65">{SITE.tagline}</p>
          <p className="mt-2 max-w-xs text-sm text-white/45">{SITE.positioning}.</p>
          {socials.length > 0 && (
            <ul className="mt-6 flex flex-wrap gap-2">
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noopener noreferrer" className="rounded-full border border-white/15 px-3 py-1.5 text-sm text-white/75 hover:border-white/40 hover:text-white">
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="md:col-span-3">
          <h2 className="font-display text-sm font-semibold text-white/50">Services</h2>
          <ul className="mt-4 space-y-2.5 text-[0.95rem]">
            {services.map((s) => (
              <li key={s.slug}>
                <Link href={`/services/${s.slug}`} className="text-white/80 hover:text-white">{s.shortTitle}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-2">
          <h2 className="font-display text-sm font-semibold text-white/50">Agency</h2>
          <ul className="mt-4 space-y-2.5 text-[0.95rem]">
            {[
              ["/about", "About"],
              ["/industries", "Industries"],
              ["/work", "Our Work"],
              ["/pricing", "Pricing"],
              ["/insights", "Insights"],
              ["/free-email-audit", "Free Email Audit"],
              ["/book-a-call", "Book a Call"],
            ].map(([href, label]) => (
              <li key={href}><Link href={href} className="text-white/80 hover:text-white">{label}</Link></li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-3">
          <h2 className="font-display text-sm font-semibold text-white/50">Contact</h2>
          <ul className="mt-4 space-y-3 text-[0.95rem] text-white/80">
            <li><a className="flex items-center gap-2.5 hover:text-white" href={`mailto:${contact.email}`}><Icon name="mail" className="size-4 text-white/45" />{contact.email}</a></li>
            <li><a className="flex items-center gap-2.5 hover:text-white" href={telHref(contact.phone)}><Icon name="phone" className="size-4 text-white/45" />{contact.phone}</a></li>
            <li><a className="flex items-center gap-2.5 hover:text-white" href={whatsappHref(contact.whatsapp)} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" className="size-4 text-white/45" />WhatsApp us</a></li>
            <li className="flex items-start gap-2.5"><Icon name="pin" className="mt-0.5 size-4 shrink-0 text-white/45" />{contact.location}<br />{contact.operatingModel}, serving clients worldwide</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-x flex flex-col gap-4 py-6 text-sm text-white/50 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} Inboxora Digital. All rights reserved.</p>
          <ul className="flex flex-wrap gap-x-5 gap-y-2">
            <li><Link href="/legal/privacy" className="hover:text-white">Privacy Policy</Link></li>
            <li><Link href="/legal/terms" className="hover:text-white">Terms and Conditions</Link></li>
            <li><Link href="/legal/cookies" className="hover:text-white">Cookie Policy</Link></li>
            <li><CookieSettingsButton /></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
