"use client";

import Link from "next/link";
import Script from "next/script";
import { useEffect, useState } from "react";

type Consent = { analytics: boolean; ts: string };
const KEY = "inboxora_consent";
const OPEN_EVENT = "inboxora:open-cookie-settings";

function readConsent(): Consent | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Consent) : null;
  } catch {
    return null;
  }
}

function saveConsent(c: Consent) {
  try {
    localStorage.setItem(KEY, JSON.stringify(c));
  } catch {}
  document.cookie = `${KEY}=${c.analytics ? "analytics" : "necessary"}; path=/; max-age=${60 * 60 * 24 * 180}; SameSite=Lax`;
}

export function CookieSettingsButton() {
  return (
    <button type="button" className="hover:text-white" onClick={() => window.dispatchEvent(new Event(OPEN_EVENT))}>
      Cookie settings
    </button>
  );
}

export function CookieConsent() {
  const gaId = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID;
  const [consent, setConsent] = useState<Consent | null>(null);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const c = readConsent();
    setConsent(c);
    setOpen(!c);
    setReady(true);
    const reopen = () => setOpen(true);
    window.addEventListener(OPEN_EVENT, reopen);
    return () => window.removeEventListener(OPEN_EVENT, reopen);
  }, []);

  const choose = (analytics: boolean) => {
    const c = { analytics, ts: new Date().toISOString() };
    saveConsent(c);
    setConsent(c);
    setOpen(false);
    if (!analytics) {
      // Revoke: update consent mode and clear GA cookies already set.
      const w = window as unknown as { gtag?: (...a: unknown[]) => void };
      w.gtag?.("consent", "update", { analytics_storage: "denied" });
      document.cookie.split(";").map((s) => s.trim().split("=")[0]).filter((n) => n.startsWith("_ga")).forEach((n) => {
        document.cookie = `${n}=; path=/; max-age=0; domain=.${location.hostname.replace(/^www\./, "")}`;
        document.cookie = `${n}=; path=/; max-age=0`;
      });
    }
  };

  const analyticsOn = Boolean(gaId && consent?.analytics);

  return (
    <>
      {analyticsOn && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`} strategy="afterInteractive" />
          <Script id="ga4" strategy="afterInteractive">{`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            window.gtag = gtag;
            gtag('consent', 'default', { ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'granted' });
            gtag('js', new Date());
            gtag('config', '${gaId}', { anonymize_ip: true, allow_google_signals: false, allow_ad_personalization_signals: false });
          `}</Script>
        </>
      )}
      {ready && open && (
        <div role="dialog" aria-modal="false" aria-labelledby="cookie-title" className="fixed inset-x-3 bottom-3 z-[60] mx-auto max-w-xl rounded-[var(--radius-card)] border border-line bg-white p-5 shadow-[var(--shadow-lift)] sm:inset-x-auto sm:left-5 sm:p-6">
          <h2 id="cookie-title" className="font-display text-lg font-bold">Your privacy choices</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            We use strictly necessary cookies to run this site. With your permission, we&apos;d also like to use Google Analytics to understand which pages are useful. We don&apos;t use advertising cookies. Read our <Link href="/legal/cookies" className="text-blue underline underline-offset-2">Cookie Policy</Link>.
          </p>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <button type="button" className="btn btn-dark !py-2.5 text-sm" onClick={() => choose(true)}>Accept analytics</button>
            <button type="button" className="btn btn-ghost !py-2.5 text-sm" onClick={() => choose(false)}>Necessary only</button>
          </div>
        </div>
      )}
    </>
  );
}
