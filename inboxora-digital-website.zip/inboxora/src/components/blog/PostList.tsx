"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Icon } from "@/components/ui/Icon";

export type PostCard = { slug: string; title: string; excerpt: string; category: string; date: string; minutes: number; image: string | null };

export function PostList({ posts, categories }: { posts: PostCard[]; categories: string[] }) {
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return posts.filter((p) => (cat === "All" || p.category === cat) && (!n || `${p.title} ${p.excerpt} ${p.category}`.toLowerCase().includes(n)));
  }, [posts, cat, q]);

  return (
    <div>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div role="group" aria-label="Filter by category" className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none]">
          {["All", ...categories].map((c) => (
            <button key={c} type="button" aria-pressed={cat === c} onClick={() => setCat(c)} className={`shrink-0 rounded-full px-3.5 py-2 text-sm font-medium ${cat === c ? "bg-navy text-white" : "border border-line bg-white text-muted hover:text-navy"}`}>
              {c}
            </button>
          ))}
        </div>
        <label className="relative block w-full lg:w-72">
          <span className="sr-only">Search articles</span>
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search articles" className="field !rounded-full !pl-10" />
        </label>
      </div>
      <p className="mt-6 text-sm text-muted" aria-live="polite">{list.length} {list.length === 1 ? "article" : "articles"}</p>
      {list.length === 0 ? (
        <div className="mt-6 rounded-[var(--radius-card)] border border-dashed border-line bg-white p-12 text-center">
          <p className="font-display text-lg font-bold">No articles match your search.</p>
          <button type="button" className="btn btn-ghost mt-4" onClick={() => { setCat("All"); setQ(""); }}>Clear search</button>
        </div>
      ) : (
        <ul className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <li key={p.slug}>
              <Link href={`/insights/${p.slug}`} className="group flex h-full flex-col overflow-hidden rounded-[var(--radius-card)] border border-line bg-white hover:border-navy/25">
                {p.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.image} alt="" loading="lazy" className="aspect-[16/9] w-full object-cover" />
                )}
                <div className="flex flex-1 flex-col p-6">
                  <span className="text-sm font-medium text-violet">{p.category}</span>
                  <h2 className="mt-2 font-display text-xl font-bold leading-snug tracking-tight group-hover:text-blue">{p.title}</h2>
                  <p className="mt-3 line-clamp-3 text-[0.95rem] leading-relaxed text-muted">{p.excerpt}</p>
                  <p className="mt-auto pt-5 text-sm text-muted">{p.date}, {p.minutes} min read</p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
