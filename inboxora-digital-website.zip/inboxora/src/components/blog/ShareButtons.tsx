"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/Icon";

export function ShareButtons({ url, title }: { url: string; title: string }) {
  const [copied, setCopied] = useState(false);
  const u = encodeURIComponent(url);
  const t = encodeURIComponent(title);
  const links = [
    { label: "LinkedIn", href: `https://www.linkedin.com/sharing/share-offsite/?url=${u}` },
    { label: "X", href: `https://twitter.com/intent/tweet?url=${u}&text=${t}` },
    { label: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${u}` },
    { label: "WhatsApp", href: `https://wa.me/?text=${t}%20${u}` },
  ];
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="mr-1 flex items-center gap-1.5 text-sm text-muted"><Icon name="share" className="size-4" />Share</span>
      {links.map((l) => (
        <a key={l.label} href={l.href} target="_blank" rel="noopener noreferrer" className="rounded-full border border-line bg-white px-3 py-1.5 text-sm hover:border-navy/30">
          {l.label}<span className="sr-only"> (opens in a new tab)</span>
        </a>
      ))}
      <button
        type="button"
        className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5 text-sm hover:border-navy/30"
        onClick={async () => {
          try { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch {}
        }}
      >
        <Icon name="link" className="size-4" />{copied ? "Link copied" : "Copy link"}
      </button>
    </div>
  );
}
