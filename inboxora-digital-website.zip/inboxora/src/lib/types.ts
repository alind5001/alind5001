export type ContactSettings = {
  businessName: string;
  email: string;
  phone: string; // display format, e.g. +91 7355309230
  whatsapp: string; // digits incl. country code, e.g. 917355309230
  location: string;
  operatingModel: string;
};

export type SocialSettings = {
  linkedin: string;
  instagram: string;
  x: string;
  facebook: string;
};

export type StatItem = { value: string; label: string; detail: string };
export type StatsSettings = {
  items: StatItem[];
  summary: string;
  disclosure: string;
};

export type PricingPackage = {
  id: string;
  name: string;
  price: string; // e.g. "$249"
  period: string; // e.g. "/month"
  description: string;
  features: string[];
  cta: string;
  ctaHref: string;
  highlighted: boolean;
};
export type PricingSettings = { packages: PricingPackage[]; notes: string[] };

export type ServiceSummary = {
  slug: string;
  title: string;
  shortTitle: string;
  summary: string;
  bullets: string[];
  active: boolean; // inactive = hidden everywhere on the public site
  onHome: boolean;
  order: number;
};
export type ServicesSettings = { items: ServiceSummary[] };

export type LegalSettings = { privacy: string; terms: string; cookies: string; updated: string };

export type SiteSettings = {
  contact: ContactSettings;
  social: SocialSettings;
  stats: StatsSettings;
  pricing: PricingSettings;
  services: ServicesSettings;
  legal: LegalSettings;
};

export type ProjectImage = {
  url: string;
  caption: string;
  category: string;
  concept: boolean; // true = concept design, not real client work
};

export type CaseStudy = {
  overview: string;
  context: string;
  objectives: string[];
  strategy: string;
  workExecuted: string[];
  campaignExamples: string[];
  automationExamples: string[];
};

export type PortfolioProject = {
  id: string;
  slug: string;
  brand_name: string;
  website: string;
  industry: string;
  country: string;
  description: string;
  services: string[];
  categories: string[];
  images: ProjectImage[];
  verified_results: string | null;
  case_study: CaseStudy;
  attribution: string;
  publication_status: "published" | "draft";
  sort_order: number;
  created_at?: string;
};

export type BlogPost = {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  featured: boolean;
  featured_image: string | null;
  seo_title: string | null;
  meta_description: string | null;
  publication_status: "published" | "draft";
  published_at: string | null;
  updated_at?: string;
};

export type BlogCategory = { id: string; name: string; slug: string };

export type LeadSource = "contact" | "audit" | "booking";
export const LEAD_STATUSES = [
  "New",
  "Contacted",
  "Discovery Call Scheduled",
  "Proposal Sent",
  "Negotiation",
  "Won",
  "Lost",
] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export type Lead = {
  id: string;
  source: LeadSource;
  name: string;
  email: string;
  company: string | null;
  website: string | null;
  country: string | null;
  service: string | null;
  budget: string | null;
  details: string | null;
  status: LeadStatus;
  notes: string | null;
  created_at: string;
};
