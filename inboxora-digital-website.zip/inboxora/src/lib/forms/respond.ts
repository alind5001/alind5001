import "server-only";
import { NextResponse } from "next/server";
import type { ZodType } from "zod";
import { fieldErrors } from "@/lib/validation";
import { SITE } from "@/lib/content/site";

export const json = (status: number, body: Record<string, unknown>) => NextResponse.json(body, { status });

export async function parseBody<T>(req: Request, schema: ZodType<T>) {
  const ct = req.headers.get("content-type") || "";
  if (!ct.includes("application/json")) return { error: json(415, { ok: false, error: "Unsupported content type." }) };
  const len = Number(req.headers.get("content-length") || 0);
  if (len > 64 * 1024) return { error: json(413, { ok: false, error: "Submission is too large." }) };
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return { error: json(400, { ok: false, error: "Invalid request." }) };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    return { error: json(422, { ok: false, error: "Please check the highlighted fields.", fieldErrors: fieldErrors(parsed.error) }) };
  }
  return { data: parsed.data };
}

/** Basic same-origin check to stop other sites posting into the forms. */
export function sameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (!origin) return true; // some privacy setups strip Origin; other guards still apply
  try {
    const o = new URL(origin).host;
    const host = req.headers.get("x-forwarded-host") || req.headers.get("host");
    return o === host || o === new URL(SITE.url).host;
  } catch {
    return false;
  }
}

export const adminLink = (path: string) => `${SITE.url}${path}`;
