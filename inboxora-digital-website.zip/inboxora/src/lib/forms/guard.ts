import "server-only";
import { createHash } from "node:crypto";
import { createServiceClient } from "@/lib/supabase/service";
import { isTurnstileConfigured } from "@/lib/env";

export type FormKind = "contact" | "audit" | "booking";

const LIMIT_PER_HOUR: Record<FormKind, number> = { contact: 5, audit: 3, booking: 5 };
const DUPLICATE_WINDOW_MS = 10 * 60 * 1000;
const MIN_FILL_MS = 2500; // faster than this is almost certainly a bot

export function clientIp(req: Request) {
  const fwd = req.headers.get("x-forwarded-for");
  return (fwd?.split(",")[0] || req.headers.get("x-real-ip") || "unknown").trim();
}

export function hashIp(ip: string) {
  const salt = process.env.IP_HASH_SALT || "inboxora-default-salt-change-me";
  return createHash("sha256").update(`${salt}:${ip}`).digest("hex");
}

export async function verifyTurnstile(token: string, ip: string): Promise<boolean> {
  if (!isTurnstileConfigured()) return true; // not configured: honeypot + timing + rate limit still apply
  if (!token) return false;
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ secret: process.env.TURNSTILE_SECRET_KEY!, response: token, remoteip: ip }),
      cache: "no-store",
    });
    const data = (await res.json()) as { success?: boolean };
    return Boolean(data.success);
  } catch {
    return false;
  }
}

export type GuardResult =
  | { ok: true; ipHash: string; duplicate: boolean }
  | { ok: false; status: number; error: string };

/**
 * Runs every spam and abuse check before a submission is stored:
 * timing, CAPTCHA, per-IP rate limit (stored in Postgres so it works on serverless),
 * and duplicate detection by email within a short window.
 */
export async function guardSubmission(opts: {
  req: Request;
  kind: FormKind;
  email: string;
  startedAt?: number;
  turnstileToken: string;
  table: "contacts" | "audit_requests" | "bookings";
}): Promise<GuardResult> {
  const sb = createServiceClient();
  if (!sb) {
    return {
      ok: false,
      status: 503,
      error: "Our form isn't connected yet. Please email or WhatsApp us directly and we'll reply within one business day.",
    };
  }
  const ip = clientIp(opts.req);
  const ipHash = hashIp(ip);

  if (opts.startedAt && Date.now() - opts.startedAt < MIN_FILL_MS) {
    return { ok: false, status: 400, error: "That was quick. Please review your details and submit again." };
  }

  if (!(await verifyTurnstile(opts.turnstileToken, ip))) {
    return { ok: false, status: 400, error: "We couldn't verify you're human. Please complete the check and try again." };
  }

  const hourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { count, error: rlError } = await sb
    .from("submission_log")
    .select("id", { count: "exact", head: true })
    .eq("ip_hash", ipHash)
    .eq("form", opts.kind)
    .gte("created_at", hourAgo);
  if (rlError) return { ok: false, status: 500, error: "Something went wrong on our side. Please try again in a moment." };
  if ((count ?? 0) >= LIMIT_PER_HOUR[opts.kind]) {
    return { ok: false, status: 429, error: "Too many submissions from your network. Please try again in an hour, or email us directly." };
  }

  const since = new Date(Date.now() - DUPLICATE_WINDOW_MS).toISOString();
  const { count: dupCount } = await sb
    .from(opts.table)
    .select("id", { count: "exact", head: true })
    .eq("email", opts.email)
    .gte("created_at", since);

  await sb.from("submission_log").insert({ ip_hash: ipHash, form: opts.kind });

  return { ok: true, ipHash, duplicate: (dupCount ?? 0) > 0 };
}
