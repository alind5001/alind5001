import "server-only";
import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";
import { defaultSettings } from "@/lib/content/site";
import { SEED_PROJECTS } from "@/lib/content/brands";
import { SEED_POSTS, BLOG_CATEGORIES } from "@/lib/content/posts";
import type { BlogCategory, BlogPost, PortfolioProject, ServiceSummary, SiteSettings } from "@/lib/types";

/*
 * Public data access. When Supabase is configured, published content comes from
 * the database (RLS only exposes published rows). When it is not configured yet,
 * the site falls back to the built-in launch content so it still renders.
 */

export const getSettings = cache(async (): Promise<SiteSettings> => {
  const sb = createPublicClient();
  if (!sb) return defaultSettings;
  const { data, error } = await sb.from("site_settings").select("key, value");
  if (error || !data) return defaultSettings;
  const merged: SiteSettings = structuredClone(defaultSettings);
  for (const row of data as { key: keyof SiteSettings; value: unknown }[]) {
    if (row.key in merged && row.value && typeof row.value === "object") {
      // Shallow-merge each section so new default fields survive older saved rows.
      (merged as Record<string, unknown>)[row.key] = { ...(merged[row.key] as object), ...(row.value as object) };
    }
  }
  return merged;
});

export async function getActiveServices(): Promise<ServiceSummary[]> {
  const s = await getSettings();
  return s.services.items.filter((i) => i.active).sort((a, b) => a.order - b.order);
}

export const getProjects = cache(async (): Promise<PortfolioProject[]> => {
  const sb = createPublicClient();
  if (!sb) return SEED_PROJECTS;
  const { data, error } = await sb
    .from("portfolio_projects")
    .select("*")
    .eq("publication_status", "published")
    .order("sort_order", { ascending: true });
  if (error || !data) return SEED_PROJECTS;
  return data as PortfolioProject[];
});

export async function getProject(slug: string) {
  const all = await getProjects();
  return all.find((p) => p.slug === slug) ?? null;
}

export const getPosts = cache(async (): Promise<BlogPost[]> => {
  const sb = createPublicClient();
  if (!sb) return SEED_POSTS;
  const { data, error } = await sb
    .from("blog_posts")
    .select("*")
    .eq("publication_status", "published")
    .lte("published_at", new Date().toISOString())
    .order("published_at", { ascending: false });
  if (error || !data) return SEED_POSTS;
  return data as BlogPost[];
});

export async function getPost(slug: string) {
  const all = await getPosts();
  return all.find((p) => p.slug === slug) ?? null;
}

export const getCategories = cache(async (): Promise<BlogCategory[]> => {
  const sb = createPublicClient();
  const fallback = BLOG_CATEGORIES.map((c) => ({ id: c.slug, ...c }));
  if (!sb) return fallback;
  const { data, error } = await sb.from("blog_categories").select("*").order("name");
  if (error || !data) return fallback;
  return data as BlogCategory[];
});
