export const env = {
  supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
};

export const isSupabaseConfigured = () => Boolean(env.supabaseUrl && env.supabaseAnonKey);
export const hasServiceRole = () => Boolean(isSupabaseConfigured() && process.env.SUPABASE_SERVICE_ROLE_KEY);
export const isResendConfigured = () =>
  Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM && process.env.AGENCY_NOTIFICATION_EMAIL);
export const isTurnstileConfigured = () =>
  Boolean(process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY && process.env.TURNSTILE_SECRET_KEY);
export const calendlyUrl = () => process.env.NEXT_PUBLIC_CALENDLY_URL || "";
