import { z } from "zod";
import { BUDGET_OPTIONS, INDUSTRY_OPTIONS, PLATFORM_OPTIONS, SUBSCRIBER_OPTIONS } from "@/lib/content/site";

const str = (max: number) => z.string().trim().max(max, `Keep this under ${max} characters.`);
const req = (label: string, max = 120) => str(max).min(1, `${label} is required.`);

const url = z
  .string()
  .trim()
  .min(1, "Website URL is required.")
  .max(300)
  .transform((v) => (/^https?:\/\//i.test(v) ? v : `https://${v}`))
  .refine((v) => {
    try {
      const u = new URL(v);
      return /^https?:$/.test(u.protocol) && u.hostname.includes(".");
    } catch {
      return false;
    }
  }, "Enter a valid website, like yourstore.com.");

const optionalUrl = z.union([z.literal(""), url]).optional().default("");

const email = z.string().trim().toLowerCase().min(1, "Email is required.").max(254).email("Enter a valid email address.");

/** Anti-spam fields included with every public form. */
export const antiSpam = {
  company_fax: z.string().max(0, "Spam detected.").optional().default(""), // honeypot: must stay empty
  started_at: z.coerce.number().optional(), // ms timestamp when form was rendered
  turnstile_token: z.string().max(4096).optional().default(""),
  marketing_consent: z.boolean().optional().default(false),
};

export const contactSchema = z.object({
  name: req("Full name", 100),
  email,
  company: req("Company name", 150),
  website: optionalUrl,
  country: req("Country", 80),
  service: req("Service", 120),
  budget: z.enum(BUDGET_OPTIONS as [string, ...string[]], { message: "Choose a budget range." }),
  message: req("Message", 4000).min(10, "Tell us a little more (at least 10 characters)."),
  plan: str(80).optional().default(""),
  ...antiSpam,
});

export const auditSchema = z.object({
  name: req("Full name", 100),
  email,
  company: req("Company name", 150),
  website: url,
  country: req("Country", 80),
  industry: z.enum(INDUSTRY_OPTIONS as [string, ...string[]], { message: "Choose an industry." }),
  email_platform: z.enum(PLATFORM_OPTIONS as [string, ...string[]], { message: "Choose your email platform." }),
  subscriber_count: z.enum(SUBSCRIBER_OPTIONS as [string, ...string[]], { message: "Choose a subscriber range." }),
  marketing_challenge: req("Main marketing challenge", 2000),
  additional_information: req("Additional information", 4000),
  ...antiSpam,
});

export const bookingRequestSchema = z.object({
  name: req("Full name", 100),
  email,
  company: req("Company name", 150),
  website: url,
  timezone: req("Time zone", 64),
  preferred_date: z
    .string()
    .trim()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a preferred date."),
  preferred_time: z.enum(["Morning (9am–12pm)", "Afternoon (12pm–4pm)", "Evening (4pm–7pm)"], { message: "Choose a preferred time of day." }),
  requirements: req("Business requirements", 4000),
  ...antiSpam,
});

export const calendlyEventSchema = z.object({
  event_uri: z.string().regex(/^https:\/\/api\.calendly\.com\/scheduled_events\/[A-Za-z0-9-]+$/),
  invitee_uri: z.string().regex(/^https:\/\/api\.calendly\.com\/scheduled_events\/[A-Za-z0-9-]+\/invitees\/[A-Za-z0-9-]+$/),
  company: str(150).optional().default(""),
  website: optionalUrl,
});

export type ContactInput = z.infer<typeof contactSchema>;
export type AuditInput = z.infer<typeof auditSchema>;
export type BookingRequestInput = z.infer<typeof bookingRequestSchema>;

export function fieldErrors(err: z.ZodError) {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const k = String(issue.path[0] ?? "form");
    if (!out[k]) out[k] = issue.message;
  }
  return out;
}
