import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import { LEAD_STATUSES, type Lead } from "@/lib/types";

export type LeadFilters = { q?: string; source?: string; status?: string; sort?: string; country?: string };

export async function queryLeads(sb: SupabaseClient, f: LeadFilters, limit = 500) {
  let q = sb.from("leads").select("*");
  if (f.source && ["contact", "audit", "booking"].includes(f.source)) q = q.eq("source", f.source);
  if (f.status && (LEAD_STATUSES as readonly string[]).includes(f.status)) q = q.eq("status", f.status);
  if (f.country) q = q.eq("country", f.country.slice(0, 80));
  const term = (f.q || "").replace(/[,()*%\\]/g, " ").trim().slice(0, 80);
  if (term) q = q.or(["name", "email", "company", "website", "service", "notes"].map((c) => `${c}.ilike.%${term}%`).join(","));
  const sort = f.sort || "newest";
  if (sort === "oldest") q = q.order("created_at", { ascending: true });
  else if (sort === "name") q = q.order("name", { ascending: true });
  else if (sort === "status") q = q.order("status", { ascending: true }).order("created_at", { ascending: false });
  else q = q.order("created_at", { ascending: false });
  const { data, error } = await q.limit(limit);
  return { rows: (data ?? []) as Lead[], error: error?.message };
}

export function leadRef(l: Pick<Lead, "id" | "source">) {
  const prefix = { contact: "ENQ", audit: "AUD", booking: "CALL" }[l.source];
  return `${prefix}-${l.id.slice(0, 8).toUpperCase()}`;
}
