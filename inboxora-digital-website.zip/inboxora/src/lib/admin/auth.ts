import "server-only";
import { redirect } from "next/navigation";
import { createSessionClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/env";

export type StaffRole = "owner" | "admin" | "editor";

/** Server-side gate for every admin page and action (defence in depth beyond middleware + RLS). */
export async function requireStaff(minimum: "staff" | "admin" = "staff") {
  if (!isSupabaseConfigured()) redirect("/admin/login?setup=1");
  const supabase = await createSessionClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/admin/login");
  const { data: row } = await supabase.from("admin_users").select("role, email").eq("user_id", user.id).maybeSingle();
  if (!row) redirect("/admin/login?denied=1");
  const role = row.role as StaffRole;
  if (minimum === "admin" && role === "editor") redirect("/admin?forbidden=1");
  return { supabase, user, role, email: row.email as string };
}

/** For server actions: returns an error instead of redirecting. */
export async function staffOrError(minimum: "staff" | "admin" = "staff") {
  if (!isSupabaseConfigured()) return { error: "Supabase is not configured." } as const;
  const supabase = await createSessionClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Your session has expired. Please sign in again." } as const;
  const { data: row } = await supabase.from("admin_users").select("role").eq("user_id", user.id).maybeSingle();
  if (!row) return { error: "You don't have access to the admin area." } as const;
  if (minimum === "admin" && row.role === "editor") return { error: "Only admins can do this." } as const;
  return { supabase, user, role: row.role as StaffRole } as const;
}
