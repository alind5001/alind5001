import "server-only";
import { createClient } from "@supabase/supabase-js";
import { env, hasServiceRole } from "@/lib/env";

/**
 * Service-role client. Bypasses RLS — use ONLY in server code for validated
 * form inserts, rate limiting and duplicate checks. Never import in client code.
 */
export function createServiceClient() {
  if (!hasServiceRole()) return null;
  return createClient(env.supabaseUrl, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
