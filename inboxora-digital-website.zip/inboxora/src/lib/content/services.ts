export type ServiceDetail = {
  slug: string;
  heroHeadline: string;
  heroCopy: string;
  overview: string[];
  problems: { title: string; body: string }[];
  included: string[];
  deliverables: string[];
  process: { title: string; body: string }[];
  faqs: { q: string; a: string }[];
  portfolioCategories: string[];
  seoTitle: string;
  seoDescription: string;
};

export const SERVICE_DETAILS: Record<string, ServiceDetail> = {
  "email-campaign-management": {
    slug: "email-campaign-management",
    heroHeadline: "Campaigns your customers look forward to opening.",
    heroCopy:
      "We plan, write, design, build and schedule your email campaigns around your products, promotions and seasonal calendar, then report on what each send contributed.",
    overview: [
      "Most e-commerce brands know they should email more consistently. The hard part is doing it every week without sends becoming repetitive, rushed or disconnected from what is happening in the business.",
      "Our campaign management service gives you a planned calendar of promotional emails, newsletters, launches and seasonal moments. Each campaign has a clear purpose, a defined audience and a single action we want the reader to take.",
    ],
    problems: [
      { title: "Irregular sending", body: "Campaigns go out when someone has time, so subscribers forget you between sends and engagement drops." },
      { title: "Discount-only messaging", body: "Every email is a sale, which trains customers to wait for offers and erodes margin." },
      { title: "Last-minute seasonal pushes", body: "BFCM, holidays and launches get planned a week out, leaving no room for build-up or testing." },
      { title: "No feedback loop", body: "Results are not reviewed, so the next campaign repeats what did not work." },
    ],
    included: [
      "Monthly campaign calendar aligned to your promotions and product roadmap",
      "Promotional campaigns, newsletters and product launch emails",
      "Seasonal and BFCM campaign sequences planned weeks in advance",
      "Subject lines, preview text and body copy",
      "Design and build in your email platform",
      "Audience selection and send-time scheduling",
      "QA across major inboxes and devices before every send",
      "Campaign performance reporting",
    ],
    deliverables: [
      "Approved monthly campaign calendar",
      "Campaign drafts for review before scheduling",
      "Scheduled campaigns inside your platform",
      "Monthly performance report with recommendations",
    ],
    process: [
      { title: "Plan", body: "We agree the month's priorities: launches, offers, content themes and key dates." },
      { title: "Draft", body: "We write and design each campaign and share it with you for approval." },
      { title: "Schedule", body: "Approved campaigns are built, tested and scheduled to the right segments." },
      { title: "Review", body: "We report on results and carry the learnings into next month's calendar." },
    ],
    faqs: [
      { q: "How many campaigns should we send each month?", a: "It depends on your list size, product range and how much you have to say. Our packages start at four campaigns a month; we recommend a cadence after reviewing your audience and calendar." },
      { q: "Do you write the copy?", a: "Yes. Copywriting is included in the Growth and Revenue Management packages, and available as an add-on for Essentials." },
      { q: "Will you send anything without our approval?", a: "No. Every campaign is shared for approval before it is scheduled." },
      { q: "Which platforms do you work in?", a: "We work in Klaviyo, Shopify Email, Omnisend and Mautic, and can review other platforms during an audit." },
    ],
    portfolioCategories: ["Promotional Campaigns", "Newsletters", "Product Launches", "Seasonal Campaigns"],
    seoTitle: "Email Campaign Management for E-commerce Brands",
    seoDescription:
      "Email campaign management for Shopify and D2C brands: planned promotional campaigns, newsletters, product launches and BFCM sends, designed, scheduled and reported.",
  },
  "email-automation": {
    slug: "email-automation",
    heroHeadline: "Automated journeys that keep working while you sleep.",
    heroCopy:
      "We design, write and build lifecycle flows that respond to what customers do, from their first visit to their fifth order.",
    overview: [
      "Automated emails reach people at the moments they are paying the most attention: right after they sign up, while a cart is still fresh, just after an order arrives, or when it is time to reorder.",
      "We map your customer lifecycle, decide which flows matter most for your business, and build them with clear triggers, timing, exit conditions and content that matches where the customer is.",
    ],
    problems: [
      { title: "Missing core flows", body: "No welcome, cart or post-purchase flow means the most timely messages never get sent." },
      { title: "Set-and-forget flows", body: "Flows built years ago still run with outdated products, offers and branding." },
      { title: "Overlapping messages", body: "Customers receive a cart reminder, a browse reminder and a campaign on the same day." },
      { title: "One flow for everyone", body: "First-time buyers and loyal customers get identical post-purchase emails." },
    ],
    included: [
      "Lifecycle map and flow prioritisation",
      "Welcome series for new subscribers",
      "Abandoned cart and checkout recovery",
      "Browse abandonment",
      "Post-purchase and onboarding sequences",
      "Replenishment reminders for consumable products",
      "Winback and sunset flows",
      "Trigger, filter and exit-condition setup",
      "Flow QA and ongoing optimisation",
    ],
    deliverables: [
      "Lifecycle flow map",
      "Flow copy and designs for approval",
      "Live, tested flows in your platform",
      "Flow performance review with recommended next tests",
    ],
    process: [
      { title: "Map", body: "We review your existing flows and customer journey, then prioritise the gaps." },
      { title: "Design", body: "We write and design each email in the flow, with timing and branching logic." },
      { title: "Build and test", body: "Flows are built with triggers, filters and exits, and tested end to end." },
      { title: "Optimise", body: "We monitor performance and run tests on timing, content and offers." },
    ],
    faqs: [
      { q: "Which flows should we build first?", a: "For most stores: welcome series, abandoned cart, browse abandonment and post-purchase. The right order depends on your traffic, catalogue and current setup." },
      { q: "Can you improve flows we already have?", a: "Yes. We often start by auditing and rebuilding existing flows rather than adding new ones." },
      { q: "Do automated flows need discounts?", a: "Not always. We decide on offers flow by flow, and often lead with reassurance, social proof or product information instead." },
      { q: "Are advanced flow builds included in the packages?", a: "The Growth package includes two initial flows. Large or complex implementations are quoted separately." },
    ],
    portfolioCategories: ["Email Automation", "Welcome Emails", "Abandoned Cart", "Browse Abandonment"],
    seoTitle: "Email Automation Services & Lifecycle Marketing",
    seoDescription:
      "Email automation services for e-commerce: welcome series, abandoned cart, browse abandonment, post-purchase, replenishment and winback flows in Klaviyo and more.",
  },
  "email-design-development": {
    slug: "email-design-development",
    heroHeadline: "Emails that look right in every inbox.",
    heroCopy:
      "Branded, responsive templates and campaign designs, coded to render reliably across email clients, screen sizes and dark mode.",
    overview: [
      "Email is not the web. Each inbox renders HTML differently, images are often blocked by default, and most opens happen on a phone. Good email design accounts for all of this from the start.",
      "We design modular template systems for your brand and build them in clean, tested HTML or in your platform's editor, so your team can create new campaigns quickly without breaking the layout.",
    ],
    problems: [
      { title: "Broken layouts", body: "Emails look fine in one inbox and fall apart in Outlook or on mobile." },
      { title: "Image-only emails", body: "Whole emails built as one image are invisible when images are off and hard to read on small screens." },
      { title: "Off-brand templates", body: "Generic platform templates make your emails look like everyone else's." },
      { title: "Slow production", body: "Every campaign is designed from scratch because there is no reusable system." },
    ],
    included: [
      "Branded master template and modular content blocks",
      "Custom HTML email templates",
      "Responsive and mobile-first layouts",
      "Promotional banners and hero graphics",
      "Newsletter templates",
      "Dark-mode and accessibility checks",
      "Cross-client rendering tests",
    ],
    deliverables: [
      "Template system in your email platform",
      "Source HTML files where applicable",
      "Module guide showing how to build new emails",
      "Rendering test results",
    ],
    process: [
      { title: "Brief", body: "We gather your brand guidelines, existing emails and the types of campaigns you send." },
      { title: "Design", body: "We design the master template and modules and share them for feedback." },
      { title: "Build", body: "Approved designs are coded or built in your platform's editor." },
      { title: "Test and hand over", body: "We test across clients and devices, then document the system for your team." },
    ],
    faqs: [
      { q: "Do you code emails by hand?", a: "Yes, when a fully custom template is needed. We also build in drag-and-drop editors when your team needs to edit easily." },
      { q: "Will the templates work in Outlook?", a: "We design and test for major clients, including Outlook, Gmail and Apple Mail, and adapt layouts where a client has known limitations." },
      { q: "Can you work from our existing brand guidelines?", a: "Yes. We adapt your brand's typography, colours and imagery to the constraints of email." },
      { q: "Do you design one-off campaign emails?", a: "Yes, either as part of a monthly package or as individual design projects." },
    ],
    portfolioCategories: ["Promotional Campaigns", "Newsletters", "Product Launches"],
    seoTitle: "Email Design & HTML Email Development",
    seoDescription:
      "Custom HTML email templates and responsive email design for e-commerce brands, tested across inboxes, devices and dark mode.",
  },
  "email-marketing-strategy": {
    slug: "email-marketing-strategy",
    heroHeadline: "A clear plan for what to send, to whom, and why.",
    heroCopy:
      "We audit your current email programme and turn the findings into a lifecycle and campaign strategy tied to your commercial goals.",
    overview: [
      "Strategy is what turns a collection of emails into a channel. It answers simple questions that are easy to skip: who are we talking to, what do they need from us at each stage, and how will we know it is working?",
      "We start with an audit of your account, flows, campaigns, list and reporting, then build a practical plan covering segments, lifecycle messaging, campaign themes and a testing roadmap.",
    ],
    problems: [
      { title: "No overall plan", body: "Campaigns and flows are added one by one without a view of the whole journey." },
      { title: "Unclear goals", body: "There is no agreed definition of what success looks like for email." },
      { title: "Untapped data", body: "Purchase and engagement data sits in the platform but is not used to tailor messages." },
      { title: "Guesswork", body: "Decisions about timing, frequency and offers are not backed by tests." },
    ],
    included: [
      "Email marketing audit",
      "Customer lifecycle strategy",
      "Audience segmentation plan",
      "Personalisation recommendations",
      "Campaign planning framework",
      "A/B testing roadmap",
      "KPI and reporting definitions",
    ],
    deliverables: [
      "Audit findings and prioritised opportunities",
      "Lifecycle and segmentation plan",
      "90-day campaign and testing roadmap",
      "Strategy walkthrough call",
    ],
    process: [
      { title: "Discover", body: "We learn about your products, customers, margins and goals." },
      { title: "Audit", body: "We review your platform setup, flows, campaigns, list and reporting." },
      { title: "Plan", body: "We build the lifecycle, segmentation and campaign strategy." },
      { title: "Present", body: "We walk you through the plan and agree priorities and next steps." },
    ],
    faqs: [
      { q: "Is the free audit the same as a strategy engagement?", a: "No. The free audit is a focused review that highlights opportunities. A strategy engagement goes deeper and produces a full plan." },
      { q: "Do we have to hire you to execute the strategy?", a: "No. The plan is yours. Many clients do choose to have us implement it." },
      { q: "What access do you need?", a: "For a paid engagement we request appropriate team-member access to your platform through its user management. We never ask for your password." },
      { q: "How long does a strategy project take?", a: "Typically two to four weeks, depending on the size of your account and how quickly we can meet." },
    ],
    portfolioCategories: ["Email Automation", "Promotional Campaigns"],
    seoTitle: "Email Marketing Strategy & Audits | Email Marketing Consultant",
    seoDescription:
      "Email marketing audits and lifecycle strategy for e-commerce brands: segmentation, personalisation, campaign planning and A/B testing roadmaps.",
  },
  "segmentation-personalisation": {
    slug: "segmentation-personalisation",
    heroHeadline: "The right message for each customer, not just the whole list.",
    heroCopy:
      "We build segments from purchase history, browsing behaviour and engagement, then use them to personalise campaigns and flows.",
    overview: [
      "Sending every email to every subscriber is simple, but it treats a first-time visitor and a loyal repeat customer the same way. Segmentation lets you speak to each group in a way that reflects their relationship with your brand.",
      "We define segments that are useful for your business, keep them maintainable, and use dynamic content so one campaign can adapt to different readers.",
    ],
    problems: [
      { title: "Whole-list sends", body: "Every campaign goes to everyone, including people who have not opened in a year." },
      { title: "Irrelevant recommendations", body: "Customers are shown products they already bought or never showed interest in." },
      { title: "Too many segments", body: "Dozens of overlapping segments that nobody understands or maintains." },
      { title: "Unknown preferences", body: "No easy way for subscribers to tell you what they want to hear about." },
    ],
    included: [
      "Engagement-based segments and sending tiers",
      "Purchase-history and product-interest segments",
      "New, repeat and lapsed customer segments",
      "Dynamic content and conditional blocks",
      "Product recommendation setup",
      "Preference centre design",
      "Segment documentation",
    ],
    deliverables: [
      "Segmentation framework and definitions",
      "Segments built in your platform",
      "Personalised campaign and flow templates",
      "Segment usage guide",
    ],
    process: [
      { title: "Review data", body: "We check which customer and event data is available in your platform." },
      { title: "Define segments", body: "We agree a small, useful set of segments tied to your goals." },
      { title: "Build", body: "Segments, dynamic blocks and recommendation logic are built and checked." },
      { title: "Apply", body: "We use the segments in campaigns and flows and measure the difference." },
    ],
    faqs: [
      { q: "How many segments do we need?", a: "Fewer than most people think. A handful of well-defined segments used consistently beats dozens that are rarely used." },
      { q: "Do we need a lot of data to start?", a: "No. Engagement and purchase history are enough for useful segments. More data enables more advanced personalisation." },
      { q: "Will personalisation work on Shopify Email?", a: "Some personalisation is possible. Platforms like Klaviyo and Omnisend offer more advanced options; we will advise what is realistic on yours." },
      { q: "Can you clean up our existing segments?", a: "Yes. Consolidating and documenting segments is often a first step." },
    ],
    portfolioCategories: ["Email Automation", "Promotional Campaigns"],
    seoTitle: "Email Segmentation & Personalisation for E-commerce",
    seoDescription:
      "Email segmentation and personalisation services: behavioural, purchase-history and engagement segments, dynamic content and product recommendations.",
  },
  "deliverability-list-management": {
    slug: "deliverability-list-management",
    heroHeadline: "Make sure your emails actually reach the inbox.",
    heroCopy:
      "We review your sending setup, authentication and list health, then put monitoring and hygiene practices in place to protect your sender reputation.",
    overview: [
      "The best campaign does nothing if it lands in spam. Mailbox providers decide where your email goes based on authentication, sender reputation and how recipients engage with your messages.",
      "We check that your domain is correctly authenticated, review list growth and consent practices, and set up hygiene and monitoring routines so problems are caught early.",
    ],
    problems: [
      { title: "Missing authentication", body: "SPF, DKIM or DMARC are missing or misconfigured, which mailbox providers increasingly require." },
      { title: "Unengaged list", body: "Large numbers of inactive subscribers drag down engagement and reputation." },
      { title: "Unclear consent", body: "It is not clear how or when subscribers opted in." },
      { title: "No monitoring", body: "Bounces and complaints rise unnoticed until placement suffers." },
    ],
    included: [
      "Email authentication review",
      "SPF, DKIM and DMARC checks and recommendations",
      "Sending domain and dedicated sending setup review",
      "List hygiene and sunset policy",
      "Bounce and spam complaint monitoring",
      "Consent and subscription management review",
      "Unsubscribe and preference handling",
    ],
    deliverables: [
      "Deliverability audit report",
      "DNS record recommendations for your developer or host",
      "List hygiene and sunset rules",
      "Ongoing monitoring summary in monthly reports",
    ],
    process: [
      { title: "Check", body: "We review authentication, domain setup and recent sending metrics." },
      { title: "Fix", body: "We provide DNS changes and platform settings, and support your team in applying them." },
      { title: "Clean", body: "We set up engagement-based hygiene and sunset flows." },
      { title: "Monitor", body: "We track bounces, complaints and engagement trends over time." },
    ],
    faqs: [
      { q: "Can you change our DNS records?", a: "We provide exact records and instructions. Your developer or domain host applies them, or we can do so with delegated access you control." },
      { q: "Will cleaning the list reduce revenue?", a: "Removing long-inactive subscribers usually protects deliverability for everyone else. We use re-engagement attempts before removing anyone." },
      { q: "Do you help with consent requirements?", a: "We review your signup and consent practices against common requirements such as GDPR, CAN-SPAM and CASL and flag issues. This is not legal advice." },
      { q: "Can you guarantee inbox placement?", a: "No one can guarantee placement. We follow sender best practices that give your emails the best chance." },
    ],
    portfolioCategories: ["Email Automation"],
    seoTitle: "Email Deliverability & List Management Services",
    seoDescription:
      "Email deliverability services for e-commerce: SPF, DKIM and DMARC checks, list hygiene, bounce and complaint monitoring, and consent management.",
  },
  "analytics-performance-reporting": {
    slug: "analytics-performance-reporting",
    heroHeadline: "Reporting that tells you what to do next.",
    heroCopy:
      "We connect email activity to revenue and retention, and present it in reports that are short, honest and actionable.",
    overview: [
      "Email platforms produce plenty of numbers. The challenge is knowing which ones matter, how attribution is being counted, and what the numbers suggest you should change.",
      "We set up consistent tracking, define the metrics that reflect your goals, and deliver regular reports that explain performance in plain language with clear recommendations.",
    ],
    problems: [
      { title: "Vanity metrics", body: "Reports focus on opens, which privacy features have made unreliable." },
      { title: "Attribution confusion", body: "Email, ads and analytics tools all claim the same sale." },
      { title: "No context", body: "Numbers are reported without comparison or explanation." },
      { title: "No next steps", body: "Reports describe the past without recommending what to change." },
    ],
    included: [
      "Revenue attribution review and settings",
      "Campaign and flow performance reporting",
      "Click-through and engagement analysis",
      "Conversion tracking checks",
      "Revenue per recipient analysis",
      "Customer retention and repeat-purchase insights",
      "Monthly report with recommendations",
    ],
    deliverables: [
      "Agreed KPI definitions",
      "Monthly performance report",
      "Quarterly retention review",
      "Prioritised optimisation recommendations",
    ],
    process: [
      { title: "Align", body: "We agree goals, KPIs and how attribution will be counted." },
      { title: "Instrument", body: "We check tracking, UTM conventions and platform attribution settings." },
      { title: "Report", body: "We deliver regular reports with commentary, not just tables." },
      { title: "Recommend", body: "Each report ends with specific tests and changes for the next period." },
    ],
    faqs: [
      { q: "Why don't you focus on open rates?", a: "Privacy features in some email apps inflate opens. We report them, but put more weight on clicks, conversions and revenue." },
      { q: "How do you handle attribution?", a: "We document the attribution window and model your platform uses and compare it with your store and analytics data, so everyone reads the numbers the same way." },
      { q: "Can you report on retention?", a: "Yes. Repeat-purchase rate and time between orders are often more useful than single-campaign metrics." },
      { q: "Do you use a dashboard tool?", a: "We usually report from your email platform and store data. A custom dashboard can be scoped separately." },
    ],
    portfolioCategories: ["Promotional Campaigns", "Email Automation"],
    seoTitle: "Email Marketing Analytics & Performance Reporting",
    seoDescription:
      "Email marketing analytics for e-commerce brands: revenue attribution, campaign reporting, conversion tracking, revenue per recipient and retention insights.",
  },
};
