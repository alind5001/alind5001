import type { LegalSettings } from "@/lib/types";

// Starting templates. They are editable in Admin → Settings → Legal pages.
// Have them reviewed by a qualified legal professional before launch.

const privacy = `This Privacy Policy explains how Inboxora Digital ("we", "us") collects and uses personal data when you visit this website or contact us. We are a remote-first email marketing agency based in Lucknow, Uttar Pradesh, India.

## What we collect

**Information you give us.** When you submit our contact form, free email audit form or discovery call request, we collect the details you enter: your name, business email, company name, website, country, the service you are interested in, budget range, and the message or business information you choose to share.

We never ask for passwords to your email platform, store or any other system, and we ask you not to send us your customers' personal data through our forms.

**Information collected automatically.** With your consent, we use Google Analytics 4 to understand how visitors use the site (pages viewed, approximate location at country or city level, device type). Analytics only loads after you accept analytics cookies. See our [Cookie Policy](/legal/cookies).

**Security data.** To prevent spam and abuse, we process a one-way hashed version of your IP address for rate limiting, and we may use Cloudflare Turnstile to verify that form submissions come from a person.

## How we use it

- To respond to your enquiry, prepare your email audit or arrange a discovery call.
- To send you a confirmation that we received your submission.
- To manage our relationship with you if you become a client.
- To keep the website secure and prevent spam.
- To improve the website, where you have consented to analytics.

We do **not** add you to any marketing mailing list because you submitted a form. We will only send you marketing emails if you separately and explicitly opt in, and every such email will include a way to unsubscribe.

## Legal bases

Where the GDPR or UK GDPR applies, we rely on: steps taken at your request before entering a contract (responding to enquiries), our legitimate interests (security, running our business), and consent (analytics cookies, any marketing). Where India's Digital Personal Data Protection Act, 2023 applies, we process personal data for the specific purpose for which you provided it, and you may withdraw consent at any time.

## Who we share it with

We use trusted service providers to run this website: Supabase (database and hosting of submissions), Resend (sending confirmation and notification emails), Vercel (website hosting), Calendly (if you book a call through it), Cloudflare (spam protection) and Google (analytics, only with consent). These providers process data on our behalf. Some are located outside India, the UK or the EU; where required, appropriate safeguards apply. We do not sell your personal data.

## How long we keep it

Enquiries that do not lead to a working relationship are deleted within 24 months. Client records are kept for as long as needed for the engagement and to meet legal and accounting obligations.

## Your rights

Depending on where you live, you may have the right to access, correct, delete or receive a copy of your personal data, to object to or restrict certain processing, to withdraw consent and to complain to a data protection authority or grievance officer. To exercise any of these rights, email us at the address on our [Contact page](/contact).

## Contact

For any privacy question, contact Inboxora Digital using the details on our [Contact page](/contact).`;

const terms = `These Terms and Conditions govern your use of the Inboxora Digital website. By using the site, you agree to them.

## About us

Inboxora Digital is an independent, remote-first email marketing agency based in Lucknow, Uttar Pradesh, India.

## Use of this website

You may browse the site and submit enquiries for legitimate business purposes. You must not misuse the site, attempt to gain unauthorised access to it, submit false information or interfere with its operation.

## Information on this site

Content on this website is provided for general information. It is not a promise of specific results. Any performance figures shown are historical, aggregated and reported as described alongside them; they are not a guarantee of future results for any client.

## Client experience

Brands shown in the Selected Client Experience section represent our founder's previous professional project work. Their inclusion does not imply endorsement by, or an official partnership with, those brands. Brand names and trademarks belong to their respective owners.

## Pricing

Prices shown are starting prices in US dollars and are indicative. Final scope, deliverables, fees and payment terms are agreed in writing before any work begins. Third-party software subscriptions are not included unless stated.

## Services

Engagements are governed by a separate written agreement or proposal. Where that agreement conflicts with these Terms, the agreement takes priority.

## Intellectual property

The design, text and code of this website belong to Inboxora Digital unless otherwise stated. You may not copy them for commercial use without permission.

## Liability

To the extent permitted by law, we are not liable for any indirect or consequential loss arising from use of this website. Nothing in these Terms limits liability that cannot be limited by law.

## Governing law

These Terms are governed by the laws of India, and the courts of Lucknow, Uttar Pradesh have jurisdiction, unless mandatory local law where you live says otherwise.

## Changes

We may update these Terms from time to time. The date at the top of the page shows the latest version.`;

const cookies = `This Cookie Policy explains how Inboxora Digital uses cookies and similar technologies on this website.

## What cookies are

Cookies are small files stored in your browser. Some are necessary for a website to work; others help the site owner understand how it is used.

## Cookies we use

| Category | Purpose | Examples | Default |
| --- | --- | --- | --- |
| Strictly necessary | Remember your cookie choice, keep the admin area signed in, protect forms from spam | \`inboxora_consent\`, Supabase auth cookies (admin only), Cloudflare Turnstile | Always on |
| Analytics | Understand which pages are useful, in aggregate | Google Analytics 4 (\`_ga\`, \`_ga_*\`) | Off until you accept |
| Third-party embeds | Show the Calendly scheduler on the booking page | Calendly | Only on the booking page |

We do not use advertising or retargeting cookies.

## Your choices

When you first visit, you can accept or reject analytics cookies. You can change your choice at any time using **Cookie settings** in the website footer. You can also block or delete cookies in your browser settings; strictly necessary cookies are required for parts of the site to work.

## Contact

Questions about cookies can be sent to us via the [Contact page](/contact).`;

export const defaultLegal: LegalSettings = {
  privacy,
  terms,
  cookies,
  updated: "2026-11-01",
};
