import type { BlogPost } from "@/lib/types";

export const BLOG_CATEGORIES = [
  { name: "Automation", slug: "automation" },
  { name: "Campaigns", slug: "campaigns" },
  { name: "Deliverability", slug: "deliverability" },
  { name: "Strategy", slug: "strategy" },
  { name: "Platforms", slug: "platforms" },
];

const AUTHOR = "Inboxora Digital";

type Seed = Pick<BlogPost, "title" | "slug" | "excerpt" | "category" | "content" | "featured" | "meta_description"> & {
  date: string;
};

const seeds: Seed[] = [
  {
    title: "Why Every Shopify Store Needs Email Automation",
    slug: "why-every-shopify-store-needs-email-automation",
    category: "Automation",
    featured: true,
    date: "2026-10-28",
    excerpt:
      "Automated emails reach customers at the moments they are paying attention. Here are the flows that matter most for a Shopify store and how to prioritise them.",
    meta_description:
      "Why Shopify stores need email automation, which flows to build first, and how to keep automated emails relevant as your store grows.",
    content: `Most Shopify stores start email marketing with campaigns: a newsletter here, a sale announcement there. Campaigns matter, but they only reach people when you decide to send. Automation reaches people when *they* do something, which is usually when they are most receptive.

## What email automation actually is

An automated email, or flow, is a message or series of messages triggered by a customer's action or a change in their status. Someone subscribes, adds a product to their cart, places an order or stops buying, and the right message follows without anyone pressing send.

Because the trigger is the customer's own behaviour, the message arrives with context. A cart reminder an hour after someone left is relevant in a way a weekly newsletter cannot be.

## The core flows for a Shopify store

**Welcome series.** New subscribers have just raised their hand. A short series introduces your brand, explains what makes your products different and points them to the right first purchase.

**Abandoned cart and checkout.** Shoppers leave for all sorts of reasons: distraction, comparison, uncertainty about delivery or fit. A well-timed reminder that answers those questions brings some of them back.

**Browse abandonment.** Visitors who viewed products but did not add them to a cart are showing interest. A gentle follow-up featuring what they looked at can restart the conversation.

**Post-purchase.** The period after the first order shapes whether a customer buys again. Order confirmation, delivery updates, how-to-use content and a thank-you all build confidence.

**Winback.** Customers who have not ordered in a while can be reminded of what they liked, introduced to what is new, or simply asked whether they still want to hear from you.

## Why automation pays off over time

A campaign is effort spent once for one send. A flow is effort spent once for every customer who triggers it from then on. That makes flows one of the most efficient investments in your email programme, as long as they are kept up to date.

Automation also improves the customer experience. Timely, relevant emails feel like good service rather than marketing.

## How to prioritise

If you are starting from scratch, build in this order:

1. Welcome series
2. Abandoned cart or checkout
3. Post-purchase
4. Browse abandonment
5. Winback

Then refine. Split flows by first-time and returning customers, add product-specific content, and test timing.

## Keep flows maintained

The most common problem we see is not missing flows but stale ones: old branding, discontinued products or offers that no longer exist. Review every flow at least quarterly, and check that customers are not receiving several automated emails on the same day.

## Getting started

Shopify Email includes basic automations, and platforms such as Klaviyo and Omnisend offer more advanced triggers, branching and segmentation. Whichever you use, start with the core flows, measure what they contribute and improve them steadily.

If you would like a second opinion on your current setup, our [free email audit](/free-email-audit) reviews your flows and highlights the gaps.`,
  },
  {
    title: "How to Reduce Abandoned Cart Losses",
    slug: "how-to-reduce-abandoned-cart-losses",
    category: "Automation",
    featured: true,
    date: "2026-10-21",
    excerpt:
      "Cart abandonment is normal, but much of it is recoverable. A practical guide to understanding why shoppers leave and building reminders that bring them back.",
    meta_description:
      "Practical ways to reduce abandoned cart losses with email: timing, content, offers, and on-site fixes that address why shoppers leave.",
    content: `Every online store has abandoned carts. Some shoppers were never going to buy, but many leave because of a question that went unanswered or a moment of distraction. The goal is not to eliminate abandonment but to recover the purchases that were genuinely close.

## Start with why people leave

Before writing a single reminder, think about the reasons shoppers hesitate on your store:

- Unexpected costs at checkout, such as shipping or taxes
- Uncertainty about delivery times
- Doubts about size, fit, suitability or quality
- Comparing prices or options elsewhere
- A complicated checkout or forced account creation
- Simple distraction

Some of these are best fixed on the website itself. Clear shipping information on product pages and a simple checkout reduce abandonment before email is needed.

## Build the reminder sequence

A typical abandoned cart flow has two or three emails:

**Email one, within a few hours.** A simple reminder showing the items left behind, with a clear link back to the cart. Keep it helpful rather than pushy.

**Email two, the next day.** Address the likely objection. Share reviews, explain your returns policy, answer common questions or show how the product is used.

**Email three, a day or two later.** If you use incentives, this is where to consider one. Many brands find they do not need one at all.

Test your timing rather than assuming. The right delays depend on your products and how long customers usually take to decide.

## Be careful with discounts

Offering a discount in every cart reminder teaches customers to abandon on purpose. If you do use incentives, consider limiting them to first-time customers, to higher cart values, or to the final email only.

## Personalise the content

Show the actual products, with images and prices. For higher-value or considered purchases, include information specific to that product: sizing guides, materials, care instructions or delivery estimates.

## Distinguish cart from checkout abandonment

Someone who reached the checkout and entered their email was closer to buying than someone who added an item and left. If your platform allows, treat them differently: a checkout abandoner may only need a simple reminder.

## Exclude the right people

Make sure the flow stops as soon as someone purchases, and avoid sending cart reminders alongside browse reminders or campaigns on the same day.

## Measure and improve

Track how many people enter the flow, how many click and how many complete a purchase. Test one variable at a time: subject line, timing, content order or incentive.

Our [Email Automation service](/services/email-automation) builds and optimises cart recovery flows as part of a full lifecycle programme.`,
  },
  {
    title: "Klaviyo vs Shopify Email: Which Is Right for Your Store?",
    slug: "klaviyo-vs-shopify-email",
    category: "Platforms",
    featured: true,
    date: "2026-10-14",
    excerpt:
      "Both platforms send email for Shopify stores, but they suit different stages of growth. A practical comparison of features, flexibility and when to switch.",
    meta_description:
      "Klaviyo vs Shopify Email compared for e-commerce brands: ease of use, automation, segmentation, reporting and when it makes sense to switch.",
    content: `If you run a Shopify store, you have probably considered both Shopify Email and Klaviyo. Both can send campaigns and automated emails to your customers. The right choice depends on your size, your ambitions for email, and how much time you want to invest.

This comparison focuses on capabilities rather than prices, because pricing changes regularly. Always check each provider's current pricing page.

## Shopify Email

Shopify Email is built into the Shopify admin.

**Strengths**

- Very easy to start: no separate account or integration
- Templates pull in your products and branding automatically
- Basic automations, such as welcome and abandoned checkout, are available
- Reporting sits alongside your store data

**Limitations**

- Fewer options for complex segmentation and conditional logic
- Less flexible flow building and branching
- More limited personalisation and testing compared with dedicated platforms

Shopify Email suits newer stores, smaller lists, and teams that want to send good-looking campaigns with minimal setup.

## Klaviyo

Klaviyo is a dedicated customer marketing platform with a deep Shopify integration.

**Strengths**

- Detailed segmentation based on browsing, purchase history and engagement
- Flexible flow builder with branching, filters and conditional content
- A/B testing for campaigns and flows
- Product recommendations and dynamic content
- More detailed attribution and reporting options
- SMS and other channels available in the same platform

**Limitations**

- More to learn, and more to configure well
- Costs generally increase as your contact list grows
- The extra capability only pays off if someone actively uses it

Klaviyo suits growing brands that want to treat email as a major revenue channel and have the time, or a partner, to manage it.

## How to decide

Ask yourself these questions:

1. **How large is your list, and how fast is it growing?** Small lists may not need advanced segmentation yet.
2. **Do you have the core flows in place?** If not, either platform can get you started.
3. **Do you want to personalise by behaviour or purchase history?** That favours a dedicated platform.
4. **Who will manage it?** Advanced tools need ongoing attention.

## When to switch

Signs you may be outgrowing Shopify Email include wanting to segment by product interest, needing branched flows, wanting structured A/B testing, or needing more detailed reporting.

If you do migrate, plan it carefully: map your existing flows, preserve consent records, warm up sending gradually and rebuild templates properly rather than copying them.

## Other options

Omnisend and Mautic are also worth considering. Omnisend is built for e-commerce with strong automation. Mautic is open source and suits teams that want full control and are comfortable self-hosting.

Unsure which fits your store? Our [free email audit](/free-email-audit) includes a platform recommendation.`,
  },
  {
    title: "Welcome Email Best Practices for E-commerce Brands",
    slug: "welcome-email-best-practices",
    category: "Automation",
    featured: false,
    date: "2026-10-07",
    excerpt:
      "Your welcome series is the first conversation with a new subscriber. Here is how to structure it, what to say and the mistakes to avoid.",
    meta_description:
      "Welcome email best practices for e-commerce: how many emails to send, what each should cover, timing, offers and common mistakes.",
    content: `A new subscriber has just told you they are interested. Few moments in the customer relationship carry as much attention, which is why the welcome series deserves more thought than a single "thanks for signing up" message.

## Send the first email immediately

If you promised something in exchange for the signup, such as a discount code or a guide, deliver it straight away. Delays create confusion and erode trust.

## Plan a short series, not a single email

A welcome series typically runs three to five emails over one to two weeks. Each email should have one job:

1. **Deliver and welcome.** Send what was promised and set expectations about what they will receive from you.
2. **Tell your story.** Why the brand exists, who is behind it and what makes the products different.
3. **Guide the first purchase.** Best-sellers, starter sets or a short quiz to help them choose.
4. **Build confidence.** Reviews, how products are made, delivery and returns information.
5. **Final nudge.** A reminder of any expiring offer, or a simple question about what they are looking for.

## Stop the series when they buy

Once someone places an order, move them to your post-purchase flow. Continuing to push a first-purchase offer to a new customer is a poor experience.

## Be thoughtful with discounts

Signup discounts work, but they are not the only option. Free shipping, a gift with purchase, exclusive content or early access can also motivate signups without discounting your products.

## Write like a person

Welcome emails can be warmer and more personal than campaigns. A short note from the founder, written plainly, often reads better than a heavily designed promotional layout.

## Set expectations and respect consent

Tell subscribers how often you will email and what kind of content they will get. Make unsubscribing easy. Only send marketing emails to people who have given the consent required in their country.

## Collect preferences gradually

Instead of a long signup form, ask a single question in one of the welcome emails, for example which product category interests them most. Use the answer to personalise future emails.

## Common mistakes

- Making the first email purely promotional
- Sending the whole series in two days
- Using the same welcome for customers and non-customers
- Never reviewing or updating the series

## Measure what matters

Look at click rates for each email, and at how many new subscribers go on to make a first purchase within the series window. Test one change at a time.

Need help building yours? Our [Email Automation service](/services/email-automation) includes welcome series strategy, copy and build.`,
  },
  {
    title: "How to Improve Email Deliverability",
    slug: "how-to-improve-email-deliverability",
    category: "Deliverability",
    featured: false,
    date: "2026-09-30",
    excerpt:
      "Deliverability decides whether your emails reach the inbox at all. Authentication, list hygiene and engagement are the three areas to get right.",
    meta_description:
      "How to improve email deliverability for e-commerce: SPF, DKIM and DMARC, list hygiene, engagement-based sending and monitoring.",
    content: `Deliverability is the difference between an email being sent and an email being seen. Mailbox providers such as Gmail, Yahoo and Outlook decide where each message lands, and they base that decision on who you are, how you send and how recipients respond.

## 1. Authenticate your sending domain

Authentication proves your emails really come from you.

- **SPF** lists the servers allowed to send on behalf of your domain.
- **DKIM** adds a cryptographic signature that shows the message was not altered.
- **DMARC** tells mailbox providers what to do with mail that fails those checks, and sends you reports.

Major mailbox providers now expect bulk senders to have these in place, along with easy one-click unsubscribe. Send from your own domain rather than a shared platform domain, and make sure the domain in your From address aligns with your authentication.

Start DMARC with a monitoring policy, review the reports, then move to a stricter policy once you are confident all legitimate mail is authenticated.

## 2. Grow your list with clear consent

Only email people who asked to hear from you. Avoid purchased or rented lists entirely. Use clear signup forms that state what people are signing up for, and consider double opt-in where it suits your audience or is expected in your markets.

## 3. Keep your list clean

- Remove hard bounces automatically.
- Watch for spam trap risk from old or poorly sourced addresses.
- Create a sunset policy: if someone has not engaged for an extended period, try to re-engage them, and stop emailing if they do not respond.

A smaller, engaged list usually performs better than a large, inactive one.

## 4. Send to engaged subscribers first

Mailbox providers pay attention to how recipients interact with your mail. Segment by engagement and send most often to your most engaged subscribers. Email less engaged contacts less frequently.

Note that open data has become less reliable because of privacy features in some email apps, so include clicks and purchases in your engagement definitions.

## 5. Watch complaints and bounces

Spam complaints are one of the strongest negative signals. Keep them very low by sending relevant content, making unsubscribing easy and honouring unsubscribes promptly. Gmail's Postmaster Tools and similar dashboards help you monitor reputation.

## 6. Be consistent

Sudden spikes in volume, such as sending to your whole list for the first time in months, can look suspicious. Keep a steady cadence and ramp up gradually before big seasonal pushes.

## 7. Write like a person

Avoid misleading subject lines, excessive capitalisation and image-only emails. Include a plain-text alternative and a clear way to unsubscribe.

## When to get help

If your engagement has dropped suddenly, you see rising bounces, or you are unsure whether your authentication is correct, a deliverability review can identify the cause. Our [Deliverability & List Management service](/services/deliverability-list-management) covers authentication checks, list hygiene and monitoring.`,
  },
  {
    title: "How Email Marketing Supports Customer Retention",
    slug: "how-email-marketing-supports-customer-retention",
    category: "Strategy",
    featured: false,
    date: "2026-09-23",
    excerpt:
      "Acquiring a customer is only the beginning. Email is one of the most direct ways to turn first-time buyers into repeat customers.",
    meta_description:
      "How email marketing supports customer retention for e-commerce: post-purchase journeys, replenishment, loyalty, winback and measuring repeat purchase.",
    content: `Paid acquisition gets a customer to your store once. What happens after that first order decides whether they become a loyal customer or a one-off sale. Email is one of the few channels you own that can shape that relationship directly.

## Why retention deserves attention

Returning customers already know your products and trust your brand. They need less persuasion, and their repeat purchases are often more profitable than first orders because you are not paying again to acquire them.

Email is well suited to retention because it is personal, it can be triggered by what each customer does, and you are not dependent on an algorithm to reach them.

## The retention journey

**After the first order.** The post-purchase period sets the tone. Clear order and delivery communication, guidance on getting the best out of the product, and a genuine thank-you all help.

**Before the next need.** For consumable products, replenishment reminders timed to how long a product lasts are helpful rather than pushy.

**When something new arrives.** Customers who bought from a category are often interested in new products in that category.

**When they go quiet.** A winback series can remind lapsed customers of what they liked, share what has changed, or ask for feedback.

## Use what you know

Retention email works best when it reflects the customer's history:

- What they bought, and when
- Which categories they browse
- Whether they are first-time, repeat or lapsed
- How they engage with your emails

Even simple segments, such as one-time versus repeat customers, make messages noticeably more relevant.

## Don't make every email a discount

Constant discounts can train customers to wait for sales. Retention also comes from usefulness: tips, stories, early access, loyalty recognition and good service.

## Ask for feedback

Reviews and short surveys show customers you care about their experience and give you insight you can use in future emails and products.

## Measure retention, not just campaigns

Look beyond single-campaign results to:

- Repeat purchase rate
- Time between first and second order
- Revenue from returning customers
- Revenue per recipient for retention flows

These metrics show whether email is building lasting relationships.

Our [Email Marketing Strategy service](/services/email-marketing-strategy) builds a lifecycle plan designed around retention.`,
  },
  {
    title: "Post-Purchase Email Automation: A Practical Guide",
    slug: "post-purchase-email-automation",
    category: "Automation",
    featured: false,
    date: "2026-09-16",
    excerpt:
      "The emails you send after an order shape whether customers come back. How to design a post-purchase flow that builds confidence and repeat orders.",
    meta_description:
      "A practical guide to post-purchase email automation for e-commerce: what to send, when, and how to tailor it for first-time and repeat customers.",
    content: `The moment after a purchase is when a customer is most curious about your brand and most open to hearing from you. Many stores send an order confirmation and then nothing until the next sale. A thoughtful post-purchase flow fills that gap.

## The goals of a post-purchase flow

- Reassure the customer that they made a good decision
- Help them use and enjoy the product
- Reduce support questions and avoidable returns
- Gather feedback and reviews
- Set up the next purchase at the right time

## A sample structure

**Thank you (shortly after purchase).** Separate from the transactional confirmation, a short brand-led thank-you sets the tone. For first-time customers, this can introduce the brand a little more.

**Shipping and delivery.** Transactional emails should be clear and accurate. Keep them focused on the order.

**How to use it (around delivery).** Care instructions, setup tips, recipes, styling ideas or a short video. This is often the most valued email in the series.

**Check-in and review request (after they have had time to use it).** Ask how it is going and invite a review. Time this to the product: a skincare product needs longer than a snack.

**Cross-sell or replenishment (later).** Suggest complementary products, or remind them to reorder before they run out.

## Tailor for first-time and repeat customers

First-time customers benefit from more brand introduction and guidance. Repeat customers already know you; they may prefer a shorter flow focused on new products, loyalty recognition or early access.

## Tailor by product

If your range is varied, use conditional content or separate flows for different categories. Care instructions for a jacket are no help to someone who bought a candle.

## Keep transactional and marketing separate

Order confirmations and shipping updates are transactional. Promotional content in post-purchase marketing emails should only go to customers who have consented to marketing, according to the rules in their country.

## Avoid overlap

Make sure post-purchase emails do not collide with campaigns or other flows. Suppress recent purchasers from discount-heavy campaigns where it makes sense.

## Measure it

Track click rates, review submissions, support contact volume and, most importantly, second-order rate among customers who went through the flow.

Our [Email Automation service](/services/email-automation) designs and builds post-purchase flows as part of your lifecycle programme.`,
  },
  {
    title: "Email Segmentation for E-commerce Brands",
    slug: "email-segmentation-for-ecommerce-brands",
    category: "Strategy",
    featured: false,
    date: "2026-09-09",
    excerpt:
      "Segmentation turns one message for everyone into the right message for each group. The segments worth building first, and how to keep them manageable.",
    meta_description:
      "Email segmentation for e-commerce brands: the essential segments to build, how to use them in campaigns and flows, and how to avoid over-segmenting.",
    content: `Sending every campaign to your whole list is simple, but it treats your most loyal customer and someone who signed up two years ago and never opened an email exactly the same. Segmentation lets you match the message to the relationship.

## Start with a few useful segments

You do not need dozens of segments. These cover most needs for an e-commerce brand:

**Engagement.** Group subscribers by recent clicks, site activity and purchases. Send most often to engaged contacts and less often to unengaged ones. This also protects deliverability.

**Customer status.** Subscribers who have never bought, first-time customers, repeat customers and lapsed customers each need different messages.

**Product interest.** Based on purchases or browsing, group people by category. Someone who only buys menswear does not need every womenswear launch.

**Value.** Customers who spend more or buy more often may deserve early access or special recognition.

**Location.** Useful for time zones, shipping messages, currency and local events.

## Use segments in campaigns

Before each campaign, ask who it is really for. A product launch might go first to repeat customers in that category, then to the wider engaged list. A clearance sale might exclude customers who just paid full price.

## Use segments in flows

Branch flows by customer status or category. A welcome series for someone who already purchased should look different from one for a brand-new subscriber.

## Add dynamic content

Instead of building separate campaigns for every segment, use conditional blocks that show different products or messages to different readers within the same email.

## Ask, don't just infer

Preference centres and simple one-question surveys let subscribers tell you what they want. Collect only what you will actually use, and be clear about how you will use it.

## Avoid over-segmenting

Too many overlapping segments become hard to manage and leave each group too small to learn from. Document what each segment means, review them regularly and retire the ones nobody uses.

## Measure the difference

Compare results between segmented and whole-list sends over time. Look at click rate, conversion and unsubscribe rate, not just total revenue.

Our [Segmentation & Personalisation service](/services/segmentation-personalisation) helps you build and use segments that fit your business.`,
  },
  {
    title: "Promotional Email Campaign Best Practices",
    slug: "promotional-email-campaign-best-practices",
    category: "Campaigns",
    featured: false,
    date: "2026-09-02",
    excerpt:
      "Promotions drive sales, but too many can wear out your list and your margins. How to plan, write and send promotional campaigns that work.",
    meta_description:
      "Promotional email campaign best practices: planning, offers, subject lines, design, segmentation, testing and protecting your margins.",
    content: `Promotional emails are often the most visible part of an e-commerce email programme. Done well, they create real moments of demand. Done badly, they train customers to ignore you until the next discount.

## Plan promotions in advance

Map your promotional calendar for the quarter: launches, seasonal moments, sales and restocks. Planning ahead lets you build anticipation, avoid back-to-back discounts and leave room for non-promotional content.

## Give every campaign one clear goal

Decide what you want readers to do: shop a collection, buy a specific product, claim an offer before a deadline. Everything in the email, from subject line to layout, should support that action.

## Choose offers carefully

Not every promotion needs a percentage off. Consider:

- Free shipping thresholds
- Gift with purchase
- Bundles
- Early access for subscribers or loyal customers
- Limited editions

Rotating offer types protects margins and keeps promotions feeling special.

## Write subject lines that are clear first

Clarity usually beats cleverness. Say what the email is about, and make the preview text add information rather than repeat the subject. Avoid misleading urgency.

## Design for scanning and mobile

Most people skim promotional emails on a phone. Use a clear headline, one primary call to action above the fold, real HTML text rather than text in images, and buttons large enough to tap.

## Segment your sends

Send promotions first to the people most likely to be interested: engaged subscribers and customers who bought from the relevant category. Consider excluding recent full-price purchasers from deep discounts.

## Build a sequence for bigger moments

For a major sale, a short sequence works better than one email: an announcement or early access email, a main launch, a reminder for engaged non-purchasers, and a final-hours message.

## Balance promotion and value

If every email is a sale, customers learn to wait. Mix promotions with newsletters, stories, guides and product education.

## Test and learn

Test one element at a time, such as subject line, offer framing or hero image. Record what you learn so it informs future campaigns.

## Report honestly

Look at clicks, conversions, revenue per recipient and unsubscribes together. A campaign that drives revenue but causes a spike in unsubscribes may cost more than it earns over time.

Our [Email Campaign Management service](/services/email-campaign-management) plans and runs promotional calendars for e-commerce brands.`,
  },
  {
    title: "Email Marketing Strategies for Black Friday and Cyber Monday",
    slug: "email-marketing-strategies-for-black-friday-cyber-monday",
    category: "Campaigns",
    featured: false,
    date: "2026-08-26",
    excerpt:
      "BFCM is the busiest inbox period of the year. How to prepare your list, plan your sequence and stand out without burning out your subscribers.",
    meta_description:
      "Black Friday and Cyber Monday email marketing strategies: preparing deliverability, building anticipation, segmenting, sequencing and following up.",
    content: `Black Friday and Cyber Monday bring the most competitive inbox conditions of the year. Every brand is sending more, and subscribers are deciding quickly what to open. Preparation makes the difference.

## Start preparing weeks ahead

**Check deliverability.** Confirm SPF, DKIM and DMARC are in place. Review bounce and complaint trends. If you plan to send more than usual, increase volume gradually in the weeks before rather than all at once.

**Clean your list.** Suppress long-term unengaged contacts from your main BFCM sends. Sending to people who never open can hurt placement for everyone else.

**Grow the right audience.** Use early access or a waitlist to encourage signups before the event.

## Decide your offer and story

Know exactly what you are offering, for how long, and to whom. Your offer does not have to be the deepest discount. Bundles, gifts with purchase, limited editions and early access can all stand out.

## Build anticipation

A teaser or early-access email in the days before the event warms up your audience. Inviting subscribers to join a VIP list gives you a segment of highly interested shoppers.

## Plan the sequence

A typical BFCM sequence might include:

1. Early access for VIPs or loyal customers
2. Black Friday launch
3. Reminder to engaged non-purchasers
4. Cyber Monday announcement
5. Final hours

Not every subscriber needs every email. Send the full sequence to your most engaged contacts and fewer emails to everyone else.

## Segment and exclude

Exclude recent purchasers from "don't miss out" reminders, or send them a thank-you or complementary product suggestion instead. Tailor product selection by category interest.

## Make emails easy to act on

Clear offer, clear deadline, clear button. Make sure delivery cut-off dates are visible if customers are buying gifts.

## Prepare your flows

Check that welcome, cart and browse abandonment flows reflect your BFCM offer, or are paused if their usual offers would conflict.

## Have a plan for after

Post-BFCM is a chance to start relationships with new customers. Use your post-purchase flow to welcome them properly, and plan a holiday gifting sequence that does not rely only on discounts.

## Review honestly

Afterwards, review revenue per recipient, unsubscribes, complaints and the share of new versus returning customers. Note what to change for next year while it is fresh.

Planning for the season? Our [free email audit](/free-email-audit) can check your readiness before the rush.`,
  },
];

export function readingTime(markdown: string) {
  const words = markdown.trim().split(/\s+/).length;
  return Math.max(1, Math.round(words / 225));
}

export const SEED_POSTS: BlogPost[] = seeds.map((s) => ({
  id: `seed-${s.slug}`,
  title: s.title,
  slug: s.slug,
  excerpt: s.excerpt,
  content: s.content,
  category: s.category,
  author: AUTHOR,
  featured: s.featured,
  featured_image: null,
  seo_title: null,
  meta_description: s.meta_description,
  publication_status: "published",
  published_at: `${s.date}T09:00:00.000Z`,
}));
