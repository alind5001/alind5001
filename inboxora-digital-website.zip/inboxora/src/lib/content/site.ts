import type { SiteSettings } from "@/lib/types";
import { defaultLegal } from "./legal";

export const SITE = {
  name: "Inboxora Digital",
  tagline: "Emails that connect. Marketing that converts.",
  positioning: "Email Marketing, Lifecycle Automation & Customer Retention",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, ""),
  description:
    "Inboxora Digital is an e-commerce email marketing agency helping Shopify and D2C brands grow repeat revenue through email campaigns, lifecycle automation, Klaviyo email marketing services and customer retention strategy.",
  targetMarkets: ["United States", "United Kingdom", "Australia", "Canada", "United Arab Emirates", "India"],
};

export const NAV = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/industries", label: "Industries" },
  { href: "/work", label: "Our Work" },
  { href: "/pricing", label: "Pricing" },
  { href: "/insights", label: "Insights" },
  { href: "/contact", label: "Contact" },
];

export const COUNTRIES = [
  "United States",
  "United Kingdom",
  "Australia",
  "Canada",
  "United Arab Emirates",
  "India",
  "New Zealand",
  "Ireland",
  "Singapore",
  "Germany",
  "France",
  "Netherlands",
  "Saudi Arabia",
  "South Africa",
  "Other",
];

export const INDUSTRY_OPTIONS = [
  "Fashion & Apparel",
  "Beauty & Skincare",
  "Jewellery & Accessories",
  "Food & Beverage",
  "Home & Lifestyle",
  "Health & Wellness",
  "Pet Supplies",
  "Industrial & B2B Products",
  "Other",
];

export const PLATFORM_OPTIONS = [
  "Klaviyo",
  "Shopify Email",
  "Omnisend",
  "Mailchimp",
  "Mautic",
  "Other",
  "Not Currently Using Email Marketing",
];

export const SUBSCRIBER_OPTIONS = [
  "Below 1,000",
  "1,000–5,000",
  "5,000–10,000",
  "10,000–50,000",
  "50,000–100,000",
  "Above 100,000",
  "Not Sure",
];

export const BUDGET_OPTIONS = ["Below $250", "$250–$500", "$500–$1,000", "$1,000–$2,500", "Above $2,500", "Not Decided"];

export const PORTFOLIO_CATEGORIES = [
  "Promotional Campaigns",
  "Welcome Emails",
  "Abandoned Cart",
  "Browse Abandonment",
  "Product Launches",
  "Newsletters",
  "Seasonal Campaigns",
  "Email Automation",
];

export const PLATFORMS = [
  { name: "Klaviyo", note: "Flows, segmentation and campaign reporting" },
  { name: "Shopify Email", note: "Native campaigns for Shopify stores" },
  { name: "Omnisend", note: "Email and automation for e-commerce" },
  { name: "Mautic", note: "Open-source marketing automation" },
];

export const defaultSettings: SiteSettings = {
  contact: {
    businessName: "Inboxora Digital",
    email: "hello@YOUR-DOMAIN.com",
    phone: "+91 7355309230",
    whatsapp: "917355309230",
    location: "Lucknow, Uttar Pradesh, India",
    operatingModel: "Remote-first",
  },
  social: { linkedin: "", instagram: "", x: "", facebook: "" },
  stats: {
    items: [
      {
        value: "20–25%",
        label: "Email-attributed share of revenue",
        detail: "Reported email-attributed share of overall revenue across the relevant client projects.",
      },
      {
        value: "90 days",
        label: "Measurement period",
        detail: "Reported project execution and measurement period.",
      },
      {
        value: "6 brands",
        label: "Selected client experiences",
        detail: "Selected professional client experiences.",
      },
    ],
    summary:
      "Across the relevant projects, email marketing accounted for approximately 20–25% of overall revenue during the reported 90-day execution period.",
    disclosure:
      "Figures represent aggregate reported historical attribution across the relevant projects. Attribution methodologies, platforms and reporting windows may differ. Results are not independently audited by Inboxora Digital and should not be interpreted as a guarantee of future performance.",
  },
  pricing: {
    packages: [
      {
        id: "essentials",
        name: "Email Essentials",
        price: "$249",
        period: "/month",
        description: "A dependable monthly campaign rhythm for brands getting email off the ground.",
        features: [
          "4 email campaigns monthly",
          "Email template design",
          "Campaign scheduling",
          "Basic performance reporting",
          "Monthly consultation",
        ],
        cta: "Get Started",
        ctaHref: "/contact?plan=Email%20Essentials",
        highlighted: false,
      },
      {
        id: "growth",
        name: "Email Growth",
        price: "$499",
        period: "/month",
        description: "More campaigns plus your first automated journeys, built around your segments.",
        features: [
          "8 email campaigns monthly",
          "Two initial automation flows",
          "Audience segmentation",
          "Email design and copywriting",
          "Performance reporting",
          "Campaign optimisation",
        ],
        cta: "Choose Growth",
        ctaHref: "/contact?plan=Email%20Growth",
        highlighted: true,
      },
      {
        id: "revenue",
        name: "Email Revenue Management",
        price: "$899",
        period: "/month",
        description: "Full ownership of your email channel, from campaigns to flows to deliverability.",
        features: [
          "12 email campaigns monthly",
          "Automation management",
          "Advanced segmentation",
          "Email performance analysis",
          "Deliverability monitoring",
          "Monthly strategy consultation",
        ],
        cta: "Request a Proposal",
        ctaHref: "/contact?plan=Email%20Revenue%20Management",
        highlighted: false,
      },
    ],
    notes: [
      "Third-party software subscriptions are not included.",
      "Custom integrations may be charged separately.",
      "Large migrations and advanced flow implementations require separate quotations.",
      "Scope and deliverables will be finalised before onboarding.",
      "No guaranteed revenue or sales promises.",
    ],
  },
  services: {
    items: [
      {
        slug: "email-campaign-management",
        title: "Email Campaign Management",
        shortTitle: "Campaign Management",
        summary: "Planned, designed and scheduled campaigns that keep your brand in the inbox with a reason to open.",
        bullets: [
          "Promotional campaigns",
          "Weekly newsletters",
          "Product launches",
          "Seasonal campaigns",
          "BFCM campaigns",
          "Campaign scheduling",
          "Campaign performance reporting",
        ],
        active: true,
        onHome: true,
        order: 1,
      },
      {
        slug: "email-automation",
        title: "Email Automation & Lifecycle Marketing",
        shortTitle: "Email Automation",
        summary: "Automated journeys that greet, recover, thank and win back customers at the moments that matter.",
        bullets: [
          "Welcome series",
          "Abandoned cart",
          "Browse abandonment",
          "Post-purchase automation",
          "Winback campaigns",
          "Replenishment reminders",
          "Customer lifecycle automation",
        ],
        active: true,
        onHome: true,
        order: 2,
      },
      {
        slug: "email-design-development",
        title: "Email Design & HTML Development",
        shortTitle: "Email Design & Development",
        summary: "On-brand templates coded to render cleanly across inboxes, devices and dark mode.",
        bullets: [
          "Custom HTML email templates",
          "Responsive email designs",
          "Promotional email banners",
          "Newsletter development",
          "Branded templates",
          "Mobile email optimisation",
        ],
        active: true,
        onHome: true,
        order: 3,
      },
      {
        slug: "email-marketing-strategy",
        title: "Email Marketing Strategy",
        shortTitle: "Email Marketing Strategy",
        summary: "An audit-led plan for what to send, to whom and when, tied to your commercial calendar.",
        bullets: [
          "Email marketing audits",
          "Campaign planning",
          "Customer lifecycle strategy",
          "Audience segmentation",
          "Personalisation",
          "A/B testing",
        ],
        active: true,
        onHome: true,
        order: 4,
      },
      {
        slug: "segmentation-personalisation",
        title: "Segmentation & Personalisation",
        shortTitle: "Segmentation & Personalisation",
        summary: "Audiences built from real behaviour, so each customer gets the message that fits them.",
        bullets: [
          "Behavioural segments",
          "Purchase-history segments",
          "Engagement tiers",
          "Dynamic content blocks",
          "Product recommendations",
          "Preference centres",
        ],
        active: true,
        onHome: false,
        order: 5,
      },
      {
        slug: "deliverability-list-management",
        title: "Deliverability & List Management",
        shortTitle: "Deliverability & List Management",
        summary: "Authentication, hygiene and monitoring that help your emails reach the inbox, not the spam folder.",
        bullets: [
          "Email authentication review",
          "SPF, DKIM and DMARC checks",
          "List hygiene",
          "Bounce monitoring",
          "Spam complaint monitoring",
          "Consent and subscription management",
        ],
        active: true,
        onHome: true,
        order: 6,
      },
      {
        slug: "analytics-performance-reporting",
        title: "Analytics & Performance Reporting",
        shortTitle: "Analytics & Reporting",
        summary: "Clear reporting that connects email activity to revenue and tells you what to do next.",
        bullets: [
          "Revenue attribution analysis",
          "Campaign performance reporting",
          "Click-through analysis",
          "Conversion tracking",
          "Revenue per recipient",
          "Customer retention insights",
        ],
        active: true,
        onHome: true,
        order: 7,
      },
      // Future services: hidden until genuinely available. Enable in Admin → Settings → Services.
      ...[
        "Meta Ads Management",
        "Google Ads",
        "Social Media Marketing",
        "CRM Management",
        "SMS Marketing",
        "Conversion Rate Optimisation",
        "Shopify Store Optimisation",
        "Marketing Automation",
      ].map((title, i) => ({
        slug: title.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        title,
        shortTitle: title,
        summary: "",
        bullets: [] as string[],
        active: false,
        onHome: false,
        order: 100 + i,
      })),
    ],
  },
  legal: defaultLegal,
};

export function whatsappHref(digits: string) {
  return `https://wa.me/${digits.replace(/\D/g, "")}`;
}
export function telHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}
