import type { PortfolioProject } from "@/lib/types";

// Founder-led project experience. Facts are limited to what the agency has confirmed:
// brand, website, industry, country and the categories of work delivered.
// Do not add metrics, screenshots or quotes here unless they are verified and permitted.

const ATTRIBUTION = "Selected Client Experience — Founder-Led Project Work";

type Seed = Omit<PortfolioProject, "id" | "attribution" | "publication_status" | "verified_results" | "images">;

const seeds: Seed[] = [
  {
    slug: "coffeecakes",
    brand_name: "CoffeeCakes.com",
    website: "https://coffeecakes.com/",
    industry: "Gourmet Food & Gifting",
    country: "USA",
    description:
      "Promotional, seasonal and product-focused email work for a US gourmet food and gifting brand.",
    services: [
      "Promotional email campaigns",
      "Seasonal email marketing",
      "Product-focused newsletters",
      "Email design and development",
      "Customer engagement",
      "Campaign performance reporting",
    ],
    categories: ["Promotional Campaigns", "Seasonal Campaigns", "Newsletters"],
    case_study: {
      overview:
        "CoffeeCakes.com is a US-based gourmet food and gifting brand. The founder's project work covered campaign planning, design and reporting across promotional and seasonal email.",
      context:
        "Gourmet food and gifting brands see demand concentrate around holidays and gifting occasions, so email needs to build anticipation early and communicate clearly when orders need to be placed.",
      objectives: [
        "Keep subscribers engaged with the product range between peak gifting periods",
        "Support seasonal and holiday demand with planned campaigns",
        "Present products clearly through on-brand email design",
        "Track and report on campaign performance",
      ],
      strategy:
        "A campaign calendar combining product-focused newsletters with seasonal promotional pushes, supported by consistent email design and regular performance reporting.",
      workExecuted: [
        "Promotional email campaigns",
        "Seasonal email marketing",
        "Product-focused newsletters",
        "Email design and development",
        "Customer engagement emails",
        "Campaign performance reporting",
      ],
      campaignExamples: ["Seasonal gifting campaigns", "Product-focused newsletters", "Promotional offers"],
      automationExamples: [],
    },
    sort_order: 1,
  },
  {
    slug: "thornado-australia",
    brand_name: "Thornado Australia",
    website: "https://thornado.com.au/",
    industry: "Industrial Equipment & Products",
    country: "Australia",
    description:
      "Brand storytelling, product discovery and re-engagement email work for an Australian industrial equipment brand.",
    services: [
      "Brand storytelling",
      "Product discovery campaigns",
      "Promotional email campaigns",
      "Customer re-engagement",
      "Product-focused communication",
    ],
    categories: ["Promotional Campaigns", "Product Launches", "Email Automation"],
    case_study: {
      overview:
        "Thornado Australia is an Australian brand in industrial equipment and products. The founder's project work focused on product discovery, brand storytelling and re-engaging existing customers.",
      context:
        "Industrial product buyers tend to research carefully before purchasing, so email works best when it helps them understand products and how they are used, not only when it promotes an offer.",
      objectives: [
        "Help subscribers discover the product range",
        "Communicate the brand's story and product value",
        "Re-engage customers who had gone quiet",
        "Support promotional periods with clear product messaging",
      ],
      strategy:
        "Product-led communication that pairs brand storytelling with discovery campaigns, plus re-engagement messaging for lapsed customers.",
      workExecuted: [
        "Brand storytelling emails",
        "Product discovery campaigns",
        "Promotional email campaigns",
        "Customer re-engagement",
        "Product-focused communication",
      ],
      campaignExamples: ["Product discovery campaigns", "Brand story emails", "Promotional campaigns"],
      automationExamples: ["Customer re-engagement messaging"],
    },
    sort_order: 2,
  },
  {
    slug: "bare-tallow-co",
    brand_name: "Bare Tallow Co.",
    website: "https://baretallow.co/",
    industry: "Natural Skincare & Personal Care",
    country: "USA",
    description:
      "Product education, blog notification and promotional email work for a US natural skincare brand.",
    services: [
      "Product education emails",
      "Blog notification emails",
      "Promotional campaigns",
      "Customer engagement",
      "Brand storytelling",
    ],
    categories: ["Newsletters", "Promotional Campaigns"],
    case_study: {
      overview:
        "Bare Tallow Co. is a US natural skincare and personal care brand. The founder's project work combined product education with content-led and promotional email.",
      context:
        "Natural skincare customers often want to understand ingredients and how to use products before committing, which makes educational content a natural fit for email.",
      objectives: [
        "Educate subscribers about products and their use",
        "Drive readers to the brand's blog content",
        "Support promotional periods",
        "Strengthen the brand story and customer engagement",
      ],
      strategy:
        "An education-first programme mixing product education emails and blog notifications with promotional campaigns and brand storytelling.",
      workExecuted: [
        "Product education emails",
        "Blog notification emails",
        "Promotional campaigns",
        "Customer engagement emails",
        "Brand storytelling",
      ],
      campaignExamples: ["Product education emails", "Blog notification emails", "Promotional campaigns"],
      automationExamples: [],
    },
    sort_order: 3,
  },
  {
    slug: "boones-bay",
    brand_name: "Boone's Bay",
    website: "https://boonesbay.com/",
    industry: "Apparel & Outdoor Lifestyle",
    country: "USA",
    description:
      "Collection launch, seasonal and product discovery email work for a US apparel and outdoor lifestyle brand.",
    services: [
      "Collection launches",
      "Promotional email campaigns",
      "Seasonal campaigns",
      "Product discovery",
      "Customer engagement",
    ],
    categories: ["Product Launches", "Seasonal Campaigns", "Promotional Campaigns"],
    case_study: {
      overview:
        "Boone's Bay is a US apparel and outdoor lifestyle brand. The founder's project work centred on collection launches, seasonal campaigns and product discovery.",
      context:
        "Apparel brands rely on new collections and seasonal moments to give customers a reason to return, and email is where those launches are first announced to the most engaged audience.",
      objectives: [
        "Launch new collections to subscribers",
        "Plan campaigns around seasonal moments",
        "Help customers discover more of the range",
        "Keep the audience engaged between launches",
      ],
      strategy:
        "A launch-and-season rhythm: collection reveals and seasonal campaigns supported by product discovery and promotional emails.",
      workExecuted: [
        "Collection launch emails",
        "Promotional email campaigns",
        "Seasonal campaigns",
        "Product discovery emails",
        "Customer engagement emails",
      ],
      campaignExamples: ["Collection launches", "Seasonal campaigns", "Product discovery emails"],
      automationExamples: [],
    },
    sort_order: 4,
  },
  {
    slug: "cheryls-herbs",
    brand_name: "Cheryl's Herbs",
    website: "https://cherylsherbs.com/",
    industry: "Herbal & Wellness Retail",
    country: "USA",
    description:
      "Product-focused, promotional and retention-focused email work for a US herbal and wellness retailer.",
    services: [
      "Product-focused campaigns",
      "Promotional email communication",
      "Customer engagement",
      "Retention-focused messaging",
    ],
    categories: ["Promotional Campaigns", "Email Automation"],
    case_study: {
      overview:
        "Cheryl's Herbs is a US herbal and wellness retailer. The founder's project work covered product-focused and promotional email with an emphasis on retention.",
      context:
        "Wellness retail depends on trust and repeat purchases, so communication needs to be clear, responsible and consistent rather than purely promotional.",
      objectives: [
        "Highlight products clearly and responsibly",
        "Support promotional periods",
        "Keep customers engaged with the brand",
        "Encourage repeat purchases through retention messaging",
      ],
      strategy:
        "Product-focused campaigns and promotional communication, balanced with engagement and retention-focused messaging for existing customers.",
      workExecuted: [
        "Product-focused campaigns",
        "Promotional email communication",
        "Customer engagement emails",
        "Retention-focused messaging",
      ],
      campaignExamples: ["Product-focused campaigns", "Promotional emails"],
      automationExamples: ["Retention-focused messaging"],
    },
    sort_order: 5,
  },
  {
    slug: "solis-lifestyle",
    brand_name: "Solis Lifestyle",
    website: "https://solislifestyle.com/",
    industry: "Lifestyle & Nutrition",
    country: "UAE",
    description:
      "Product discovery, promotional and brand communication email work for a UAE lifestyle and nutrition brand.",
    services: [
      "Product discovery",
      "Promotional campaigns",
      "Brand communication",
      "Customer engagement",
      "Retention-focused messaging",
    ],
    categories: ["Promotional Campaigns", "Product Launches", "Email Automation"],
    case_study: {
      overview:
        "Solis Lifestyle is a lifestyle and nutrition brand based in the UAE. The founder's project work covered product discovery, promotions and brand communication.",
      context:
        "Lifestyle and nutrition customers respond to clear product information and a consistent brand voice, and repeat purchases matter as products are used up.",
      objectives: [
        "Introduce subscribers to the product range",
        "Support promotional campaigns",
        "Communicate the brand consistently",
        "Encourage repeat engagement and purchases",
      ],
      strategy:
        "Product discovery and brand communication supported by promotional campaigns and retention-focused messaging.",
      workExecuted: [
        "Product discovery emails",
        "Promotional campaigns",
        "Brand communication",
        "Customer engagement emails",
        "Retention-focused messaging",
      ],
      campaignExamples: ["Product discovery emails", "Promotional campaigns", "Brand communication"],
      automationExamples: ["Retention-focused messaging"],
    },
    sort_order: 6,
  },
];

export const SEED_PROJECTS: PortfolioProject[] = seeds.map((s) => ({
  ...s,
  id: `seed-${s.slug}`,
  attribution: ATTRIBUTION,
  publication_status: "published",
  verified_results: null,
  images: [],
}));

export { ATTRIBUTION };
