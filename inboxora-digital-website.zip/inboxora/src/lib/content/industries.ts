export type Industry = {
  slug: string;
  name: string;
  card: string; // homepage summary
  journey: string;
  opportunities: string[];
  campaigns: string[];
  flows: string[];
  retention: string;
};

export const INDUSTRIES: Industry[] = [
  {
    slug: "fashion-apparel",
    name: "Fashion & Apparel",
    card: "New drops, restocks and styling ideas give shoppers a reason to come back between seasons.",
    journey:
      "Shoppers often discover a brand through social media, browse several items, and hesitate over size and fit before buying. After the first order, the relationship depends on new collections and a sense of personal style.",
    opportunities: [
      "Size and fit reassurance during browse and cart abandonment",
      "Collection storytelling that goes beyond the discount",
      "Back-in-stock and low-stock alerts for wanted items",
    ],
    campaigns: ["Collection launches", "Lookbooks and styling guides", "End-of-season sales", "Restock announcements"],
    flows: ["Welcome series with brand story", "Browse abandonment by category", "Abandoned cart with fit guidance", "Post-purchase care and styling"],
    retention:
      "Use purchase history to suggest complementary pieces, and segment by category so customers hear about the drops they actually care about.",
  },
  {
    slug: "beauty-skincare",
    name: "Beauty & Skincare",
    card: "Education builds trust in ingredients and routines, and replenishment timing drives the next order.",
    journey:
      "Beauty customers research ingredients and suitability before trying something new. Once a product works for them, they repurchase on a predictable cycle and are open to adding steps to their routine.",
    opportunities: [
      "Ingredient and routine education for new subscribers",
      "Usage tips in the days after delivery",
      "Replenishment reminders timed to product size",
    ],
    campaigns: ["Ingredient spotlights", "Routine builders", "New product launches", "Gift sets and seasonal bundles"],
    flows: ["Educational welcome series", "Post-purchase how-to-use", "Replenishment reminders", "Cross-sell to complete the routine"],
    retention:
      "Replenishment and routine-building flows turn a single trial into a habit, while education reduces returns and builds confidence.",
  },
  {
    slug: "jewellery-accessories",
    name: "Jewellery & Accessories",
    card: "Considered purchases and gifting moments reward patient nurturing and well-timed reminders.",
    journey:
      "Jewellery is often a considered or gift purchase with a longer decision window. Shoppers compare pieces, return several times, and buy around occasions like birthdays, anniversaries and holidays.",
    opportunities: [
      "Nurture sequences for long consideration windows",
      "Gift guides ahead of key occasions",
      "Craftsmanship and materials storytelling",
    ],
    campaigns: ["Gift guides", "New collection reveals", "Occasion reminders", "Care and styling content"],
    flows: ["Welcome series with brand craft", "Extended browse abandonment", "Post-purchase care guide", "Anniversary and occasion reminders"],
    retention:
      "Capture occasion dates where customers choose to share them, and follow up gift purchases with self-purchase inspiration.",
  },
  {
    slug: "food-beverage",
    name: "Food & Beverage",
    card: "Seasonal menus, gifting and repeat consumption make email a natural channel for reorders.",
    journey:
      "Food and drink customers often buy for themselves and as gifts. Products are consumed and reordered, and demand rises around holidays and seasonal moments.",
    opportunities: [
      "Gifting campaigns ahead of holidays with clear order-by dates",
      "Reorder reminders timed to consumption",
      "Recipes, pairings and origin stories",
    ],
    campaigns: ["Holiday gifting", "Seasonal and limited editions", "Recipes and serving ideas", "Corporate gifting"],
    flows: ["Welcome series with best-sellers", "Abandoned cart with delivery dates", "Reorder reminders", "Gift recipient follow-up"],
    retention:
      "Separate gifters from self-purchasers, and use reorder timing and seasonal calendars to bring customers back at the right moment.",
  },
  {
    slug: "home-lifestyle",
    name: "Home & Lifestyle",
    card: "Inspiration and room-by-room ideas help customers picture your products in their space.",
    journey:
      "Home and lifestyle purchases are driven by inspiration. Customers save ideas, return to compare, and often furnish or refresh a space over several orders.",
    opportunities: [
      "Inspiration content that shows products in context",
      "Complementary product suggestions after purchase",
      "Seasonal refresh campaigns",
    ],
    campaigns: ["Room and style guides", "Seasonal refreshes", "New arrivals", "Bundles and sets"],
    flows: ["Inspiration-led welcome", "Browse abandonment by room or category", "Post-purchase care and pairing", "Winback with new arrivals"],
    retention:
      "Use first-purchase category to suggest what completes the look, and keep lapsed customers engaged with new-arrival inspiration.",
  },
  {
    slug: "health-wellness",
    name: "Health & Wellness",
    card: "Trust, education and consistent routines matter more than urgency in this category.",
    journey:
      "Wellness customers want to understand what a product does and whether it suits them before buying. Ongoing use and routine are central to whether they stay.",
    opportunities: [
      "Clear, responsible product education",
      "Onboarding that supports consistent use",
      "Subscription and replenishment nudges",
    ],
    campaigns: ["Product education", "Founder and sourcing stories", "Seasonal wellness themes", "New product introductions"],
    flows: ["Educational welcome", "Post-purchase onboarding", "Replenishment reminders", "Subscription save flows"],
    retention:
      "Supportive onboarding and well-timed replenishment help customers stay consistent. Copy should avoid unsupported health claims.",
  },
  {
    slug: "pet-supplies",
    name: "Pet Supplies",
    card: "Pet owners reorder food and essentials on a rhythm that email can match closely.",
    journey:
      "Pet owners buy essentials repeatedly and treats or accessories occasionally. Knowing the type and age of the pet makes communication far more relevant.",
    opportunities: [
      "Collecting pet type and life stage with consent",
      "Reorder reminders for food and essentials",
      "Celebrating pet birthdays and milestones",
    ],
    campaigns: ["New treats and toys", "Seasonal care tips", "Pet birthday offers", "Bundles"],
    flows: ["Welcome with pet preference capture", "Reorder reminders", "Post-purchase tips", "Winback for lapsed reorders"],
    retention:
      "Segment by pet type and life stage, and match reorder reminders to how quickly each product is used.",
  },
  {
    slug: "industrial-b2b",
    name: "Industrial & B2B Products",
    card: "Longer buying cycles call for product education, specifications and steady relationship building.",
    journey:
      "Industrial and B2B buyers research specifications, compare options and may need approval before purchasing. Repeat orders often come from trust in product quality and support.",
    opportunities: [
      "Product discovery and specification content",
      "Application stories that show products in use",
      "Re-engagement for quiet accounts",
    ],
    campaigns: ["Product spotlights", "Application and how-to content", "New range announcements", "Trade and seasonal offers"],
    flows: ["Welcome with product range overview", "Quote and cart follow-up", "Post-purchase support", "Re-engagement for lapsed buyers"],
    retention:
      "Useful technical content and timely re-engagement keep your brand front of mind for the next purchase decision.",
  },
];
