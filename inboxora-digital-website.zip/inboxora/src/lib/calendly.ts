import "server-only";
import { createServiceClient } from "@/lib/supabase/service";
import { acknowledgement, internalNotification, sendEmail } from "@/lib/email";
import { getSettings } from "@/lib/data";
import { adminLink } from "@/lib/forms/respond";

type CalEvent = { resource: { uri: string; name: string; start_time: string; end_time: string; status: string; location?: { join_url?: string } } };
type CalInvitee = { resource: { uri: string; name: string; email: string; timezone: string; status: string; questions_and_answers?: { question: string; answer: string }[] } };

async function cal<T>(uri: string): Promise<T | null> {
  const token = process.env.CALENDLY_API_TOKEN;
  if (!token) return null;
  const res = await fetch(uri, { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
  if (!res.ok) {
    console.error("[calendly] fetch failed", res.status);
    return null;
  }
  return (await res.json()) as T;
}

/**
 * Looks up a booking in Calendly's API (so the data is trusted, not taken from the browser),
 * stores it once, and sends our own confirmation alongside Calendly's.
 */
export async function recordCalendlyBooking(eventUri: string, inviteeUri: string, extra: { company?: string; website?: string } = {}) {
  const sb = createServiceClient();
  if (!sb) return { ok: false as const, status: 503, error: "Booking storage is not configured." };
  const [ev, inv] = await Promise.all([cal<CalEvent>(eventUri), cal<CalInvitee>(inviteeUri)]);
  if (!ev || !inv) return { ok: false as const, status: 502, error: "Could not verify the booking with Calendly." };

  const answers = inv.resource.questions_and_answers ?? [];
  const find = (re: RegExp) => answers.find((a) => re.test(a.question))?.answer;
  const requirements = answers.map((a) => `${a.question}: ${a.answer}`).join("\n") || null;

  const { data: existing } = await sb.from("bookings").select("id").eq("calendly_event_uri", eventUri).maybeSingle();
  if (existing) return { ok: true as const, duplicate: true };

  const record = {
    name: inv.resource.name,
    email: inv.resource.email.toLowerCase(),
    company: extra.company || find(/company|business/i) || null,
    website: extra.website || find(/website|url|store/i) || null,
    scheduled_at: ev.resource.start_time,
    timezone: inv.resource.timezone,
    requirements,
    meeting_status: "scheduled",
    source: "calendly",
    calendly_event_uri: eventUri,
    calendly_invitee_uri: inviteeUri,
    status: "Discovery Call Scheduled",
  };
  const { data: row, error } = await sb.from("bookings").insert(record).select("id").single();
  if (error) {
    if (error.code === "23505") return { ok: true as const, duplicate: true }; // stored by webhook in parallel
    console.error("[calendly] insert failed", error.message);
    return { ok: false as const, status: 500, error: "Could not store the booking." };
  }

  const { contact } = await getSettings();
  const when = new Date(ev.resource.start_time);
  const local = when.toLocaleString("en-GB", { timeZone: inv.resource.timezone, dateStyle: "full", timeStyle: "short" });
  const note = internalNotification(
    "discovery call booking",
    { Name: record.name, Email: record.email, Company: record.company, Website: record.website, When: `${local} (${record.timezone})`, Answers: requirements },
    adminLink(`/admin/leads?source=booking&id=${row.id}`)
  );
  const ack = acknowledgement({
    name: record.name,
    heading: "Your discovery call is booked",
    lines: [
      `Thanks for booking a 30-minute discovery call with Inboxora Digital on ${local} (${record.timezone}).`,
      "Calendly has sent your calendar invitation with the meeting link. If you need to reschedule, use the link in that invitation.",
      "Before the call, it helps if you can think about your main goal for email over the next few months. No preparation is required.",
    ],
    contactEmail: contact.email,
  });
  await Promise.all([
    sendEmail({ to: process.env.AGENCY_NOTIFICATION_EMAIL || contact.email, replyTo: record.email, ...note }),
    sendEmail({ to: record.email, subject: "Your discovery call is confirmed | Inboxora Digital", ...ack }),
  ]);
  return { ok: true as const };
}

export async function markCalendlyCancelled(eventUri: string) {
  const sb = createServiceClient();
  if (!sb) return;
  await sb.from("bookings").update({ meeting_status: "cancelled" }).eq("calendly_event_uri", eventUri);
}
