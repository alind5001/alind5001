import "server-only";
import { isResendConfigured } from "@/lib/env";

export function esc(v: unknown) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

type SendArgs = { to: string; subject: string; html: string; text: string; replyTo?: string };

/** Sends via Resend's REST API. Returns false (and logs) if not configured or on failure. */
export async function sendEmail(args: SendArgs): Promise<boolean> {
  if (!isResendConfigured()) {
    console.warn(`[email] Resend not configured; skipped "${args.subject}" to ${args.to.replace(/(.{2}).+@/, "$1***@")}`);
    return false;
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM,
        to: [args.to],
        subject: args.subject,
        html: args.html,
        text: args.text,
        ...(args.replyTo ? { reply_to: args.replyTo } : {}),
      }),
      cache: "no-store",
    });
    if (!res.ok) console.error("[email] Resend error", res.status, await res.text().catch(() => ""));
    return res.ok;
  } catch (e) {
    console.error("[email] Resend request failed", e);
    return false;
  }
}

function shell(title: string, body: string) {
  return `<!doctype html><html><body style="margin:0;background:#F8FAFC;font-family:Inter,Arial,sans-serif;color:#101828">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="100%" style="max-width:560px;background:#fff;border:1px solid #E5E7EB;border-radius:16px" cellpadding="0" cellspacing="0">
<tr><td style="padding:28px 32px 0"><p style="margin:0;font-weight:800;letter-spacing:.08em;font-size:13px;color:#101828">INBOXORA <span style="color:#667085">DIGITAL</span></p></td></tr>
<tr><td style="padding:20px 32px 32px"><h1 style="font-size:22px;line-height:1.3;margin:0 0 16px">${esc(title)}</h1>${body}</td></tr>
</table>
<p style="font-size:12px;color:#667085;margin:16px 0 0">Inboxora Digital · Remote-first email marketing agency · Lucknow, India</p>
</td></tr></table></body></html>`;
}

function rows(data: Record<string, unknown>) {
  return `<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;font-size:14px">${Object.entries(data)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(
      ([k, v]) =>
        `<tr><td style="padding:8px 12px 8px 0;color:#667085;vertical-align:top;white-space:nowrap;border-top:1px solid #E5E7EB">${esc(k)}</td><td style="padding:8px 0;border-top:1px solid #E5E7EB;white-space:pre-wrap">${esc(v)}</td></tr>`
    )
    .join("")}</table>`;
}

function textRows(data: Record<string, unknown>) {
  return Object.entries(data)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${k}: ${v}`)
    .join("\n");
}

export function internalNotification(kind: string, data: Record<string, unknown>, adminUrl: string) {
  const subject = `New ${kind}: ${data["Name"]} (${data["Company"] ?? ""})`;
  return {
    subject,
    html: shell(`New ${kind}`, `${rows(data)}<p style="margin:24px 0 0"><a href="${esc(adminUrl)}" style="background:#101828;color:#fff;padding:10px 18px;border-radius:999px;text-decoration:none;font-weight:600;font-size:14px">Open in admin</a></p>`),
    text: `New ${kind}\n\n${textRows(data)}\n\nOpen in admin: ${adminUrl}`,
  };
}

export function acknowledgement(opts: { name: string; heading: string; lines: string[]; contactEmail: string }) {
  const first = opts.name.split(" ")[0];
  const html = shell(
    opts.heading,
    `<p style="font-size:15px;line-height:1.6;margin:0 0 12px">Hi ${esc(first)},</p>${opts.lines
      .map((l) => `<p style="font-size:15px;line-height:1.6;margin:0 0 12px">${esc(l)}</p>`)
      .join("")}<p style="font-size:15px;line-height:1.6;margin:16px 0 0">Best regards,<br/>Inboxora Digital</p>
<p style="font-size:12px;line-height:1.5;color:#667085;margin:24px 0 0">You're receiving this one-time confirmation because you submitted a form on our website. We haven't added you to any mailing list. Questions? Reply to this email or write to ${esc(opts.contactEmail)}.</p>`
  );
  const text = `Hi ${first},\n\n${opts.lines.join("\n\n")}\n\nBest regards,\nInboxora Digital\n\nYou're receiving this one-time confirmation because you submitted a form on our website. We haven't added you to any mailing list.`;
  return { html, text };
}
