import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

/** Keeps the admin session fresh and blocks /admin for anyone who isn't signed-in staff. */
export async function middleware(req: NextRequest) {
  const res = NextResponse.next({ request: req });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const isLogin = req.nextUrl.pathname === "/admin/login";

  if (!url || !key) {
    if (isLogin) return res;
    return NextResponse.redirect(new URL("/admin/login?setup=1", req.url));
  }

  const supabase = createServerClient(url, key, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (toSet) => {
        toSet.forEach(({ name, value }) => req.cookies.set(name, value));
        toSet.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
      },
    },
  });
  const { data: { user } } = await supabase.auth.getUser();

  if (isLogin) {
    return user ? NextResponse.redirect(new URL("/admin", req.url)) : res;
  }
  if (!user) {
    const to = new URL("/admin/login", req.url);
    to.searchParams.set("next", req.nextUrl.pathname);
    return NextResponse.redirect(to);
  }
  const { data: staff } = await supabase.rpc("is_staff");
  if (!staff) return NextResponse.redirect(new URL("/admin/login?denied=1", req.url));

  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  res.headers.set("Cache-Control", "no-store");
  return res;
}

export const config = { matcher: ["/admin/:path*"] };
