import type { MetadataRoute } from "next";
import { SITE } from "@/lib/content/site";
import { getActiveServices, getPosts, getProjects } from "@/lib/data";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [services, projects, posts] = await Promise.all([getActiveServices(), getProjects(), getPosts()]);
  const now = new Date();
  const staticPages = ["", "/about", "/services", "/industries", "/work", "/pricing", "/insights", "/contact", "/free-email-audit", "/book-a-call", "/legal/privacy", "/legal/terms", "/legal/cookies"];
  return [
    ...staticPages.map((p) => ({ url: `${SITE.url}${p}`, lastModified: now, changeFrequency: "monthly" as const, priority: p === "" ? 1 : p === "/free-email-audit" ? 0.9 : 0.7 })),
    ...services.map((s) => ({ url: `${SITE.url}/services/${s.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 })),
    ...projects.map((p) => ({ url: `${SITE.url}/work/${p.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.6 })),
    ...posts.map((p) => ({ url: `${SITE.url}/insights/${p.slug}`, lastModified: new Date(p.updated_at || p.published_at || now), changeFrequency: "yearly" as const, priority: 0.6 })),
  ];
}
