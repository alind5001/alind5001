import { ImageResponse } from "next/og";

export const alt = "Inboxora Digital: Emails that connect. Marketing that converts.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OG() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 72, background: "linear-gradient(135deg,#101828 0%,#172554 60%,#2e1f6b 100%)", color: "white" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <div style={{ width: 56, height: 56, borderRadius: 16, background: "linear-gradient(135deg,#3B82F6,#8B5CF6)" }} />
          <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: 4 }}>INBOXORA DIGITAL</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1.02, letterSpacing: -3, maxWidth: 980 }}>Emails that connect. Marketing that converts.</div>
          <div style={{ fontSize: 30, marginTop: 28, color: "rgba(255,255,255,.65)" }}>Email marketing, lifecycle automation and customer retention for e-commerce brands.</div>
        </div>
      </div>
    ),
    size
  );
}
