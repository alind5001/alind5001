import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-mist px-6">
      <div className="max-w-md text-center">
        <p className="font-display text-7xl font-extrabold tracking-tight gradient-text">404</p>
        <h1 className="mt-4 font-display text-2xl font-bold">This page isn&apos;t in our inbox.</h1>
        <p className="mt-3 text-muted">The link may be out of date, or the page may have moved.</p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/" className="btn btn-dark">Go to homepage</Link>
          <Link href="/contact" className="btn btn-ghost">Contact us</Link>
        </div>
      </div>
    </main>
  );
}
