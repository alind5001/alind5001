import { calendlyEventSchema } from "@/lib/validation";
import { json, parseBody, sameOrigin } from "@/lib/forms/respond";
import { recordCalendlyBooking } from "@/lib/calendly";
import { clientIp, hashIp } from "@/lib/forms/guard";
import { createServiceClient } from "@/lib/supabase/service";

export const runtime = "nodejs";

/** Called by the booking page when Calendly's embed reports a scheduled event. */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "Forbidden." });
  if (!process.env.CALENDLY_API_TOKEN) return json(200, { ok: true, recorded: false, reason: "CALENDLY_API_TOKEN not set" });
  const parsed = await parseBody(req, calendlyEventSchema);
  if ("error" in parsed) return parsed.error;
  const d = parsed.data!;

  // Light rate limit: lookups hit Calendly's API.
  const sb = createServiceClient();
  if (sb) {
    const ipHash = hashIp(clientIp(req));
    const { count } = await sb.from("submission_log").select("id", { count: "exact", head: true }).eq("ip_hash", ipHash).eq("form", "calendly").gte("created_at", new Date(Date.now() - 3600_000).toISOString());
    if ((count ?? 0) >= 10) return json(429, { ok: false, error: "Too many requests." });
    await sb.from("submission_log").insert({ ip_hash: ipHash, form: "calendly" });
  }

  const r = await recordCalendlyBooking(d.event_uri, d.invitee_uri, { company: d.company, website: d.website });
  return r.ok ? json(200, { ok: true }) : json(r.status, { ok: false, error: r.error });
}
