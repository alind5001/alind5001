import { createHmac, timingSafeEqual } from "node:crypto";
import { json } from "@/lib/forms/respond";
import { markCalendlyCancelled, recordCalendlyBooking } from "@/lib/calendly";

export const runtime = "nodejs";

function verify(body: string, header: string | null, key: string) {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]));
  const t = parts.t;
  const v1 = parts.v1;
  if (!t || !v1) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > 300) return false; // 5-minute tolerance against replays
  const expected = createHmac("sha256", key).update(`${t}.${body}`).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(v1);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Optional: Calendly webhook (paid Calendly plans). Subscribe to invitee.created and invitee.canceled. */
export async function POST(req: Request) {
  const key = process.env.CALENDLY_WEBHOOK_SIGNING_KEY;
  if (!key) return json(404, { ok: false });
  const body = await req.text();
  if (!verify(body, req.headers.get("calendly-webhook-signature"), key)) return json(401, { ok: false, error: "Invalid signature." });

  const evt = JSON.parse(body) as { event: string; payload: { uri: string; event: string } };
  if (evt.event === "invitee.created") await recordCalendlyBooking(evt.payload.event, evt.payload.uri);
  if (evt.event === "invitee.canceled") await markCalendlyCancelled(evt.payload.event);
  return json(200, { ok: true });
}
