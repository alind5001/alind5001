import { bookingRequestSchema } from "@/lib/validation";
import { guardSubmission } from "@/lib/forms/guard";
import { adminLink, json, parseBody, sameOrigin } from "@/lib/forms/respond";
import { createServiceClient } from "@/lib/supabase/service";
import { acknowledgement, internalNotification, sendEmail } from "@/lib/email";
import { getSettings } from "@/lib/data";

export const runtime = "nodejs";

/** Fallback discovery-call request, used when Calendly is not configured. Records a request, not a confirmed slot. */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "Forbidden." });
  const parsed = await parseBody(req, bookingRequestSchema);
  if ("error" in parsed) return parsed.error;
  const d = parsed.data!;

  const today = new Date().toISOString().slice(0, 10);
  if (d.preferred_date < today) return json(422, { ok: false, error: "Please check the highlighted fields.", fieldErrors: { preferred_date: "Choose a date from today onwards." } });

  const guard = await guardSubmission({ req, kind: "booking", email: d.email, startedAt: d.started_at, turnstileToken: d.turnstile_token, table: "bookings" });
  if (!guard.ok) return json(guard.status, { ok: false, error: guard.error });
  if (guard.duplicate) return json(200, { ok: true, duplicate: true });

  const sb = createServiceClient()!;
  const { data: row, error } = await sb
    .from("bookings")
    .insert({
      name: d.name,
      email: d.email,
      company: d.company,
      website: d.website,
      scheduled_at: null,
      timezone: d.timezone,
      preferred_date: d.preferred_date,
      preferred_time: d.preferred_time,
      requirements: d.requirements,
      meeting_status: "requested",
      source: "request_form",
      marketing_consent: d.marketing_consent,
      status: "New",
    })
    .select("id")
    .single();
  if (error) {
    console.error("[booking] insert failed", error.message);
    return json(500, { ok: false, error: "We couldn't save your request. Please try again, or email us directly." });
  }

  const { contact } = await getSettings();
  const note = internalNotification(
    "discovery call request",
    { Name: d.name, Email: d.email, Company: d.company, Website: d.website, "Time zone": d.timezone, "Preferred date": d.preferred_date, "Preferred time": d.preferred_time, Requirements: d.requirements },
    adminLink(`/admin/leads?source=booking&id=${row.id}`)
  );
  const ack = acknowledgement({
    name: d.name,
    heading: "We've received your call request",
    lines: [
      `Thanks for asking to book a 30-minute discovery call. You asked for ${d.preferred_date}, ${d.preferred_time.toLowerCase()} (${d.timezone}).`,
      "This isn't a confirmed booking yet. We'll reply within one business day to confirm a time that works, and send a calendar invitation once it's agreed.",
    ],
    contactEmail: contact.email,
  });
  await Promise.all([
    sendEmail({ to: process.env.AGENCY_NOTIFICATION_EMAIL || contact.email, replyTo: d.email, ...note }),
    sendEmail({ to: d.email, subject: "Your discovery call request | Inboxora Digital", ...ack }),
  ]);
  return json(200, { ok: true });
}
