import { contactSchema } from "@/lib/validation";
import { guardSubmission } from "@/lib/forms/guard";
import { adminLink, json, parseBody, sameOrigin } from "@/lib/forms/respond";
import { createServiceClient } from "@/lib/supabase/service";
import { acknowledgement, internalNotification, sendEmail } from "@/lib/email";
import { getSettings } from "@/lib/data";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "Forbidden." });
  const parsed = await parseBody(req, contactSchema);
  if ("error" in parsed) return parsed.error;
  const d = parsed.data!;

  const guard = await guardSubmission({ req, kind: "contact", email: d.email, startedAt: d.started_at, turnstileToken: d.turnstile_token, table: "contacts" });
  if (!guard.ok) return json(guard.status, { ok: false, error: guard.error });
  if (guard.duplicate) return json(200, { ok: true, duplicate: true });

  const sb = createServiceClient()!;
  const message = d.plan ? `[Package: ${d.plan}]\n\n${d.message}` : d.message;
  const { data: row, error } = await sb
    .from("contacts")
    .insert({
      name: d.name,
      email: d.email,
      company: d.company,
      website: d.website || null,
      country: d.country,
      service: d.service,
      budget: d.budget,
      message,
      marketing_consent: d.marketing_consent,
      status: "New",
    })
    .select("id")
    .single();
  if (error) {
    console.error("[contact] insert failed", error.message);
    return json(500, { ok: false, error: "We couldn't save your enquiry. Please try again, or email us directly." });
  }

  const { contact } = await getSettings();
  const note = internalNotification(
    "project enquiry",
    { Name: d.name, Email: d.email, Company: d.company, Website: d.website, Country: d.country, Service: d.service, Budget: d.budget, Package: d.plan, Message: d.message, "Marketing consent": d.marketing_consent ? "Yes" : "No" },
    adminLink(`/admin/leads?source=contact&id=${row.id}`)
  );
  const ack = acknowledgement({
    name: d.name,
    heading: "Thanks, we've received your enquiry",
    lines: [
      `Thank you for getting in touch with Inboxora Digital about ${d.service.toLowerCase()}.`,
      "We'll review your message and reply within one business day, usually with a few questions or a suggested time for a short call.",
    ],
    contactEmail: contact.email,
  });
  await Promise.all([
    sendEmail({ to: process.env.AGENCY_NOTIFICATION_EMAIL || contact.email, replyTo: d.email, ...note }),
    sendEmail({ to: d.email, subject: "We've received your enquiry | Inboxora Digital", ...ack }),
  ]);

  return json(200, { ok: true });
}
