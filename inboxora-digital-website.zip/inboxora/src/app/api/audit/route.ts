import { auditSchema } from "@/lib/validation";
import { guardSubmission } from "@/lib/forms/guard";
import { adminLink, json, parseBody, sameOrigin } from "@/lib/forms/respond";
import { createServiceClient } from "@/lib/supabase/service";
import { acknowledgement, internalNotification, sendEmail } from "@/lib/email";
import { getSettings } from "@/lib/data";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "Forbidden." });
  const parsed = await parseBody(req, auditSchema);
  if ("error" in parsed) return parsed.error;
  const d = parsed.data!;

  const guard = await guardSubmission({ req, kind: "audit", email: d.email, startedAt: d.started_at, turnstileToken: d.turnstile_token, table: "audit_requests" });
  if (!guard.ok) return json(guard.status, { ok: false, error: guard.error });
  if (guard.duplicate) return json(200, { ok: true, duplicate: true });

  const sb = createServiceClient()!;
  const { data: row, error } = await sb
    .from("audit_requests")
    .insert({
      name: d.name,
      email: d.email,
      company: d.company,
      website: d.website,
      country: d.country,
      industry: d.industry,
      email_platform: d.email_platform,
      subscriber_count: d.subscriber_count,
      marketing_challenge: d.marketing_challenge,
      additional_information: d.additional_information,
      marketing_consent: d.marketing_consent,
      status: "New",
    })
    .select("id")
    .single();
  if (error) {
    console.error("[audit] insert failed", error.message);
    return json(500, { ok: false, error: "We couldn't save your audit request. Please try again, or email us directly." });
  }

  const { contact } = await getSettings();
  const note = internalNotification(
    "email audit request",
    { Name: d.name, Email: d.email, Company: d.company, Website: d.website, Country: d.country, Industry: d.industry, Platform: d.email_platform, Subscribers: d.subscriber_count, Challenge: d.marketing_challenge, "Additional information": d.additional_information, "Marketing consent": d.marketing_consent ? "Yes" : "No" },
    adminLink(`/admin/leads?source=audit&id=${row.id}`)
  );
  const ack = acknowledgement({
    name: d.name,
    heading: "Your free email audit request is in",
    lines: [
      `Thanks for requesting a free email marketing audit for ${d.company}.`,
      "We'll start with what's publicly visible: your website's signup experience and the emails a new subscriber receives. If a deeper look would help, we'll ask before going further.",
      "We will never ask for your platform password or your customers' data. If we need access later, we'll explain how to add us as a team member through your platform's own user settings, which you control.",
      "Expect to hear from us within two business days.",
    ],
    contactEmail: contact.email,
  });
  await Promise.all([
    sendEmail({ to: process.env.AGENCY_NOTIFICATION_EMAIL || contact.email, replyTo: d.email, ...note }),
    sendEmail({ to: d.email, subject: "Your free email audit request | Inboxora Digital", ...ack }),
  ]);

  return json(200, { ok: true });
}
