import { NextResponse } from "next/server";
import { createSessionClient } from "@/lib/supabase/server";

/** Exchanges a Supabase auth code (password reset / invite links) for a session. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const nextParam = url.searchParams.get("next") || "/admin";
  const next = nextParam.startsWith("/admin") ? nextParam : "/admin";
  if (code) {
    const sb = await createSessionClient();
    const { error } = await sb.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(new URL(next, url.origin));
  }
  return NextResponse.redirect(new URL("/admin/login", url.origin));
}
