import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { CalendlyEmbed } from "@/components/forms/CalendlyEmbed";
import { BookingRequestForm } from "@/components/forms/BookingRequestForm";
import { Icon } from "@/components/ui/Icon";
import { calendlyUrl } from "@/lib/env";

export const metadata: Metadata = {
  title: "Book a Discovery Call",
  description: "Book a free 30-minute discovery call with Inboxora Digital to discuss your e-commerce email marketing goals.",
  alternates: { canonical: "/book-a-call" },
};

export default function BookPage() {
  const url = calendlyUrl();
  return (
    <>
      <PageHero
        crumbs={[{ href: "/book-a-call", label: "Book a Call" }]}
        title="Let's Discuss Your Email Marketing Goals."
        lede="A relaxed 30-minute video call to understand your store, your customers and where email could help most."
      />
      <section className="container-x grid gap-12 py-16 md:py-20 lg:grid-cols-12">
        <aside className="lg:col-span-4">
          <ul className="space-y-4">
            <li className="flex gap-3"><Icon name="clock" className="mt-0.5 size-5 shrink-0 text-violet" /><span><strong>30 minutes</strong>, by video call</span></li>
            <li className="flex gap-3"><Icon name="globe" className="mt-0.5 size-5 shrink-0 text-violet" /><span>Times shown in <strong>your time zone</strong></span></li>
            <li className="flex gap-3"><Icon name="message" className="mt-0.5 size-5 shrink-0 text-violet" /><span>Free, with no obligation to buy</span></li>
          </ul>
          <h2 className="mt-10 font-display text-lg font-bold">What we&apos;ll cover</h2>
          <ul className="mt-3 space-y-2 text-ink/80">
            {["Your store, products and customers", "Your current email setup", "Your goals for the next few months", "Whether we're a good fit, and next steps"].map((i) => (
              <li key={i} className="flex gap-2.5"><span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-violet" />{i}</li>
            ))}
          </ul>
        </aside>
        <div className="lg:col-span-8">
          {url ? (
            <CalendlyEmbed url={url} />
          ) : (
            <div className="rounded-[var(--radius-panel)] border border-line bg-white p-6 md:p-10">
              <h2 className="font-display text-2xl font-bold tracking-tight">Request a call time</h2>
              <p className="mb-8 mt-2 text-muted">Tell us when suits you and we&apos;ll confirm a time by email, along with a calendar invitation.</p>
              <BookingRequestForm />
            </div>
          )}
        </div>
      </section>
    </>
  );
}
