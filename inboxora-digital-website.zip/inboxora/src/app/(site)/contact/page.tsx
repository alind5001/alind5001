import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { ContactForm } from "@/components/forms/ContactForm";
import { Icon } from "@/components/ui/Icon";
import { getActiveServices, getSettings } from "@/lib/data";
import { telHref, whatsappHref } from "@/lib/content/site";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Contact Inboxora Digital, a remote-first e-commerce email marketing agency based in Lucknow, India. Call, WhatsApp, email or send an enquiry.",
  alternates: { canonical: "/contact" },
};

type Props = { searchParams: Promise<{ plan?: string }> };

export default async function ContactPage({ searchParams }: Props) {
  const [{ contact }, services, sp] = await Promise.all([getSettings(), getActiveServices(), searchParams]);
  const plan = typeof sp.plan === "string" ? sp.plan.slice(0, 80) : undefined;
  const methods = [
    { icon: "mail" as const, label: "Email", value: contact.email, href: `mailto:${contact.email}` },
    { icon: "phone" as const, label: "Phone", value: contact.phone, href: telHref(contact.phone) },
    { icon: "whatsapp" as const, label: "WhatsApp", value: contact.phone, href: whatsappHref(contact.whatsapp), external: true },
  ];
  return (
    <>
      <PageHero crumbs={[{ href: "/contact", label: "Contact" }]} title="Let's Talk About Growing Your Business." />
      <section className="container-x grid gap-12 py-16 md:py-20 lg:grid-cols-12">
        <aside className="space-y-6 lg:col-span-4">
          <div>
            <h2 className="font-display text-xl font-bold">{contact.businessName}</h2>
            <p className="mt-2 flex gap-2 text-muted"><Icon name="pin" className="mt-0.5 size-5 shrink-0" />{contact.location}</p>
            <p className="mt-1 flex gap-2 text-muted"><Icon name="globe" className="mt-0.5 size-5 shrink-0" />{contact.operatingModel}, working with clients worldwide</p>
          </div>
          <ul className="space-y-3">
            {methods.map((m) => (
              <li key={m.label}>
                <a href={m.href} {...(m.external ? { target: "_blank", rel: "noopener noreferrer" } : {})} className="flex items-center gap-4 rounded-[var(--radius-card)] border border-line bg-white p-4 transition-colors hover:border-navy/30">
                  <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-blue/10 to-violet/15 text-blue"><Icon name={m.icon} /></span>
                  <span>
                    <span className="block text-sm text-muted">{m.label}</span>
                    <span className="block font-semibold">{m.value}</span>
                  </span>
                </a>
              </li>
            ))}
          </ul>
          <p className="text-sm leading-relaxed text-muted">We reply to enquiries within one business day (IST). For time-sensitive questions, WhatsApp is fastest.</p>
        </aside>
        <div className="rounded-[var(--radius-panel)] border border-line bg-white p-6 md:p-10 lg:col-span-8">
          <h2 className="font-display text-2xl font-bold tracking-tight">Send us an enquiry</h2>
          <p className="mb-8 mt-2 text-muted">Tell us about your store and what you&apos;d like help with.</p>
          <ContactForm services={services.map((s) => s.title)} plan={plan} />
        </div>
      </section>
    </>
  );
}
