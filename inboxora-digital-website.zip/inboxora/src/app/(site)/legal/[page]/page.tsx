import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui/PageHero";
import { Markdown } from "@/components/ui/Markdown";
import { getSettings } from "@/lib/data";

export const revalidate = 300;

const PAGES = {
  privacy: { title: "Privacy Policy", key: "privacy" },
  terms: { title: "Terms and Conditions", key: "terms" },
  cookies: { title: "Cookie Policy", key: "cookies" },
} as const;

type Props = { params: Promise<{ page: string }> };

export function generateStaticParams() {
  return Object.keys(PAGES).map((page) => ({ page }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = PAGES[(await params).page as keyof typeof PAGES];
  if (!p) return {};
  return { title: p.title, description: `${p.title} for Inboxora Digital.`, alternates: { canonical: `/legal/${(await params).page}` } };
}

export default async function LegalPage({ params }: Props) {
  const slug = (await params).page;
  const p = PAGES[slug as keyof typeof PAGES];
  if (!p) notFound();
  const { legal } = await getSettings();
  const updated = new Date(legal.updated).toLocaleDateString("en-GB", { dateStyle: "long" });
  return (
    <>
      <PageHero crumbs={[{ href: `/legal/${slug}`, label: p.title }]} title={p.title} lede={`Last updated ${updated}`} />
      <section className="container-x max-w-3xl py-16">
        <Markdown>{legal[p.key]}</Markdown>
      </section>
    </>
  );
}
