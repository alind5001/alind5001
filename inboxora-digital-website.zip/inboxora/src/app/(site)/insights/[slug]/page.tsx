import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Markdown } from "@/components/ui/Markdown";
import { JsonLd } from "@/components/ui/JsonLd";
import { CtaBand } from "@/components/ui/CtaBand";
import { ShareButtons } from "@/components/blog/ShareButtons";
import { readingTime } from "@/lib/content/posts";
import { SITE } from "@/lib/content/site";
import { getPost, getPosts } from "@/lib/data";

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getPosts()).map((p) => ({ slug: p.slug }));
}

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getPost((await params).slug);
  if (!p) return {};
  const title = p.seo_title || p.title;
  const description = p.meta_description || p.excerpt;
  return {
    title,
    description,
    alternates: { canonical: `/insights/${p.slug}` },
    openGraph: { type: "article", title, description, publishedTime: p.published_at ?? undefined, authors: [p.author], images: p.featured_image ? [p.featured_image] : undefined },
  };
}

export default async function PostPage({ params }: Props) {
  const p = await getPost((await params).slug);
  if (!p) notFound();
  const all = await getPosts();
  const related = [...all.filter((o) => o.slug !== p.slug && o.category === p.category), ...all.filter((o) => o.slug !== p.slug && o.category !== p.category)].slice(0, 3);
  const url = `${SITE.url}/insights/${p.slug}`;
  const date = p.published_at ? new Date(p.published_at).toLocaleDateString("en-GB", { dateStyle: "long" }) : "";

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          headline: p.title,
          description: p.meta_description || p.excerpt,
          datePublished: p.published_at,
          dateModified: p.updated_at || p.published_at,
          author: { "@type": "Organization", name: p.author },
          publisher: { "@type": "Organization", name: SITE.name, logo: { "@type": "ImageObject", url: `${SITE.url}/icon.svg` } },
          mainEntityOfPage: url,
          image: p.featured_image || undefined,
        }}
      />
      <article>
        <header className="border-b border-line bg-white">
          <div className="container-x max-w-3xl py-14 md:py-20">
            <nav aria-label="Breadcrumb" className="text-sm text-muted">
              <Link href="/insights" className="hover:text-navy">Insights</Link> <span aria-hidden>/</span> <span>{p.category}</span>
            </nav>
            <h1 className="display-lg mt-5">{p.title}</h1>
            <p className="lede mt-5">{p.excerpt}</p>
            <p className="mt-6 text-sm text-muted">
              By <span className="font-medium text-ink">{p.author}</span>, <time dateTime={p.published_at ?? undefined}>{date}</time>, {readingTime(p.content)} min read
            </p>
          </div>
        </header>
        {p.featured_image && (
          <div className="container-x max-w-4xl pt-10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={p.featured_image} alt="" className="w-full rounded-[var(--radius-card)] object-cover" />
          </div>
        )}
        <div className="container-x max-w-3xl py-12 md:py-16">
          <Markdown>{p.content}</Markdown>
          <div className="mt-12 border-t border-line pt-6">
            <ShareButtons url={url} title={p.title} />
          </div>
        </div>
      </article>
      {related.length > 0 && (
        <section className="border-t border-line bg-white">
          <div className="container-x py-16">
            <h2 className="display-md">Related articles</h2>
            <ul className="mt-8 grid gap-5 md:grid-cols-3">
              {related.map((r) => (
                <li key={r.slug}>
                  <Link href={`/insights/${r.slug}`} className="block h-full rounded-[var(--radius-card)] border border-line p-6 hover:border-navy/25">
                    <span className="text-sm font-medium text-violet">{r.category}</span>
                    <p className="mt-2 font-display text-lg font-bold leading-snug">{r.title}</p>
                    <p className="mt-3 text-sm text-muted">{readingTime(r.content)} min read</p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
      <CtaBand />
    </>
  );
}
