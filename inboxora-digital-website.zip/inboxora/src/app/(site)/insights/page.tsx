import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/ui/PageHero";
import { PostList } from "@/components/blog/PostList";
import { CtaBand } from "@/components/ui/CtaBand";
import { readingTime } from "@/lib/content/posts";
import { getCategories, getPosts } from "@/lib/data";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Insights | E-commerce Email Marketing Blog",
  description: "Practical guides on e-commerce email marketing: automation, abandoned cart, deliverability, segmentation, Klaviyo vs Shopify Email and BFCM strategy.",
  alternates: { canonical: "/insights" },
};

const fmt = (d: string | null) => (d ? new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "");

export default async function InsightsPage() {
  const [posts, cats] = await Promise.all([getPosts(), getCategories()]);
  const featured = posts.filter((p) => p.featured).slice(0, 3);
  const cards = posts.map((p) => ({ slug: p.slug, title: p.title, excerpt: p.excerpt, category: p.category, date: fmt(p.published_at), minutes: readingTime(p.content), image: p.featured_image }));
  const usedCats = cats.map((c) => c.name).filter((n) => posts.some((p) => p.category === n));
  return (
    <>
      <PageHero crumbs={[{ href: "/insights", label: "Insights" }]} title="Insights for better email marketing." lede="Practical, no-hype guides on campaigns, automation, deliverability and retention for e-commerce brands." />
      {featured.length > 0 && (
        <section className="container-x pt-16">
          <h2 className="font-display text-xl font-bold">Featured articles</h2>
          <ul className="mt-6 grid gap-5 lg:grid-cols-3">
            {featured.map((p, i) => (
              <li key={p.slug} className={i === 0 ? "lg:col-span-2 lg:row-span-2" : ""}>
                <Link href={`/insights/${p.slug}`} className={`flex h-full flex-col justify-end rounded-[var(--radius-panel)] p-7 md:p-9 ${i === 0 ? "min-h-72 bg-navy text-white" : "border border-line bg-white"}`}>
                  <span className={`text-sm font-medium ${i === 0 ? "text-violet" : "text-violet"}`}>{p.category}</span>
                  <h3 className={`mt-2 font-display font-bold tracking-tight ${i === 0 ? "text-3xl md:text-4xl" : "text-xl"}`}>{p.title}</h3>
                  {i === 0 && <p className="mt-3 max-w-xl text-white/70">{p.excerpt}</p>}
                  <p className={`mt-4 text-sm ${i === 0 ? "text-white/55" : "text-muted"}`}>{fmt(p.published_at)}, {readingTime(p.content)} min read</p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
      <section className="container-x py-16 md:py-20">
        <h2 className="mb-6 font-display text-xl font-bold">All articles</h2>
        <PostList posts={cards} categories={usedCats} />
      </section>
      <CtaBand />
    </>
  );
}
