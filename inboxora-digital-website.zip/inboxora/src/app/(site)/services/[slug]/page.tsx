import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { Faq } from "@/components/ui/Faq";
import { Icon } from "@/components/ui/Icon";
import { JsonLd } from "@/components/ui/JsonLd";
import { BrandCard } from "@/components/work/BrandCard";
import { SERVICE_DETAILS } from "@/lib/content/services";
import { SITE } from "@/lib/content/site";
import { getActiveServices, getProjects } from "@/lib/data";

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getActiveServices()).map((s) => ({ slug: s.slug }));
}

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const summary = (await getActiveServices()).find((s) => s.slug === slug);
  if (!summary) return {};
  const d = SERVICE_DETAILS[slug];
  return {
    title: d?.seoTitle ?? summary.title,
    description: d?.seoDescription ?? summary.summary,
    alternates: { canonical: `/services/${slug}` },
  };
}

export default async function ServiceDetailPage({ params }: Props) {
  const { slug } = await params;
  const services = await getActiveServices();
  const summary = services.find((s) => s.slug === slug);
  if (!summary) notFound();
  const d = SERVICE_DETAILS[slug];
  const projects = await getProjects();
  const related = d
    ? projects.filter((p) => p.categories.some((c) => d.portfolioCategories.includes(c))).slice(0, 3)
    : [];

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: summary.title,
          description: d?.seoDescription ?? summary.summary,
          provider: { "@type": "ProfessionalService", name: SITE.name, url: SITE.url },
          areaServed: SITE.targetMarkets,
          url: `${SITE.url}/services/${slug}`,
        }}
      />
      <PageHero
        crumbs={[{ href: "/services", label: "Services" }, { href: `/services/${slug}`, label: summary.shortTitle }]}
        title={d?.heroHeadline ?? summary.title}
        lede={d?.heroCopy ?? summary.summary}
      >
        <Link href="/book-a-call" className="btn btn-primary">Book a Discovery Call</Link>
        <Link href="/free-email-audit" className="btn btn-ghost">Get Free Email Audit</Link>
      </PageHero>

      <section className="container-x grid gap-12 py-20 md:py-24 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="text-sm font-semibold text-violet">{summary.title}</p>
          <h2 className="display-md mt-2">Service overview</h2>
        </div>
        <div className="space-y-5 text-lg leading-relaxed text-ink/80 lg:col-span-7">
          {(d?.overview ?? [summary.summary]).map((p) => <p key={p}>{p}</p>)}
        </div>
      </section>

      {d && (
        <>
          <section className="border-y border-line bg-white">
            <div className="container-x py-20 md:py-24">
              <h2 className="display-md">Problems we solve</h2>
              <ul className="mt-10 grid gap-5 md:grid-cols-2">
                {d.problems.map((p) => (
                  <li key={p.title} className="rounded-[var(--radius-card)] bg-mist p-6">
                    <h3 className="font-display text-lg font-bold">{p.title}</h3>
                    <p className="mt-2 leading-relaxed text-muted">{p.body}</p>
                  </li>
                ))}
              </ul>
            </div>
          </section>

          <section className="container-x grid gap-12 py-20 md:py-24 lg:grid-cols-2">
            <div>
              <h2 className="display-md">What is included</h2>
              <ul className="mt-8 space-y-3">
                {d.included.map((i) => (
                  <li key={i} className="flex gap-3 leading-relaxed">
                    <Icon name="check" className="mt-1 size-5 shrink-0 text-violet" />{i}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-[var(--radius-panel)] bg-navy p-8 text-white md:p-10">
              <h2 className="display-md">Deliverables</h2>
              <ul className="mt-8 divide-y divide-white/10">
                {d.deliverables.map((i) => (
                  <li key={i} className="py-3.5 text-white/85">{i}</li>
                ))}
              </ul>
            </div>
          </section>

          <section className="border-y border-line bg-white">
            <div className="container-x py-20 md:py-24">
              <h2 className="display-md">Working process</h2>
              <ol className="mt-10 grid gap-8 md:grid-cols-4">
                {d.process.map((s, i) => (
                  <li key={s.title} className="border-t-2 border-navy pt-5">
                    <span className="text-sm font-semibold text-muted">Step {i + 1}</span>
                    <h3 className="mt-1 font-display text-lg font-bold">{s.title}</h3>
                    <p className="mt-2 leading-relaxed text-muted">{s.body}</p>
                  </li>
                ))}
              </ol>
            </div>
          </section>

          {related.length > 0 && (
            <section className="container-x py-20 md:py-24">
              <h2 className="display-md">Relevant portfolio examples</h2>
              <p className="mt-3 max-w-2xl text-muted">Founder-led project experience that included this type of work.</p>
              <div className="mt-10 grid gap-5 md:grid-cols-3">
                {related.map((p) => <BrandCard key={p.id} project={p} />)}
              </div>
            </section>
          )}

          <section className="container-x pb-8 pt-4 md:pb-12">
            <h2 className="display-md mb-8">Frequently asked questions</h2>
            <Faq items={d.faqs} />
            <JsonLd
              data={{
                "@context": "https://schema.org",
                "@type": "FAQPage",
                mainEntity: d.faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
              }}
            />
          </section>
        </>
      )}

      {!d && summary.bullets.length > 0 && (
        <section className="container-x pb-12">
          <ul className="grid gap-3 sm:grid-cols-2">
            {summary.bullets.map((b) => (
              <li key={b} className="flex gap-3"><Icon name="check" className="mt-1 size-5 text-violet" />{b}</li>
            ))}
          </ul>
        </section>
      )}

      <CtaBand
        title="Let's talk about your email programme."
        copy="Book a 30-minute discovery call. We'll learn about your store and goals, and you'll leave with a clearer picture of what to prioritise."
        primary={{ href: "/book-a-call", label: "Book a Discovery Call" }}
        secondary={{ href: "/free-email-audit", label: "Get Free Email Audit" }}
      />
    </>
  );
}
