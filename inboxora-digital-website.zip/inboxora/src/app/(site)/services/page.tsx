import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/ui/PageHero";
import { ServiceCard } from "@/components/ui/ServiceCard";
import { CtaBand } from "@/components/ui/CtaBand";
import { getActiveServices } from "@/lib/data";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Email Marketing Services for E-commerce",
  description:
    "Email campaign management, email automation services, HTML email design, strategy, segmentation, deliverability and reporting for Shopify and D2C brands.",
  alternates: { canonical: "/services" },
};

export default async function ServicesPage() {
  const services = await getActiveServices();
  return (
    <>
      <PageHero
        crumbs={[{ href: "/services", label: "Services" }]}
        title="Email marketing services built for e-commerce."
        lede="Choose a single service or combine them into a complete email programme. Every engagement starts with understanding your store, your customers and your goals."
      >
        <Link href="/free-email-audit" className="btn btn-primary">Get Free Email Audit</Link>
        <Link href="/pricing" className="btn btn-ghost">View pricing</Link>
      </PageHero>
      <section className="container-x py-20 md:py-24">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => <ServiceCard key={s.slug} service={s} />)}
        </div>
      </section>
      <CtaBand
        title="Not sure where to start?"
        copy="A free email audit shows where the biggest opportunities are in your current setup, so you can decide what to prioritise."
      />
    </>
  );
}
