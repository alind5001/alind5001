import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { AuditForm } from "@/components/forms/AuditForm";
import { Icon } from "@/components/ui/Icon";

export const metadata: Metadata = {
  title: "Free Email Marketing Audit",
  description:
    "Request a free email marketing audit for your e-commerce store: a personalised review of your campaigns, automations, deliverability and retention opportunities.",
  alternates: { canonical: "/free-email-audit" },
};

const CHECKS = [
  "Signup experience and welcome journey",
  "Core automations: cart, browse, post-purchase, winback",
  "Campaign cadence, design and messaging",
  "Segmentation and personalisation",
  "Deliverability basics and list health",
  "Prioritised list of opportunities",
];

export default function AuditPage() {
  return (
    <>
      <PageHero
        crumbs={[{ href: "/free-email-audit", label: "Free Email Audit" }]}
        title="Find the Opportunities Hiding in Your Email Marketing."
        lede="Get a personalised review of your existing email marketing setup and discover opportunities to improve campaigns, customer journeys and retention."
      />
      <section className="container-x grid gap-12 py-16 md:py-20 lg:grid-cols-12">
        <aside className="order-2 lg:order-1 lg:col-span-4">
          <div className="lg:sticky lg:top-28">
            <h2 className="font-display text-xl font-bold">What we review</h2>
            <ul className="mt-5 space-y-3">
              {CHECKS.map((c) => (
                <li key={c} className="flex gap-3 leading-relaxed"><Icon name="check" className="mt-1 size-5 shrink-0 text-violet" />{c}</li>
              ))}
            </ul>
            <div className="mt-8 rounded-[var(--radius-card)] bg-navy p-6 text-white">
              <h3 className="font-display font-bold">Free, with no obligation</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/70">You&apos;ll get honest findings whether or not you decide to work with us. We never ask for passwords or customer data.</p>
            </div>
          </div>
        </aside>
        <div className="order-1 rounded-[var(--radius-panel)] border border-line bg-white p-6 md:p-10 lg:order-2 lg:col-span-8">
          <AuditForm />
        </div>
      </section>
    </>
  );
}
