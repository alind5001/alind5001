import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { PortfolioGrid } from "@/components/work/PortfolioGrid";
import { ATTRIBUTION } from "@/lib/content/brands";
import { PORTFOLIO_CATEGORIES } from "@/lib/content/site";
import { getProjects } from "@/lib/data";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Our Work | Selected Email Marketing Experience",
  description:
    "Selected email marketing work and founder-led client experience across food, industrial, skincare, apparel, wellness and lifestyle e-commerce brands.",
  alternates: { canonical: "/work" },
};

export default async function WorkPage() {
  const projects = await getProjects();
  return (
    <>
      <PageHero
        crumbs={[{ href: "/work", label: "Our Work" }]}
        title="Selected Work & Client Experience."
        lede="Explore selected examples of email marketing work and professional project experience across different e-commerce industries."
      />
      <section className="container-x py-16 md:py-20">
        <div className="mb-10 rounded-[var(--radius-card)] border border-violet/25 bg-violet/[0.05] p-5 text-sm leading-relaxed text-ink/80 md:p-6">
          <strong className="text-ink">{ATTRIBUTION}.</strong> These projects represent our founder&apos;s previous professional experience. They do not imply endorsement by, or an official partnership with, the brands shown. Where real campaign screenshots are not yet published, previews are clearly labelled concept designs and are not client work.
        </div>
        <PortfolioGrid projects={projects} categories={PORTFOLIO_CATEGORIES} />
      </section>
      <CtaBand />
    </>
  );
}
