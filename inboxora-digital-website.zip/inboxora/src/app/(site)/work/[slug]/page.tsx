import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { CaseGallery } from "@/components/work/CaseGallery";
import { galleryFor } from "@/components/work/gallery";
import { getProject, getProjects } from "@/lib/data";

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getProjects()).map((p) => ({ slug: p.slug }));
}

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProject((await params).slug);
  if (!p) return {};
  return {
    title: `${p.brand_name} | Email Marketing Experience`,
    description: p.description,
    alternates: { canonical: `/work/${p.slug}` },
  };
}

export default async function CaseStudyPage({ params }: Props) {
  const p = await getProject((await params).slug);
  if (!p) notFound();
  const cs = p.case_study;
  const all = await getProjects();
  const others = all.filter((o) => o.slug !== p.slug).slice(0, 3);
  const items = galleryFor(p.images, p.categories, p.brand_name);
  const hasRealImages = p.images.some((i) => !i.concept);

  const Block = ({ n, title, children }: { n: number; title: string; children: React.ReactNode }) => (
    <section className="grid gap-4 border-t border-line py-10 md:grid-cols-12">
      <h2 className="font-display text-xl font-bold tracking-tight md:col-span-4">
        <span className="mr-2 text-muted">{n}.</span>{title}
      </h2>
      <div className="leading-relaxed text-ink/80 md:col-span-8">{children}</div>
    </section>
  );
  const Bullets = ({ items }: { items: string[] }) => (
    <ul className="space-y-2">
      {items.map((i) => (
        <li key={i} className="flex gap-3"><Icon name="check" className="mt-1 size-4 shrink-0 text-violet" />{i}</li>
      ))}
    </ul>
  );

  return (
    <>
      <PageHero
        crumbs={[{ href: "/work", label: "Our Work" }, { href: `/work/${p.slug}`, label: p.brand_name }]}
        title={p.brand_name}
        lede={p.description}
        aside={
          <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-[var(--radius-card)] border border-line bg-line text-sm">
            <div className="bg-white p-4"><dt className="text-muted">Industry</dt><dd className="mt-1 font-semibold">{p.industry}</dd></div>
            <div className="bg-white p-4"><dt className="text-muted">Country</dt><dd className="mt-1 font-semibold">{p.country}</dd></div>
            <div className="col-span-2 bg-white p-4"><dt className="text-muted">Engagement</dt><dd className="mt-1 font-semibold">{p.attribution}</dd></div>
          </dl>
        }
      >
        <a href={p.website} target="_blank" rel="noopener noreferrer nofollow" className="btn btn-dark">
          Visit Brand Website <Icon name="external" className="size-4" />
        </a>
      </PageHero>

      <div className="container-x py-12 md:py-16">
        <Block n={1} title="Brand overview"><p>{cs.overview}</p></Block>
        <Block n={2} title="Industry"><p>{p.industry}, {p.country}</p></Block>
        <Block n={3} title="Business context"><p>{cs.context}</p></Block>
        <Block n={4} title="Marketing objectives"><Bullets items={cs.objectives} /></Block>
        <Block n={5} title="Email marketing strategy"><p>{cs.strategy}</p></Block>
        <Block n={6} title="Work executed"><Bullets items={cs.workExecuted} /></Block>
        <Block n={7} title="Campaign examples">
          <Bullets items={cs.campaignExamples} />
          <div className="mt-8">
            <CaseGallery items={items} />
            {!hasRealImages && (
              <p className="mt-4 text-sm text-muted">
                Previews above are illustrative concept designs, not the brand&apos;s actual emails. Approved campaign screenshots can be added from the admin dashboard.
              </p>
            )}
          </div>
        </Block>
        {cs.automationExamples.length > 0 && (
          <Block n={8} title="Automation examples"><Bullets items={cs.automationExamples} /></Block>
        )}
        <Block n={cs.automationExamples.length > 0 ? 9 : 8} title="Performance insights">
          {p.verified_results ? (
            <p className="whitespace-pre-line">{p.verified_results}</p>
          ) : (
            <p className="text-muted">
              Project-level results for this brand are not published. Aggregate figures across the relevant projects, with methodology, are shown on our <Link href="/#performance" className="text-blue underline underline-offset-2">homepage</Link>.
            </p>
          )}
        </Block>
        <Block n={cs.automationExamples.length > 0 ? 10 : 9} title="Visit brand website">
          <a href={p.website} target="_blank" rel="noopener noreferrer nofollow" className="inline-flex items-center gap-2 font-semibold text-blue underline underline-offset-2">
            {p.website.replace(/^https?:\/\//, "").replace(/\/$/, "")} <Icon name="external" className="size-4" />
          </a>
          <p className="mt-3 text-sm text-muted">Inclusion here does not imply endorsement by, or an official partnership with, {p.brand_name}. Brand names belong to their respective owners.</p>
        </Block>
      </div>

      {others.length > 0 && (
        <section className="border-t border-line bg-white">
          <div className="container-x py-16">
            <h2 className="display-md">More client experience</h2>
            <ul className="mt-8 grid gap-4 md:grid-cols-3">
              {others.map((o) => (
                <li key={o.slug}>
                  <Link href={`/work/${o.slug}`} className="block rounded-[var(--radius-card)] border border-line p-6 hover:border-navy/30">
                    <p className="text-sm text-muted">{o.industry}, {o.country}</p>
                    <p className="mt-1 font-display text-lg font-bold">{o.brand_name}</p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
      <CtaBand />
    </>
  );
}
