import Link from "next/link";
import { HeroVisual } from "@/components/home/HeroVisual";
import { StatsBlock } from "@/components/home/StatsBlock";
import { ServiceCard } from "@/components/ui/ServiceCard";
import { BrandCard } from "@/components/work/BrandCard";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon, type IconName } from "@/components/ui/Icon";
import { INDUSTRIES } from "@/lib/content/industries";
import { PLATFORMS } from "@/lib/content/site";
import { ATTRIBUTION } from "@/lib/content/brands";
import { getActiveServices, getProjects, getSettings } from "@/lib/data";

export const revalidate = 300;

const WHY: { icon: IconName; title: string; body: string }[] = [
  { icon: "target", title: "E-commerce-focused expertise", body: "We work only with online retail, so we understand carts, catalogues and repeat purchase." },
  { icon: "spark", title: "Conversion-focused creative", body: "Every email is designed around one clear action for the reader." },
  { icon: "calendar", title: "Custom campaign planning", body: "Calendars built around your products, launches and seasons, not a template." },
  { icon: "chart", title: "Data-driven optimisation", body: "Decisions guided by clicks, conversions and revenue, tested over time." },
  { icon: "flow", title: "Lifecycle automation", body: "Journeys that respond to what each customer does, from signup to reorder." },
  { icon: "pen", title: "Professional email design", body: "On-brand templates that render well across inboxes and devices." },
  { icon: "message", title: "Transparent communication", body: "Clear reporting, honest recommendations and no inflated promises." },
  { icon: "layers", title: "Flexible engagement models", body: "Monthly retainers, focused projects or audits, scoped to your needs." },
];

const STEPS = [
  { title: "Discover", body: "Understand your business, audience, products and objectives." },
  { title: "Audit", body: "Review your existing email marketing setup, campaigns and automations." },
  { title: "Strategise", body: "Build a campaign calendar and customer retention strategy." },
  { title: "Create", body: "Design and develop email campaigns and automated journeys." },
  { title: "Execute", body: "Schedule, test and launch approved campaigns." },
  { title: "Optimise", body: "Review results and continuously improve performance." },
];

const INDUSTRY_ICONS: Record<string, IconName> = {
  "fashion-apparel": "spark",
  "beauty-skincare": "heart",
  "jewellery-accessories": "target",
  "food-beverage": "refresh",
  "home-lifestyle": "layers",
  "health-wellness": "shield",
  "pet-supplies": "users",
  "industrial-b2b": "compass",
};

export default async function HomePage() {
  const [settings, services, projects] = await Promise.all([getSettings(), getActiveServices(), getProjects()]);
  const homeServices = services.filter((s) => s.onHome);
  const { stats } = settings;

  return (
    <>
      {/* 1. Hero */}
      <section className="relative overflow-hidden">
        <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-[42rem] bg-[radial-gradient(50%_60%_at_80%_10%,rgb(139_92_246/0.14),transparent),radial-gradient(40%_50%_at_10%_0%,rgb(59_130_246/0.12),transparent)]" />
        <div className="container-x relative grid items-center gap-16 pb-24 pt-14 md:pt-20 lg:grid-cols-[1.05fr_1fr] lg:gap-12 lg:pb-32">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 text-sm text-muted">
              <span className="size-1.5 rounded-full bg-gradient-to-r from-blue to-violet" />
              Email marketing for e-commerce brands
            </p>
            <h1 className="display-xl mt-6">Turn Every Email Into an Opportunity for Growth.</h1>
            <p className="lede mt-6">
              We help ambitious e-commerce brands build meaningful customer relationships and drive repeat revenue through strategic email marketing, intelligent automation and conversion-focused campaigns.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/free-email-audit" className="btn btn-primary">Get a Free Email Audit</Link>
              <Link href="/work" className="btn btn-ghost">Explore Our Work</Link>
            </div>
            <p className="mt-8 flex items-center gap-2 text-sm text-muted">
              <Icon name="mail" className="size-4 text-violet" />
              Your email marketing partner, from first click to repeat purchase.
            </p>
          </div>
          <HeroVisual />
        </div>
      </section>

      {/* 2. Trust and experience */}
      <section className="border-y border-line bg-white">
        <div className="container-x grid gap-10 py-16 md:py-20 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-5">
            <h2 className="display-md">Built Around Real E-commerce Marketing Experience.</h2>
            <p className="mt-4 leading-relaxed text-muted">
              Experience across multiple e-commerce industries, product categories and customer journeys, with a focus on strategic email communication and customer retention.
            </p>
          </div>
          <div className="lg:col-span-7">
            <ul className="grid gap-4 sm:grid-cols-3">
              {[
                ["6", "selected brand experiences"],
                ["90-day", "reported project performance period"],
                ["20–25%", "reported email-attributed revenue contribution*"],
              ].map(([v, l]) => (
                <li key={l} className="rounded-[var(--radius-card)] bg-mist p-5">
                  <span className="block font-display text-3xl font-extrabold tracking-tight">{v}</span>
                  <span className="mt-1 block text-sm leading-snug text-muted">{l}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs leading-relaxed text-muted">
              *An aggregate historical result reported across the relevant founder-led projects, not a guaranteed result for individual clients. <Link href="#performance" className="underline underline-offset-2">See methodology</Link>.
            </p>
          </div>
        </div>
      </section>

      {/* 3. Services */}
      <section className="container-x py-20 md:py-28">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <h2 className="display-lg">Everything your email channel needs, under one roof.</h2>
            <p className="lede mt-4">From the first campaign to a full lifecycle programme, we plan, build and improve the emails that bring customers back.</p>
          </div>
          <Link href="/services" className="btn btn-ghost self-start md:self-auto">View all services</Link>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {homeServices.map((s) => <ServiceCard key={s.slug} service={s} />)}
        </div>
      </section>

      {/* 4. Why Inboxora */}
      <section className="bg-white">
        <div className="container-x grid gap-12 py-20 md:py-28 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <h2 className="display-lg lg:sticky lg:top-28">More Than Emails. A Strategy for Better Customer Relationships.</h2>
          </div>
          <ul className="grid gap-x-10 gap-y-9 sm:grid-cols-2 lg:col-span-8">
            {WHY.map((w) => (
              <li key={w.title} className="border-t border-line pt-6">
                <Icon name={w.icon} className="size-6 text-blue" />
                <h3 className="mt-4 font-display text-lg font-bold tracking-tight">{w.title}</h3>
                <p className="mt-1.5 leading-relaxed text-muted">{w.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 5. How we work */}
      <section className="container-x py-20 md:py-28">
        <div className="max-w-2xl">
          <h2 className="display-lg">How We Work</h2>
          <p className="lede mt-4">Six steps, repeated every month, so your email programme keeps getting sharper.</p>
        </div>
        <ol className="relative mt-14 grid gap-8 md:grid-cols-3 lg:grid-cols-6 lg:gap-5">
          <div aria-hidden className="absolute left-0 right-0 top-[1.35rem] hidden h-px bg-gradient-to-r from-blue via-violet to-blue/20 lg:block" />
          {STEPS.map((s, i) => (
            <li key={s.title} className="relative">
              <span className="relative grid size-11 place-items-center rounded-full border border-line bg-white font-display text-sm font-bold text-navy shadow-[var(--shadow-float)]">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="mt-5 font-display text-lg font-bold tracking-tight">{s.title}</h3>
              <p className="mt-1.5 text-[0.93rem] leading-relaxed text-muted">{s.body}</p>
            </li>
          ))}
        </ol>
        <div className="mt-12">
          <Link href="/contact" className="btn btn-dark">Let&apos;s Work Together</Link>
        </div>
      </section>

      {/* 6. Selected client experience */}
      <section className="border-y border-line bg-white">
        <div className="container-x py-20 md:py-28">
          <p className="inline-flex rounded-full bg-violet/10 px-3 py-1.5 text-sm font-medium text-violet">{ATTRIBUTION}</p>
          <div className="mt-5 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <div className="max-w-3xl">
              <h2 className="display-lg">Experience Across Brands. Strategies Built Around Growth.</h2>
              <p className="lede mt-4">
                Our founder&apos;s professional experience includes working on email marketing projects across multiple e-commerce brands, covering promotional campaigns, automation, newsletters, product discovery and customer engagement.
              </p>
            </div>
            <Link href="/work" className="btn btn-ghost self-start lg:self-auto">See all work</Link>
          </div>
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {projects.slice(0, 6).map((p) => <BrandCard key={p.id} project={p} />)}
          </div>
          <p className="mt-8 max-w-3xl text-sm leading-relaxed text-muted">
            These projects represent our founder&apos;s previous professional experience. Brand names are shown for reference only and do not imply endorsement by, or an official partnership with, any brand.
          </p>
        </div>
      </section>

      {/* 7. Performance highlights */}
      <section id="performance" className="scroll-mt-24 bg-navy text-white">
        <div className="container-x py-20 md:py-28">
          <h2 className="display-lg max-w-3xl">Email Marketing With a Measurable Business Contribution.</h2>
          <div className="mt-12">
            <StatsBlock stats={stats} />
          </div>
        </div>
      </section>

      {/* 8. Platforms */}
      <section className="container-x py-20 md:py-24">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-4">
            <h2 className="display-md">Platforms we work in</h2>
            <p className="mt-3 leading-relaxed text-muted">We build and manage email programmes on the platforms e-commerce brands already use.</p>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2 lg:col-span-8 lg:grid-cols-4">
            {PLATFORMS.map((p) => (
              <li key={p.name} className="rounded-[var(--radius-card)] border border-line bg-white p-5">
                <span className="block font-display text-lg font-bold tracking-tight">{p.name}</span>
                <span className="mt-1 block text-sm leading-snug text-muted">{p.note}</span>
              </li>
            ))}
          </ul>
        </div>
        <p className="mt-6 text-xs text-muted">Platform names are trademarks of their respective owners. Listing a platform does not indicate official partner status or certification.</p>
      </section>

      {/* 9. Industries */}
      <section className="bg-white">
        <div className="container-x py-20 md:py-28">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div className="max-w-2xl">
              <h2 className="display-lg">Industries we understand</h2>
              <p className="lede mt-4">Each category has its own buying rhythm. We shape email around it.</p>
            </div>
            <Link href="/industries" className="btn btn-ghost self-start md:self-auto">Explore industries</Link>
          </div>
          <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {INDUSTRIES.map((ind) => (
              <li key={ind.slug}>
                <Link href={`/industries#${ind.slug}`} className="flex h-full flex-col rounded-[var(--radius-card)] border border-line bg-mist p-6 transition-colors hover:border-blue/40 hover:bg-white">
                  <Icon name={INDUSTRY_ICONS[ind.slug] ?? "spark"} className="size-6 text-violet" />
                  <h3 className="mt-5 font-display text-lg font-bold tracking-tight">{ind.name}</h3>
                  <p className="mt-2 text-[0.92rem] leading-relaxed text-muted">{ind.card}</p>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 10. Final CTA */}
      <CtaBand />
    </>
  );
}
