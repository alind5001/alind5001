import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { CookieConsent } from "@/components/layout/CookieConsent";
import { JsonLd } from "@/components/ui/JsonLd";
import { SITE, telHref } from "@/lib/content/site";
import { getSettings } from "@/lib/data";

export default async function SiteLayout({ children }: { children: React.ReactNode }) {
  const { contact, social } = await getSettings();
  // Organization schema without a street address: the agency is remote-first.
  const org = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: SITE.name,
    url: SITE.url,
    logo: `${SITE.url}/icon.svg`,
    slogan: SITE.tagline,
    description: SITE.description,
    email: contact.email,
    telephone: telHref(contact.phone).replace("tel:", ""),
    address: { "@type": "PostalAddress", addressLocality: "Lucknow", addressRegion: "Uttar Pradesh", addressCountry: "IN" },
    areaServed: SITE.targetMarkets.map((name) => ({ "@type": "Country", name })),
    knowsAbout: ["Email marketing", "Email automation", "Klaviyo", "Shopify Email", "Customer retention"],
    sameAs: Object.values(social).filter(Boolean),
  };
  return (
    <>
      <JsonLd data={org} />
      <Navbar />
      <main id="main">{children}</main>
      <Footer />
      <CookieConsent />
    </>
  );
}
