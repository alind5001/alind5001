import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { Faq } from "@/components/ui/Faq";
import { Icon } from "@/components/ui/Icon";
import { getSettings } from "@/lib/data";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Pricing | Email Marketing Packages",
  description:
    "Email marketing packages for e-commerce brands, starting at $249/month. Campaigns, automation, segmentation, reporting and deliverability monitoring.",
  alternates: { canonical: "/pricing" },
};

export default async function PricingPage() {
  const { pricing } = await getSettings();
  return (
    <>
      <PageHero
        crumbs={[{ href: "/pricing", label: "Pricing" }]}
        title="Simple packages. Scope agreed before we start."
        lede="All prices are starting prices in US dollars. We confirm scope, deliverables and the final fee in writing before onboarding."
      />
      <section className="container-x py-16 md:py-24">
        <ul className="grid gap-5 lg:grid-cols-3">
          {pricing.packages.map((p) => (
            <li
              key={p.id}
              className={`relative flex flex-col rounded-[var(--radius-panel)] p-7 md:p-9 ${
                p.highlighted ? "bg-navy text-white shadow-[var(--shadow-lift)]" : "border border-line bg-white"
              }`}
            >
              {p.highlighted && (
                <span className="absolute right-6 top-6 rounded-full bg-gradient-to-r from-blue to-violet px-3 py-1 text-xs font-semibold text-white">Recommended</span>
              )}
              <h2 className="font-display text-xl font-bold tracking-tight">{p.name}</h2>
              <p className={`mt-2 text-[0.95rem] leading-relaxed ${p.highlighted ? "text-white/65" : "text-muted"}`}>{p.description}</p>
              <p className="mt-7">
                <span className={`block text-sm ${p.highlighted ? "text-white/60" : "text-muted"}`}>Starting at</span>
                <span className="font-display text-5xl font-extrabold tracking-[-0.04em]">{p.price}</span>
                <span className={p.highlighted ? "text-white/60" : "text-muted"}>{p.period}</span>
              </p>
              <ul className="mt-7 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex gap-3 text-[0.95rem]">
                    <Icon name="check" className={`mt-0.5 size-5 shrink-0 ${p.highlighted ? "text-violet" : "text-blue"}`} />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="mt-auto pt-9">
                <Link href={p.ctaHref} className={`btn w-full ${p.highlighted ? "btn-primary" : "btn-dark"}`}>{p.cta}</Link>
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-10 grid gap-8 rounded-[var(--radius-card)] border border-line bg-white p-7 md:grid-cols-2 md:p-9">
          <div>
            <h2 className="font-display text-lg font-bold">Good to know</h2>
            <ul className="mt-4 space-y-2.5 text-[0.95rem] text-ink/80">
              {pricing.notes.map((n) => (
                <li key={n} className="flex gap-3"><span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-violet" />{n}</li>
              ))}
            </ul>
          </div>
          <div className="md:border-l md:border-line md:pl-8">
            <h2 className="font-display text-lg font-bold">Need something different?</h2>
            <p className="mt-3 leading-relaxed text-muted">
              Running a migration, a one-off flow build or a BFCM-only engagement? Tell us what you need and we&apos;ll put together a customised proposal.
            </p>
            <Link href="/contact?plan=Custom%20proposal" className="btn btn-ghost mt-6">Request a Custom Proposal</Link>
          </div>
        </div>
      </section>

      <section className="container-x pb-8">
        <h2 className="display-md mb-8">Pricing questions</h2>
        <Faq
          items={[
            { q: "Is there a minimum contract length?", a: "We agree the engagement terms with you before onboarding. Many clients start with a three-month period so there is time to plan, launch and learn." },
            { q: "Are email platform costs included?", a: "No. Your subscription to Klaviyo, Shopify Email, Omnisend or another platform is paid directly by you." },
            { q: "Do you guarantee results?", a: "No. We do not guarantee revenue or sales. We commit to the agreed scope, transparent reporting and continuous improvement." },
            { q: "Which currency do you invoice in?", a: "Prices are shown in US dollars. Invoicing currency and payment method are confirmed in your proposal." },
          ]}
        />
      </section>
      <CtaBand />
    </>
  );
}
