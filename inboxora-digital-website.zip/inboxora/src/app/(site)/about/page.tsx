import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon, type IconName } from "@/components/ui/Icon";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Inboxora Digital is an independent, remote-first email marketing agency from Lucknow, India, helping e-commerce brands build better customer relationships and retention.",
  alternates: { canonical: "/about" },
};

const VALUES: { icon: IconName; title: string; body: string }[] = [
  { icon: "message", title: "Honesty", body: "We report what happened, including what did not work, and never promise guaranteed results." },
  { icon: "users", title: "Customer respect", body: "We send emails people want to receive, with clear consent and easy ways to opt out." },
  { icon: "target", title: "Clarity", body: "Every campaign, flow and report has a clear purpose and a clear next step." },
  { icon: "refresh", title: "Continuous improvement", body: "We treat each month's results as input for the next month's plan." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        crumbs={[{ href: "/about", label: "About" }]}
        title="Helping E-commerce Brands Build Better Customer Relationships."
      />

      <section className="container-x grid gap-12 py-20 md:py-28 lg:grid-cols-12">
        <div className="space-y-6 text-lg leading-relaxed text-ink/80 lg:col-span-7">
          <p>
            Inboxora Digital is an independent email marketing agency focused on helping e-commerce businesses improve customer engagement, build meaningful customer journeys and strengthen retention strategies.
          </p>
          <p>
            We combine creative email design, campaign planning, automation and performance analysis to help businesses communicate more effectively with their customers.
          </p>
          <p>
            Our approach is straightforward: understand the business, identify opportunities, create the right strategy, execute consistently and optimise continuously.
          </p>
        </div>
        <aside className="lg:col-span-5">
          <dl className="grid gap-px overflow-hidden rounded-[var(--radius-card)] border border-line bg-line">
            {[
              ["Based in", "Lucknow, Uttar Pradesh, India"],
              ["Working model", "Remote-first"],
              ["Clients in", "USA, UK, Australia, Canada, UAE and India"],
              ["Focus", "Email marketing, lifecycle automation and customer retention for e-commerce"],
            ].map(([k, v]) => (
              <div key={k} className="bg-white p-5">
                <dt className="text-sm text-muted">{k}</dt>
                <dd className="mt-1 font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        </aside>
      </section>

      <section className="border-y border-line bg-white">
        <div className="container-x grid gap-px py-20 md:grid-cols-3 md:py-24">
          {[
            ["Our Mission", "To help e-commerce brands turn one-time buyers into loyal customers through email that is useful, well-timed and genuinely on-brand."],
            ["Our Vision", "An inbox where brands earn attention by being relevant, and where email is recognised as one of the most valuable relationships a store can build."],
            ["Our Approach", "Understand the business, identify opportunities, create the right strategy, execute consistently and optimise continuously."],
          ].map(([t, b]) => (
            <div key={t} className="md:border-l md:border-line md:px-8 md:first:border-l-0 md:first:pl-0">
              <h2 className="display-md">{t}</h2>
              <p className="mt-4 leading-relaxed text-muted">{b}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-x py-20 md:py-28">
        <h2 className="display-lg">Our Values</h2>
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {VALUES.map((v) => (
            <li key={v.title} className="rounded-[var(--radius-card)] border border-line bg-white p-6">
              <Icon name={v.icon} className="size-6 text-violet" />
              <h3 className="mt-5 font-display text-lg font-bold">{v.title}</h3>
              <p className="mt-2 text-[0.95rem] leading-relaxed text-muted">{v.body}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="bg-navy text-white">
        <div className="container-x grid gap-12 py-20 md:py-28 lg:grid-cols-2">
          <div>
            <h2 className="display-lg">Founder Experience</h2>
            <p className="mt-6 text-lg leading-relaxed text-white/75">
              Built on practical experience working with e-commerce brands across different product categories, our approach combines campaign execution, email design, marketing automation and performance reporting.
            </p>
            <p className="mt-4 leading-relaxed text-white/60">
              That experience spans gourmet food and gifting, industrial products, natural skincare, apparel, herbal wellness and lifestyle nutrition brands in the USA, Australia and the UAE.
            </p>
            <Link href="/work" className="btn btn-on-dark mt-8">See selected client experience</Link>
          </div>
          <div>
            <h2 className="display-lg">Why Email Marketing Matters</h2>
            <ul className="mt-6 space-y-5">
              {[
                ["You own the relationship", "Your list is not subject to a social platform's algorithm or rising ad costs."],
                ["It reaches people at the right moment", "Automated journeys respond to what each customer actually does."],
                ["It builds repeat purchase", "Post-purchase, replenishment and winback emails bring customers back."],
                ["It is measurable", "Clicks, conversions and revenue can be tracked and improved over time."],
              ].map(([t, b]) => (
                <li key={t} className="flex gap-4">
                  <Icon name="check" className="mt-1 size-5 shrink-0 text-violet" />
                  <div>
                    <h3 className="font-display font-bold">{t}</h3>
                    <p className="mt-1 text-white/65">{b}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
