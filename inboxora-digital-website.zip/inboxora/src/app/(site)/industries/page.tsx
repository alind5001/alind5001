import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { INDUSTRIES } from "@/lib/content/industries";

export const metadata: Metadata = {
  title: "Industries We Serve | E-commerce Email Marketing",
  description:
    "Email marketing for fashion, beauty, jewellery, food and beverage, home, wellness, pet and industrial e-commerce brands: journeys, campaigns, flows and retention.",
  alternates: { canonical: "/industries" },
};

export default function IndustriesPage() {
  return (
    <>
      <PageHero
        crumbs={[{ href: "/industries", label: "Industries" }]}
        title="Email shaped around how your customers buy."
        lede="Every category has its own customer journey and buying rhythm. Here's how we approach email for the industries we work with most."
      />
      <div className="sticky top-[4.5rem] z-30 border-b border-line bg-white/90 backdrop-blur">
        <nav aria-label="Industries" className="container-x flex gap-2 overflow-x-auto py-3 [scrollbar-width:none]">
          {INDUSTRIES.map((i) => (
            <a key={i.slug} href={`#${i.slug}`} className="shrink-0 rounded-full border border-line px-3.5 py-1.5 text-sm text-muted hover:border-navy hover:text-navy">
              {i.name}
            </a>
          ))}
        </nav>
      </div>
      <div className="container-x divide-y divide-line">
        {INDUSTRIES.map((ind) => (
          <section key={ind.slug} id={ind.slug} className="grid scroll-mt-36 gap-10 py-16 md:py-20 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <h2 className="display-md">{ind.name}</h2>
              <p className="mt-4 leading-relaxed text-muted">{ind.card}</p>
            </div>
            <div className="grid gap-8 sm:grid-cols-2 lg:col-span-8">
              <div className="sm:col-span-2">
                <h3 className="font-display font-bold">Typical customer journey</h3>
                <p className="mt-2 leading-relaxed text-ink/80">{ind.journey}</p>
              </div>
              <List title="Email marketing opportunities" items={ind.opportunities} />
              <List title="Recommended campaigns" items={ind.campaigns} />
              <List title="Automation flows" items={ind.flows} />
              <div>
                <h3 className="font-display font-bold">Retention opportunities</h3>
                <p className="mt-2 leading-relaxed text-ink/80">{ind.retention}</p>
              </div>
            </div>
          </section>
        ))}
      </div>
      <section className="container-x pb-4 pt-8 text-center">
        <p className="text-muted">Don&apos;t see your category? <Link href="/contact" className="font-semibold text-blue underline underline-offset-2">Tell us about your store</Link>.</p>
      </section>
      <CtaBand />
    </>
  );
}

function List({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h3 className="font-display font-bold">{title}</h3>
      <ul className="mt-2 space-y-1.5 text-ink/80">
        {items.map((i) => (
          <li key={i} className="flex gap-2.5"><span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-violet" />{i}</li>
        ))}
      </ul>
    </div>
  );
}
