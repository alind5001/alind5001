import Link from "next/link";
import { requireStaff } from "@/lib/admin/auth";
import { isResendConfigured, isTurnstileConfigured, calendlyUrl, hasServiceRole } from "@/lib/env";

export const metadata = { title: "Overview" };

export default async function Overview({ searchParams }: { searchParams: Promise<{ forbidden?: string }> }) {
  const sp = await searchParams;
  const { supabase, role } = await requireStaff();
  if (role === "editor") {
    return (
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Welcome</h1>
        <p className="mt-3 text-muted">As an editor you can manage the <Link className="text-blue underline" href="/admin/portfolio">portfolio</Link> and <Link className="text-blue underline" href="/admin/blog">blog</Link>.</p>
        {sp.forbidden && <p className="mt-4 text-sm text-red-700">That section is for admins only.</p>}
      </div>
    );
  }

  const count = async (table: string, filter?: (q: any) => any) => {
    let q = supabase.from(table).select("id", { count: "exact", head: true });
    if (filter) q = filter(q);
    const { count } = await q;
    return count ?? 0;
  };
  const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString();
  const [total, newLeads, audits, calls, negotiation, won, lost, thisWeek] = await Promise.all([
    count("leads"),
    count("leads", (q) => q.eq("status", "New")),
    count("audit_requests"),
    count("bookings"),
    count("leads", (q) => q.eq("status", "Negotiation")),
    count("leads", (q) => q.eq("status", "Won")),
    count("leads", (q) => q.eq("status", "Lost")),
    count("leads", (q) => q.gte("created_at", weekAgo)),
  ]);
  const { data: recent } = await supabase.from("leads").select("id, source, name, company, status, created_at").order("created_at", { ascending: false }).limit(6);

  const cards = [
    { label: "Total enquiries", value: total, href: "/admin/leads" },
    { label: "New enquiries", value: newLeads, href: "/admin/leads?status=New" },
    { label: "Audit requests", value: audits, href: "/admin/leads?source=audit" },
    { label: "Discovery call requests", value: calls, href: "/admin/leads?source=booking" },
    { label: "Leads in negotiation", value: negotiation, href: "/admin/leads?status=Negotiation" },
    { label: "Won clients", value: won, href: "/admin/leads?status=Won" },
    { label: "Lost leads", value: lost, href: "/admin/leads?status=Lost" },
    { label: "Received in the last 7 days", value: thisWeek, href: "/admin/leads?sort=newest" },
  ];

  const integrations = [
    { name: "Database & admin (Supabase)", ok: hasServiceRole(), hint: "SUPABASE_SERVICE_ROLE_KEY" },
    { name: "Email notifications (Resend)", ok: isResendConfigured(), hint: "RESEND_API_KEY, EMAIL_FROM, AGENCY_NOTIFICATION_EMAIL" },
    { name: "Spam protection (Turnstile)", ok: isTurnstileConfigured(), hint: "NEXT_PUBLIC_TURNSTILE_SITE_KEY, TURNSTILE_SECRET_KEY" },
    { name: "Booking (Calendly embed)", ok: Boolean(calendlyUrl()), hint: "NEXT_PUBLIC_CALENDLY_URL" },
    { name: "Booking records (Calendly API)", ok: Boolean(process.env.CALENDLY_API_TOKEN), hint: "CALENDLY_API_TOKEN" },
    { name: "Analytics (GA4, after consent)", ok: Boolean(process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID), hint: "NEXT_PUBLIC_GA_MEASUREMENT_ID" },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold tracking-tight">Overview</h1>
      <p className="mt-1 text-muted">All figures come from real submissions in your database.</p>

      <ul className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => (
          <li key={c.label}>
            <Link href={c.href} className="block rounded-[var(--radius-card)] border border-line bg-white p-5 hover:border-navy/30">
              <span className="block font-display text-3xl font-extrabold tracking-tight">{c.value}</span>
              <span className="mt-1 block text-sm text-muted">{c.label}</span>
            </Link>
          </li>
        ))}
      </ul>

      <div className="mt-10 grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <section className="rounded-[var(--radius-card)] border border-line bg-white">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <h2 className="font-display font-bold">Latest leads</h2>
            <Link href="/admin/leads" className="text-sm text-blue">View all</Link>
          </div>
          {recent && recent.length > 0 ? (
            <ul className="divide-y divide-line">
              {recent.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-4 px-5 py-3 text-sm">
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{r.name}{r.company ? `, ${r.company}` : ""}</span>
                    <span className="text-muted capitalize">{r.source}, {new Date(r.created_at).toLocaleDateString("en-GB")}</span>
                  </span>
                  <span className="shrink-0 rounded-full bg-mist px-2.5 py-1 text-xs">{r.status}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-muted">No leads yet. New enquiries, audit requests and call bookings will appear here as they arrive.</p>
          )}
        </section>
        <section className="rounded-[var(--radius-card)] border border-line bg-white p-5">
          <h2 className="font-display font-bold">Integrations</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {integrations.map((i) => (
              <li key={i.name} className="flex items-start gap-3">
                <span className={`mt-1 size-2.5 shrink-0 rounded-full ${i.ok ? "bg-emerald-500" : "bg-amber-400"}`} aria-hidden />
                <span>
                  <span className="block font-medium">{i.name}: {i.ok ? "configured" : "not configured"}</span>
                  {!i.ok && <span className="block text-xs text-muted">Set {i.hint}</span>}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-muted">&quot;Configured&quot; means the keys are present. Send a test submission to confirm each one works end to end.</p>
        </section>
      </div>
    </div>
  );
}
