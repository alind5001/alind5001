import { requireStaff } from "@/lib/admin/auth";
import { AdminNav } from "./AdminNav";

export const dynamic = "force-dynamic";

export default async function DashLayout({ children }: { children: React.ReactNode }) {
  const { email, role } = await requireStaff();
  return (
    <div className="lg:grid lg:grid-cols-[15rem_1fr]">
      <AdminNav email={email} role={role} />
      <div className="min-w-0 px-5 py-8 md:px-10 md:py-10">{children}</div>
    </div>
  );
}
