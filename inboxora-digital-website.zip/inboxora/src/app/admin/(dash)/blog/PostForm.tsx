"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { savePost, type PostInput } from "@/app/admin/actions";
import { ImageUpload } from "@/components/admin/ImageUpload";

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

export function PostForm({ initial, categories }: { initial: PostInput; categories: string[] }) {
  const router = useRouter();
  // published_at arrives as ISO (UTC); the input works in the editor's local time.
  const [p, setP] = useState<PostInput>(() => ({ ...initial, published_at: toLocalInput(initial.published_at) }));
  const [tab, setTab] = useState<"write" | "preview">("write");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  const set = <K extends keyof PostInput>(k: K, v: PostInput[K]) => setP((x) => ({ ...x, [k]: v }));
  const words = p.content.trim() ? p.content.trim().split(/\s+/).length : 0;
  const seoTitle = p.seo_title || p.title;
  const metaDesc = p.meta_description || p.excerpt;

  return (
    <form
      className="grid max-w-6xl gap-8 xl:grid-cols-[1fr_20rem]"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await savePost({ ...p, published_at: p.published_at ? new Date(p.published_at).toISOString() : "" });
          if (r.ok) {
            setMsg({ ok: true, text: p.publication_status === "published" ? "Article saved and published." : "Draft saved." });
            if (!p.id && r.id) router.replace(`/admin/blog/${r.id}`); else router.refresh();
          } else setMsg({ ok: false, text: r.error });
        });
      }}
    >
      <div className="min-w-0 space-y-5">
        <div>
          <Link href="/admin/blog" className="text-sm text-muted hover:text-navy">Blog</Link>
          <h1 className="font-display text-3xl font-bold tracking-tight">{p.id ? "Edit article" : "New article"}</h1>
        </div>
        {msg && <p role={msg.ok ? "status" : "alert"} className={`rounded-xl px-4 py-3 text-sm ${msg.ok ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-800"}`}>{msg.text}</p>}
        <label className="block"><span className="field-label">Title</span>
          <input className="field !text-lg font-semibold" required value={p.title} onChange={(e) => { set("title", e.target.value); if (!p.id) set("slug", slugify(e.target.value)); }} />
        </label>
        <label className="block"><span className="field-label">Excerpt</span>
          <textarea className="field" rows={2} value={p.excerpt} onChange={(e) => set("excerpt", e.target.value)} />
        </label>
        <div className="rounded-[var(--radius-card)] border border-line bg-white">
          <div className="flex items-center justify-between border-b border-line px-3 py-2">
            <div role="tablist" className="flex gap-1">
              {(["write", "preview"] as const).map((t) => (
                <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`rounded-lg px-3 py-1.5 text-sm capitalize ${tab === t ? "bg-mist font-semibold" : "text-muted"}`}>{t}</button>
              ))}
            </div>
            <span className="text-xs text-muted">Markdown, {words} words, about {Math.max(1, Math.round(words / 225))} min read</span>
          </div>
          {tab === "write" ? (
            <textarea aria-label="Article content (Markdown)" className="block min-h-[32rem] w-full resize-y rounded-b-[var(--radius-card)] p-4 font-mono text-sm leading-relaxed outline-none" value={p.content} onChange={(e) => set("content", e.target.value)} placeholder={"## Heading\n\nWrite your article in Markdown…"} />
          ) : (
            <div className="prose-article min-h-[32rem] p-6"><ReactMarkdown remarkPlugins={[remarkGfm]}>{p.content || "_Nothing to preview yet._"}</ReactMarkdown></div>
          )}
        </div>
        <p className="text-xs text-muted">Please don&apos;t publish statistics without a credible, linked source.</p>
      </div>

      <aside className="space-y-5">
        <section className="space-y-4 rounded-[var(--radius-card)] border border-line bg-white p-5">
          <h2 className="font-display font-bold">Publishing</h2>
          <label className="block"><span className="field-label">Status</span>
            <select className="field" value={p.publication_status} onChange={(e) => set("publication_status", e.target.value as "draft" | "published")}>
              <option value="draft">Draft</option><option value="published">Published</option>
            </select>
          </label>
          <label className="block"><span className="field-label">Publish date</span>
            <input type="datetime-local" className="field" value={p.published_at} onChange={(e) => set("published_at", e.target.value)} />
            <span className="mt-1 block text-xs text-muted">Leave empty to use the moment you publish. A future date schedules it.</span>
          </label>
          <label className="block"><span className="field-label">Category</span>
            <select className="field" value={p.category} onChange={(e) => set("category", e.target.value)} required>
              {!categories.includes(p.category) && <option value={p.category}>{p.category || "Choose…"}</option>}
              {categories.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="block"><span className="field-label">Author</span><input className="field" value={p.author} onChange={(e) => set("author", e.target.value)} /></label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={p.featured} onChange={(e) => set("featured", e.target.checked)} /> Featured article</label>
          <button className="btn btn-dark w-full" disabled={pending}>{pending ? "Saving…" : p.publication_status === "published" ? "Save & publish" : "Save draft"}</button>
        </section>

        <section className="space-y-3 rounded-[var(--radius-card)] border border-line bg-white p-5">
          <h2 className="font-display font-bold">Featured image</h2>
          {p.featured_image && (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.featured_image} alt="" className="aspect-video w-full rounded-lg object-cover" />
              <button type="button" className="text-sm text-red-700" onClick={() => set("featured_image", "")}>Remove image</button>
            </>
          )}
          <ImageUpload folder="blog" onUploaded={(url) => set("featured_image", url)} />
        </section>

        <section className="space-y-4 rounded-[var(--radius-card)] border border-line bg-white p-5">
          <h2 className="font-display font-bold">SEO</h2>
          <label className="block"><span className="field-label">URL slug</span><input className="field" required value={p.slug} onChange={(e) => set("slug", slugify(e.target.value))} /></label>
          <label className="block"><span className="field-label">SEO title <span className="font-normal text-muted">({seoTitle.length}/70)</span></span><input className="field" value={p.seo_title} placeholder={p.title} onChange={(e) => set("seo_title", e.target.value)} /></label>
          <label className="block"><span className="field-label">Meta description <span className="font-normal text-muted">({metaDesc.length}/170)</span></span><textarea className="field" rows={3} value={p.meta_description} placeholder={p.excerpt} onChange={(e) => set("meta_description", e.target.value)} /></label>
          <div className="rounded-lg bg-mist p-3 text-sm">
            <p className="truncate text-[#1a0dab]">{seoTitle || "Article title"} | Inboxora Digital</p>
            <p className="truncate text-xs text-emerald-700">/insights/{p.slug}</p>
            <p className="line-clamp-2 text-xs text-muted">{metaDesc || "Meta description preview"}</p>
          </div>
        </section>
      </aside>
    </form>
  );
}

function toLocalInput(iso: string) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
