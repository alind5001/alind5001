import { requireStaff } from "@/lib/admin/auth";
import { PostForm } from "../PostForm";

export const metadata = { title: "New article" };

export default async function NewPost() {
  const { supabase } = await requireStaff();
  const { data: cats } = await supabase.from("blog_categories").select("name").order("name");
  return (
    <PostForm
      categories={(cats ?? []).map((c) => c.name)}
      initial={{ title: "", slug: "", excerpt: "", content: "", category: cats?.[0]?.name ?? "", author: "Inboxora Digital", featured: false, featured_image: "", seo_title: "", meta_description: "", publication_status: "draft", published_at: "" }}
    />
  );
}
