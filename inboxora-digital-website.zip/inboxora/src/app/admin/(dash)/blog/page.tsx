import Link from "next/link";
import { requireStaff } from "@/lib/admin/auth";
import { PostRowActions } from "./PostRowActions";

export const metadata = { title: "Blog" };

export default async function BlogAdmin({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  const sp = await searchParams;
  const { supabase } = await requireStaff();
  let q = supabase.from("blog_posts").select("id, title, slug, category, featured, publication_status, published_at, updated_at").order("published_at", { ascending: false, nullsFirst: true });
  if (sp.status === "draft" || sp.status === "published") q = q.eq("publication_status", sp.status);
  const term = (sp.q || "").replace(/[,()*%\\]/g, " ").trim();
  if (term) q = q.ilike("title", `%${term}%`);
  const { data: rows, error } = await q;
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Blog</h1>
          <p className="mt-1 text-muted">Articles published on Insights.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/blog/categories" className="btn btn-ghost !py-2.5 text-sm">Categories</Link>
          <Link href="/admin/blog/new" className="btn btn-dark !py-2.5 text-sm">New article</Link>
        </div>
      </div>
      <form className="mt-6 flex flex-wrap gap-3" role="search">
        <input name="q" defaultValue={sp.q} placeholder="Search titles" className="field max-w-xs" aria-label="Search titles" />
        <select name="status" defaultValue={sp.status ?? ""} className="field !w-auto" aria-label="Status">
          <option value="">All</option><option value="published">Published</option><option value="draft">Drafts</option>
        </select>
        <button className="btn btn-dark !py-2.5 text-sm">Filter</button>
      </form>
      {error && <p role="alert" className="mt-4 text-sm text-red-700">{error.message}</p>}
      <div className="mt-6 overflow-x-auto rounded-[var(--radius-card)] border border-line bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b border-line bg-mist text-xs text-muted">
            <tr>{["Title", "Category", "Published", "Status", ""].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-line">
            {(rows ?? []).map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3 font-medium"><Link className="hover:text-blue" href={`/admin/blog/${p.id}`}>{p.title}</Link>{p.featured && <span className="ml-2 rounded-full bg-violet/10 px-2 py-0.5 text-xs text-violet">Featured</span>}</td>
                <td className="px-4 py-3">{p.category}</td>
                <td className="whitespace-nowrap px-4 py-3">{p.published_at ? new Date(p.published_at).toLocaleDateString("en-GB") : "—"}</td>
                <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${p.publication_status === "published" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-700"}`}>{p.publication_status}</span></td>
                <td className="px-4 py-3"><PostRowActions id={p.id} slug={p.slug} status={p.publication_status} title={p.title} /></td>
              </tr>
            ))}
            {rows?.length === 0 && <tr><td colSpan={5} className="px-4 py-10 text-center text-muted">No articles found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
