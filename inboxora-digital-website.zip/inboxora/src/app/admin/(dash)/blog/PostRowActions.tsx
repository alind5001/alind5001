"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { deletePost, setPostStatus } from "@/app/admin/actions";

export function PostRowActions({ id, slug, status, title }: { id: string; slug: string; status: string; title: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <div className="flex flex-wrap justify-end gap-3 text-sm">
      <Link href={`/admin/blog/${id}`} className="text-blue hover:underline">Edit</Link>
      {status === "published" && <a href={`/insights/${slug}`} target="_blank" className="text-muted hover:underline">View</a>}
      <button type="button" disabled={pending} className="text-muted hover:underline" onClick={() => start(async () => {
        const r = await setPostStatus(id, status === "published" ? "draft" : "published"); if (!r.ok) alert(r.error); router.refresh();
      })}>{status === "published" ? "Unpublish" : "Publish"}</button>
      <button type="button" disabled={pending} className="text-red-700 hover:underline" onClick={() => {
        if (!confirm(`Delete "${title}"? This can't be undone.`)) return;
        start(async () => { const r = await deletePost(id); if (!r.ok) alert(r.error); router.refresh(); });
      }}>Delete</button>
    </div>
  );
}
