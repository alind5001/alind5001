import { notFound } from "next/navigation";
import { requireStaff } from "@/lib/admin/auth";
import { PostForm } from "../PostForm";

export const metadata = { title: "Edit article" };

export default async function EditPost({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await requireStaff();
  const [{ data: p }, { data: cats }] = await Promise.all([
    supabase.from("blog_posts").select("*").eq("id", id).maybeSingle(),
    supabase.from("blog_categories").select("name").order("name"),
  ]);
  if (!p) notFound();
  return (
    <PostForm
      categories={(cats ?? []).map((c) => c.name)}
      initial={{
        id: p.id, title: p.title, slug: p.slug, excerpt: p.excerpt ?? "", content: p.content ?? "", category: p.category, author: p.author,
        featured: p.featured, featured_image: p.featured_image ?? "", seo_title: p.seo_title ?? "", meta_description: p.meta_description ?? "",
        publication_status: p.publication_status, published_at: p.published_at ?? "",
      }}
    />
  );
}
