import { requireStaff } from "@/lib/admin/auth";
import { CategoryManager } from "./CategoryManager";

export const metadata = { title: "Blog categories" };

export default async function Categories() {
  const { supabase } = await requireStaff();
  const { data } = await supabase.from("blog_categories").select("id, name, slug").order("name");
  return <CategoryManager categories={data ?? []} />;
}
