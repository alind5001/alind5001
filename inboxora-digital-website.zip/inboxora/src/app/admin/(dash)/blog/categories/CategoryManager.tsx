"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { deleteCategory, saveCategory } from "@/app/admin/actions";

export function CategoryManager({ categories }: { categories: { id: string; name: string; slug: string }[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [pending, start] = useTransition();
  return (
    <div className="max-w-xl">
      <Link href="/admin/blog" className="text-sm text-muted hover:text-navy">Blog</Link>
      <h1 className="font-display text-3xl font-bold tracking-tight">Categories</h1>
      <form className="mt-6 flex gap-2" onSubmit={(e) => { e.preventDefault(); start(async () => { const r = await saveCategory(name); if (r.ok) { setName(""); setErr(""); router.refresh(); } else setErr(r.error); }); }}>
        <input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="New category name" aria-label="New category name" />
        <button className="btn btn-dark !py-2.5 text-sm" disabled={pending}>Add</button>
      </form>
      {err && <p role="alert" className="mt-2 text-sm text-red-700">{err}</p>}
      <ul className="mt-6 divide-y divide-line rounded-[var(--radius-card)] border border-line bg-white">
        {categories.map((c) => (
          <li key={c.id} className="flex items-center justify-between px-4 py-3">
            <span>{c.name} <span className="text-xs text-muted">/{c.slug}</span></span>
            <button type="button" className="text-sm text-red-700 hover:underline" disabled={pending} onClick={() => {
              if (!confirm(`Delete category "${c.name}"?`)) return;
              start(async () => { const r = await deleteCategory(c.id, c.name); if (!r.ok) setErr(r.error); router.refresh(); });
            }}>Delete</button>
          </li>
        ))}
        {categories.length === 0 && <li className="px-4 py-8 text-center text-sm text-muted">No categories yet.</li>}
      </ul>
    </div>
  );
}
