"use client";

import { useState } from "react";
import { createBrowserSupabase } from "@/lib/supabase/browser";

export default function PasswordPage() {
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  return (
    <div className="max-w-md">
      <h1 className="font-display text-3xl font-bold tracking-tight">Change password</h1>
      <form
        className="mt-8 space-y-4 rounded-[var(--radius-card)] border border-line bg-white p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          const p1 = String(fd.get("p1")), p2 = String(fd.get("p2"));
          setMsg(""); setErr("");
          if (p1.length < 12) return setErr("Use at least 12 characters.");
          if (p1 !== p2) return setErr("Passwords don't match.");
          const { error } = await createBrowserSupabase().auth.updateUser({ password: p1 });
          if (error) setErr(error.message); else { setMsg("Password updated."); e.currentTarget.reset(); }
        }}
      >
        <div><label className="field-label" htmlFor="p1">New password</label><input id="p1" name="p1" type="password" autoComplete="new-password" className="field" required /></div>
        <div><label className="field-label" htmlFor="p2">Confirm new password</label><input id="p2" name="p2" type="password" autoComplete="new-password" className="field" required /></div>
        {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
        {msg && <p role="status" className="text-sm text-emerald-700">{msg}</p>}
        <button className="btn btn-dark">Update password</button>
      </form>
    </div>
  );
}
