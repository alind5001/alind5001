"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { saveProject, type ProjectInput } from "@/app/admin/actions";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { PORTFOLIO_CATEGORIES } from "@/lib/content/site";

const toLines = (a: string[]) => a.join("\n");
const fromLines = (s: string) => s.split("\n").map((l) => l.trim()).filter(Boolean);
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

export function ProjectForm({ initial }: { initial: ProjectInput }) {
  const router = useRouter();
  const [p, setP] = useState<ProjectInput>(initial);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  const set = <K extends keyof ProjectInput>(k: K, v: ProjectInput[K]) => setP((x) => ({ ...x, [k]: v }));
  const setCs = <K extends keyof ProjectInput["case_study"]>(k: K, v: ProjectInput["case_study"][K]) => setP((x) => ({ ...x, case_study: { ...x.case_study, [k]: v } }));

  return (
    <form
      className="max-w-4xl space-y-8"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await saveProject(p);
          if (r.ok) {
            setMsg({ ok: true, text: "Project saved." });
            if (!p.id && r.id) router.replace(`/admin/portfolio/${r.id}`);
            else router.refresh();
          } else setMsg({ ok: false, text: r.error });
        });
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <Link href="/admin/portfolio" className="text-sm text-muted hover:text-navy">Portfolio</Link>
          <h1 className="font-display text-3xl font-bold tracking-tight">{p.id ? p.brand_name || "Edit project" : "New project"}</h1>
        </div>
        <div className="flex items-center gap-3">
          <select aria-label="Publication status" className="field !w-auto" value={p.publication_status} onChange={(e) => set("publication_status", e.target.value as "draft" | "published")}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
          <button className="btn btn-dark" disabled={pending}>{pending ? "Saving…" : "Save project"}</button>
        </div>
      </div>
      {msg && <p role={msg.ok ? "status" : "alert"} className={`rounded-xl px-4 py-3 text-sm ${msg.ok ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-800"}`}>{msg.text}</p>}

      <Card title="Brand">
        <div className="grid gap-4 sm:grid-cols-2">
          <In label="Brand name" value={p.brand_name} onChange={(v) => { set("brand_name", v); if (!p.id && !p.slug) set("slug", slugify(v)); }} required />
          <In label="URL slug" value={p.slug} onChange={(v) => set("slug", slugify(v))} hint={`/work/${p.slug || "…"}`} required />
          <In label="Website" value={p.website} onChange={(v) => set("website", v)} placeholder="https://" />
          <In label="Industry" value={p.industry} onChange={(v) => set("industry", v)} />
          <In label="Country" value={p.country} onChange={(v) => set("country", v)} />
          <In label="Display order" type="number" value={String(p.sort_order)} onChange={(v) => set("sort_order", Number(v) || 0)} />
        </div>
        <Ta label="Short description" value={p.description} onChange={(v) => set("description", v)} rows={2} />
        <In label="Attribution label" value={p.attribution} onChange={(v) => set("attribution", v)} hint="Shown on the case study. Keep it accurate about how the work was done." />
      </Card>

      <Card title="Services and categories">
        <Ta label="Project services (one per line)" value={toLines(p.services)} onChange={(v) => set("services", fromLines(v))} rows={5} />
        <fieldset>
          <legend className="field-label">Portfolio categories (used for filtering)</legend>
          <div className="flex flex-wrap gap-2">
            {PORTFOLIO_CATEGORIES.map((c) => {
              const on = p.categories.includes(c);
              return (
                <label key={c} className={`cursor-pointer rounded-full border px-3 py-1.5 text-sm ${on ? "border-navy bg-navy text-white" : "border-line bg-white"}`}>
                  <input type="checkbox" className="sr-only" checked={on} onChange={() => set("categories", on ? p.categories.filter((x) => x !== c) : [...p.categories, c])} />
                  {c}
                </label>
              );
            })}
          </div>
        </fieldset>
      </Card>

      <Card title="Case study">
        <Ta label="Brand overview" value={p.case_study.overview} onChange={(v) => setCs("overview", v)} rows={3} />
        <Ta label="Business context" value={p.case_study.context} onChange={(v) => setCs("context", v)} rows={3} />
        <Ta label="Marketing objectives (one per line)" value={toLines(p.case_study.objectives)} onChange={(v) => setCs("objectives", fromLines(v))} rows={4} />
        <Ta label="Email marketing strategy" value={p.case_study.strategy} onChange={(v) => setCs("strategy", v)} rows={3} />
        <Ta label="Work executed (one per line)" value={toLines(p.case_study.workExecuted)} onChange={(v) => setCs("workExecuted", fromLines(v))} rows={4} />
        <Ta label="Campaign examples (one per line)" value={toLines(p.case_study.campaignExamples)} onChange={(v) => setCs("campaignExamples", fromLines(v))} rows={3} />
        <Ta label="Automation examples (one per line, optional)" value={toLines(p.case_study.automationExamples)} onChange={(v) => setCs("automationExamples", fromLines(v))} rows={3} />
      </Card>

      <Card title="Verified results">
        <Ta label="Verified results (optional)" value={p.verified_results} onChange={(v) => set("verified_results", v)} rows={4} hint="Only add figures you can verify and have permission to publish, with their source and time period. Leave empty to show no project-level results." />
      </Card>

      <Card title="Images">
        <p className="text-sm text-muted">Upload real email screenshots you have permission to show. Mark anything that isn&apos;t real client work as a concept design; the site labels it publicly.</p>
        <ul className="grid gap-4 sm:grid-cols-2">
          {p.images.map((img, i) => (
            <li key={img.url} className="rounded-xl border border-line p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={img.url} alt="" className="h-40 w-full rounded-lg bg-mist object-contain" />
              <div className="mt-3 space-y-2">
                <input className="field" placeholder="Caption / alt text" value={img.caption} onChange={(e) => set("images", p.images.map((x, j) => (j === i ? { ...x, caption: e.target.value } : x)))} />
                <select className="field" value={img.category} onChange={(e) => set("images", p.images.map((x, j) => (j === i ? { ...x, category: e.target.value } : x)))}>
                  {PORTFOLIO_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={img.concept} onChange={(e) => set("images", p.images.map((x, j) => (j === i ? { ...x, concept: e.target.checked } : x)))} /> Concept design (not real client work)</label>
                <div className="flex justify-between text-sm">
                  <span className="flex gap-3">
                    <button type="button" disabled={i === 0} className="text-muted disabled:opacity-40" onClick={() => { const a = [...p.images]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; set("images", a); }}>Move up</button>
                    <button type="button" disabled={i === p.images.length - 1} className="text-muted disabled:opacity-40" onClick={() => { const a = [...p.images]; [a[i + 1], a[i]] = [a[i], a[i + 1]]; set("images", a); }}>Move down</button>
                  </span>
                  <button type="button" className="text-red-700" onClick={() => { if (confirm("Remove this image from the project? Save to apply.")) set("images", p.images.filter((_, j) => j !== i)); }}>Remove</button>
                </div>
              </div>
            </li>
          ))}
        </ul>
        <ImageUpload folder="portfolio" label="Upload screenshot" onUploaded={(url) => set("images", [...p.images, { url, caption: "", category: p.categories[0] ?? PORTFOLIO_CATEGORIES[0], concept: false }])} />
        <p className="text-xs text-muted">Uploaded images are attached when you save the project.</p>
      </Card>
    </form>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-4 rounded-[var(--radius-card)] border border-line bg-white p-6">
      <h2 className="font-display text-lg font-bold">{title}</h2>
      {children}
    </section>
  );
}
function In({ label, value, onChange, hint, ...rest }: { label: string; value: string; onChange: (v: string) => void; hint?: string } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <input className="field" value={value} onChange={(e) => onChange(e.target.value)} {...rest} />
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}
function Ta({ label, value, onChange, hint, rows = 4 }: { label: string; value: string; onChange: (v: string) => void; hint?: string; rows?: number }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <textarea className="field" rows={rows} value={value} onChange={(e) => onChange(e.target.value)} />
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}
