import { notFound } from "next/navigation";
import { requireStaff } from "@/lib/admin/auth";
import { ProjectForm } from "../ProjectForm";
import type { ProjectInput } from "@/app/admin/actions";

export const metadata = { title: "Edit project" };

export default async function EditProject({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await requireStaff();
  const { data } = await supabase.from("portfolio_projects").select("*").eq("id", id).maybeSingle();
  if (!data) notFound();
  const cs = data.case_study ?? {};
  const initial: ProjectInput = {
    id: data.id, slug: data.slug, brand_name: data.brand_name, website: data.website ?? "", industry: data.industry ?? "", country: data.country ?? "",
    description: data.description ?? "", services: data.services ?? [], categories: data.categories ?? [], images: data.images ?? [],
    verified_results: data.verified_results ?? "", attribution: data.attribution, publication_status: data.publication_status, sort_order: data.sort_order,
    case_study: {
      overview: cs.overview ?? "", context: cs.context ?? "", objectives: cs.objectives ?? [], strategy: cs.strategy ?? "",
      workExecuted: cs.workExecuted ?? [], campaignExamples: cs.campaignExamples ?? [], automationExamples: cs.automationExamples ?? [],
    },
  };
  return <ProjectForm initial={initial} />;
}
