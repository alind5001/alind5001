"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { deleteProject, setProjectStatus } from "@/app/admin/actions";

export function ProjectRowActions({ id, slug, status, name }: { id: string; slug: string; status: string; name: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <div className="flex flex-wrap justify-end gap-3 text-sm">
      <Link href={`/admin/portfolio/${id}`} className="text-blue hover:underline">Edit</Link>
      {status === "published" && <a href={`/work/${slug}`} target="_blank" className="text-muted hover:underline">View</a>}
      <button type="button" disabled={pending} className="text-muted hover:underline" onClick={() => start(async () => {
        const r = await setProjectStatus(id, status === "published" ? "draft" : "published");
        if (!r.ok) alert(r.error); router.refresh();
      })}>{status === "published" ? "Unpublish" : "Publish"}</button>
      <button type="button" disabled={pending} className="text-red-700 hover:underline" onClick={() => {
        if (!confirm(`Delete ${name}? This can't be undone.`)) return;
        start(async () => { const r = await deleteProject(id); if (!r.ok) alert(r.error); router.refresh(); });
      }}>Delete</button>
    </div>
  );
}
