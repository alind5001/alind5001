import { requireStaff } from "@/lib/admin/auth";
import { ProjectForm } from "../ProjectForm";
import { ATTRIBUTION } from "@/lib/content/brands";

export const metadata = { title: "New project" };

export default async function NewProject() {
  await requireStaff();
  return (
    <ProjectForm
      initial={{
        slug: "", brand_name: "", website: "", industry: "", country: "", description: "",
        services: [], categories: [], images: [], verified_results: "",
        case_study: { overview: "", context: "", objectives: [], strategy: "", workExecuted: [], campaignExamples: [], automationExamples: [] },
        attribution: ATTRIBUTION, publication_status: "draft", sort_order: 100,
      }}
    />
  );
}
