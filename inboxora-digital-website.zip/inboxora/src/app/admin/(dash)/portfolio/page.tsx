import Link from "next/link";
import { requireStaff } from "@/lib/admin/auth";
import { ProjectRowActions } from "./ProjectRowActions";

export const metadata = { title: "Portfolio" };

export default async function PortfolioAdmin() {
  const { supabase } = await requireStaff();
  const { data: rows, error } = await supabase.from("portfolio_projects").select("id, slug, brand_name, industry, country, publication_status, images, sort_order, updated_at").order("sort_order");
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Portfolio</h1>
          <p className="mt-1 text-muted">Projects and case studies shown on Our Work.</p>
        </div>
        <Link href="/admin/portfolio/new" className="btn btn-dark !py-2.5 text-sm">Add project</Link>
      </div>
      {error && <p role="alert" className="mt-4 text-sm text-red-700">{error.message}</p>}
      <div className="mt-6 overflow-x-auto rounded-[var(--radius-card)] border border-line bg-white">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-line bg-mist text-xs text-muted">
            <tr>{["Order", "Brand", "Industry", "Country", "Images", "Status", ""].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-line">
            {(rows ?? []).map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3 text-muted">{p.sort_order}</td>
                <td className="px-4 py-3 font-medium"><Link href={`/admin/portfolio/${p.id}`} className="hover:text-blue">{p.brand_name}</Link></td>
                <td className="px-4 py-3">{p.industry}</td>
                <td className="px-4 py-3">{p.country}</td>
                <td className="px-4 py-3">{Array.isArray(p.images) ? p.images.length : 0}</td>
                <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${p.publication_status === "published" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-700"}`}>{p.publication_status}</span></td>
                <td className="px-4 py-3"><ProjectRowActions id={p.id} slug={p.slug} status={p.publication_status} name={p.brand_name} /></td>
              </tr>
            ))}
            {rows?.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-muted">No projects yet. Add your first project, or run supabase/seed.sql to load the six launch case studies.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
