"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { saveSettings, type SettingsKey } from "@/app/admin/actions";
import type { SiteSettings } from "@/lib/types";

const TABS: { key: SettingsKey | "portfolio"; label: string }[] = [
  { key: "contact", label: "Contact" },
  { key: "social", label: "Social links" },
  { key: "stats", label: "Homepage statistics" },
  { key: "pricing", label: "Pricing" },
  { key: "services", label: "Services" },
  { key: "legal", label: "Legal pages" },
  { key: "portfolio", label: "Portfolio content" },
];

export function SettingsEditor({ initial }: { initial: SiteSettings }) {
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("contact");
  const [s, setS] = useState<SiteSettings>(initial);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  const router = useRouter();

  const save = (key: SettingsKey) =>
    start(async () => {
      const r = await saveSettings(key, s[key]);
      setMsg(r.ok ? { ok: true, text: "Saved. The public site updates within a few seconds." } : { ok: false, text: r.error });
      if (r.ok) router.refresh();
    });

  const up = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => { setS((x) => ({ ...x, [k]: v })); setMsg(null); };

  return (
    <div className="max-w-5xl">
      <h1 className="font-display text-3xl font-bold tracking-tight">Website settings</h1>
      <div role="tablist" className="mt-6 flex gap-1 overflow-x-auto border-b border-line">
        {TABS.map((t) => (
          <button key={t.key} role="tab" aria-selected={tab === t.key} type="button" onClick={() => { setTab(t.key); setMsg(null); }} className={`shrink-0 border-b-2 px-3 py-2.5 text-sm font-medium ${tab === t.key ? "border-navy text-navy" : "border-transparent text-muted hover:text-navy"}`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-6 rounded-[var(--radius-card)] border border-line bg-white p-6">
        {tab === "contact" && (
          <div className="grid gap-4 sm:grid-cols-2">
            <F label="Business name" v={s.contact.businessName} on={(v) => up("contact", { ...s.contact, businessName: v })} />
            <F label="Business email" type="email" v={s.contact.email} on={(v) => up("contact", { ...s.contact, email: v })} />
            <F label="Phone number (display)" v={s.contact.phone} on={(v) => up("contact", { ...s.contact, phone: v })} />
            <F label="WhatsApp number (digits with country code)" v={s.contact.whatsapp} on={(v) => up("contact", { ...s.contact, whatsapp: v.replace(/\D/g, "") })} hint={`Links to https://wa.me/${s.contact.whatsapp}`} />
            <F label="Location" v={s.contact.location} on={(v) => up("contact", { ...s.contact, location: v })} />
            <F label="Operating model" v={s.contact.operatingModel} on={(v) => up("contact", { ...s.contact, operatingModel: v })} />
          </div>
        )}

        {tab === "social" && (
          <div className="grid gap-4 sm:grid-cols-2">
            {(["linkedin", "instagram", "x", "facebook"] as const).map((k) => (
              <F key={k} label={k === "x" ? "X (Twitter)" : k[0].toUpperCase() + k.slice(1)} v={s.social[k]} placeholder="https://" on={(v) => up("social", { ...s.social, [k]: v })} />
            ))}
            <p className="text-sm text-muted sm:col-span-2">Leave a field empty to hide that link.</p>
          </div>
        )}

        {tab === "stats" && (
          <div className="space-y-5">
            <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Only publish figures you can substantiate. Keep the methodology disclosure accurate for whatever you show.</p>
            {s.stats.items.map((it, i) => (
              <div key={i} className="grid gap-3 rounded-xl border border-line p-4 sm:grid-cols-[8rem_1fr]">
                <F label="Value" v={it.value} on={(v) => up("stats", { ...s.stats, items: s.stats.items.map((x, j) => (j === i ? { ...x, value: v } : x)) })} />
                <F label="Label" v={it.label} on={(v) => up("stats", { ...s.stats, items: s.stats.items.map((x, j) => (j === i ? { ...x, label: v } : x)) })} />
                <T className="sm:col-span-2" label="Detail" rows={2} v={it.detail} on={(v) => up("stats", { ...s.stats, items: s.stats.items.map((x, j) => (j === i ? { ...x, detail: v } : x)) })} />
              </div>
            ))}
            <T label="Supporting text" rows={3} v={s.stats.summary} on={(v) => up("stats", { ...s.stats, summary: v })} />
            <T label="Methodology disclosure" rows={4} v={s.stats.disclosure} on={(v) => up("stats", { ...s.stats, disclosure: v })} />
          </div>
        )}

        {tab === "pricing" && (
          <div className="space-y-5">
            {s.pricing.packages.map((pk, i) => {
              const setPk = (patch: Partial<typeof pk>) => up("pricing", { ...s.pricing, packages: s.pricing.packages.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
              return (
                <div key={pk.id} className="grid gap-3 rounded-xl border border-line p-4 sm:grid-cols-3">
                  <F label="Package name" v={pk.name} on={(v) => setPk({ name: v })} />
                  <F label="Starting price" v={pk.price} on={(v) => setPk({ price: v })} />
                  <F label="Period" v={pk.period} on={(v) => setPk({ period: v })} />
                  <T className="sm:col-span-3" label="Description" rows={2} v={pk.description} on={(v) => setPk({ description: v })} />
                  <T className="sm:col-span-3" label="Features (one per line)" rows={6} v={pk.features.join("\n")} on={(v) => setPk({ features: v.split("\n").map((l) => l.trim()).filter(Boolean) })} />
                  <F label="Button text" v={pk.cta} on={(v) => setPk({ cta: v })} />
                  <F label="Button link" v={pk.ctaHref} on={(v) => setPk({ ctaHref: v })} />
                  <label className="flex items-end gap-2 pb-3 text-sm"><input type="checkbox" checked={pk.highlighted} onChange={(e) => setPk({ highlighted: e.target.checked })} /> Highlight this package</label>
                </div>
              );
            })}
            <T label="Pricing notes (one per line)" rows={6} v={s.pricing.notes.join("\n")} on={(v) => up("pricing", { ...s.pricing, notes: v.split("\n").map((l) => l.trim()).filter(Boolean) })} />
          </div>
        )}

        {tab === "services" && (
          <div className="space-y-4">
            <p className="text-sm text-muted">Inactive services are hidden everywhere on the public site. Future services (ads, social, SMS and others) stay inactive until you&apos;re ready to offer them. Detailed page content for the seven core services lives in the codebase.</p>
            {[...s.services.items].sort((a, b) => a.order - b.order).map((sv) => {
              const setSv = (patch: Partial<typeof sv>) => up("services", { items: s.services.items.map((x) => (x.slug === sv.slug ? { ...x, ...patch } : x)) });
              return (
                <details key={sv.slug} className={`rounded-xl border p-4 ${sv.active ? "border-line" : "border-dashed border-line bg-mist/60"}`}>
                  <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-3">
                    <span className="font-semibold">{sv.title}</span>
                    <span className="flex items-center gap-4 text-sm" onClick={(e) => e.stopPropagation()}>
                      <label className="flex items-center gap-1.5"><input type="checkbox" checked={sv.active} onChange={(e) => setSv({ active: e.target.checked })} /> Active</label>
                      <label className="flex items-center gap-1.5"><input type="checkbox" checked={sv.onHome} onChange={(e) => setSv({ onHome: e.target.checked })} /> On homepage</label>
                    </span>
                  </summary>
                  <div className="mt-4 grid gap-3 sm:grid-cols-3">
                    <F label="Title" v={sv.title} on={(v) => setSv({ title: v })} />
                    <F label="Short title" v={sv.shortTitle} on={(v) => setSv({ shortTitle: v })} />
                    <F label="Order" type="number" v={String(sv.order)} on={(v) => setSv({ order: Number(v) || 0 })} />
                    <T className="sm:col-span-3" label="Summary" rows={2} v={sv.summary} on={(v) => setSv({ summary: v })} />
                    <T className="sm:col-span-3" label="Bullet points (one per line)" rows={6} v={sv.bullets.join("\n")} on={(v) => setSv({ bullets: v.split("\n").map((l) => l.trim()).filter(Boolean) })} />
                  </div>
                </details>
              );
            })}
          </div>
        )}

        {tab === "legal" && (
          <div className="space-y-5">
            <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">These are starting templates. Have them reviewed by a qualified legal professional for your business and markets. Markdown is supported.</p>
            <F label="Last updated (YYYY-MM-DD)" v={s.legal.updated} on={(v) => up("legal", { ...s.legal, updated: v })} />
            <T label="Privacy Policy" rows={14} mono v={s.legal.privacy} on={(v) => up("legal", { ...s.legal, privacy: v })} />
            <T label="Terms and Conditions" rows={14} mono v={s.legal.terms} on={(v) => up("legal", { ...s.legal, terms: v })} />
            <T label="Cookie Policy" rows={14} mono v={s.legal.cookies} on={(v) => up("legal", { ...s.legal, cookies: v })} />
          </div>
        )}

        {tab === "portfolio" && (
          <p className="text-muted">Portfolio projects, case studies, screenshots and verified results are managed in <Link className="font-semibold text-blue underline" href="/admin/portfolio">Portfolio</Link>.</p>
        )}

        {tab !== "portfolio" && (
          <div className="mt-6 flex flex-wrap items-center gap-4 border-t border-line pt-5">
            <button type="button" className="btn btn-dark" disabled={pending} onClick={() => save(tab)}>{pending ? "Saving…" : "Save changes"}</button>
            {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-700" : "text-red-700"}`}>{msg.text}</p>}
          </div>
        )}
      </div>
    </div>
  );
}

function F({ label, v, on, hint, type = "text", placeholder }: { label: string; v: string; on: (v: string) => void; hint?: string; type?: string; placeholder?: string }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <input type={type} className="field" value={v} placeholder={placeholder} onChange={(e) => on(e.target.value)} />
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}
function T({ label, v, on, rows = 3, className = "", mono = false }: { label: string; v: string; on: (v: string) => void; rows?: number; className?: string; mono?: boolean }) {
  return (
    <label className={`block ${className}`}>
      <span className="field-label">{label}</span>
      <textarea className={`field ${mono ? "font-mono text-sm" : ""}`} rows={rows} value={v} onChange={(e) => on(e.target.value)} />
    </label>
  );
}
