import { requireStaff } from "@/lib/admin/auth";
import { getSettings } from "@/lib/data";
import { SettingsEditor } from "./SettingsEditor";

export const metadata = { title: "Settings" };

export default async function SettingsPage() {
  await requireStaff("admin");
  const settings = await getSettings();
  return <SettingsEditor initial={settings} />;
}
