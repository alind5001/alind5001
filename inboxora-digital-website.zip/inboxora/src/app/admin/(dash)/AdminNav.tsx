"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { LogoMark } from "@/components/ui/Logo";
import { Icon, type IconName } from "@/components/ui/Icon";
import { createBrowserSupabase } from "@/lib/supabase/browser";

const ITEMS: { href: string; label: string; icon: IconName; adminOnly?: boolean }[] = [
  { href: "/admin", label: "Overview", icon: "chart", adminOnly: true },
  { href: "/admin/leads", label: "Leads", icon: "users", adminOnly: true },
  { href: "/admin/portfolio", label: "Portfolio", icon: "image" },
  { href: "/admin/blog", label: "Blog", icon: "pen" },
  { href: "/admin/settings", label: "Settings", icon: "layers", adminOnly: true },
];

export function AdminNav({ email, role }: { email: string; role: string }) {
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const items = ITEMS.filter((i) => !i.adminOnly || role !== "editor");
  const active = (h: string) => (h === "/admin" ? path === "/admin" : path.startsWith(h));

  return (
    <aside className="border-b border-line bg-navy text-white lg:sticky lg:top-0 lg:h-screen lg:border-b-0">
      <div className="flex items-center justify-between px-5 py-4 lg:py-6">
        <Link href="/admin" className="flex items-center gap-2.5">
          <LogoMark className="size-8" />
          <span className="font-display text-sm font-extrabold tracking-[0.08em]">INBOXORA</span>
        </Link>
        <button type="button" className="rounded-full p-2 hover:bg-white/10 lg:hidden" aria-expanded={open} aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          <Icon name={open ? "close" : "menu"} />
        </button>
      </div>
      <nav className={`${open ? "block" : "hidden"} px-3 pb-4 lg:block`} aria-label="Admin">
        <ul className="space-y-1">
          {items.map((i) => (
            <li key={i.href}>
              <Link href={i.href} onClick={() => setOpen(false)} aria-current={active(i.href) ? "page" : undefined} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${active(i.href) ? "bg-white/12 text-white" : "text-white/65 hover:bg-white/5 hover:text-white"}`}>
                <Icon name={i.icon} className="size-[1.1rem]" /> {i.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="mt-6 border-t border-white/10 px-3 pt-5 text-sm lg:absolute lg:inset-x-3 lg:bottom-6">
          <p className="truncate text-white/80">{email}</p>
          <p className="text-xs capitalize text-white/45">{role}</p>
          <div className="mt-3 flex gap-3">
            <Link href="/" target="_blank" className="text-white/60 hover:text-white">View site</Link>
            <Link href="/admin/password" className="text-white/60 hover:text-white">Password</Link>
            <button
              type="button"
              className="text-white/60 hover:text-white"
              onClick={async () => { await createBrowserSupabase().auth.signOut(); router.replace("/admin/login"); router.refresh(); }}
            >
              Sign out
            </button>
          </div>
        </div>
      </nav>
    </aside>
  );
}
