import Link from "next/link";
import { requireStaff } from "@/lib/admin/auth";
import { queryLeads } from "@/lib/admin/leads";
import { LEAD_STATUSES } from "@/lib/types";
import { LeadsTable } from "./LeadsTable";

export const metadata = { title: "Leads" };

type SP = { q?: string; source?: string; status?: string; sort?: string; id?: string };

export default async function LeadsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const { supabase } = await requireStaff("admin");
  const { rows, error } = await queryLeads(supabase, sp);
  const qs = new URLSearchParams(Object.entries(sp).filter(([k, v]) => v && k !== "id") as [string, string][]).toString();

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Leads</h1>
          <p className="mt-1 text-muted">Enquiries, audit requests and discovery calls in one place.</p>
        </div>
        <a href={`/admin/leads-export${qs ? `?${qs}` : ""}`} className="btn btn-ghost !py-2.5 text-sm">Export CSV</a>
      </div>

      <form className="mt-6 grid gap-3 rounded-[var(--radius-card)] border border-line bg-white p-4 sm:grid-cols-2 lg:grid-cols-[1fr_auto_auto_auto_auto]" role="search">
        <label className="sr-only" htmlFor="lq">Search</label>
        <input id="lq" name="q" defaultValue={sp.q} placeholder="Search name, email, company, website, notes" className="field" />
        <label className="sr-only" htmlFor="ls">Source</label>
        <select id="ls" name="source" defaultValue={sp.source ?? ""} className="field">
          <option value="">All sources</option>
          <option value="contact">Enquiries</option>
          <option value="audit">Audit requests</option>
          <option value="booking">Discovery calls</option>
        </select>
        <label className="sr-only" htmlFor="lst">Status</label>
        <select id="lst" name="status" defaultValue={sp.status ?? ""} className="field">
          <option value="">All statuses</option>
          {LEAD_STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <label className="sr-only" htmlFor="lso">Sort</label>
        <select id="lso" name="sort" defaultValue={sp.sort ?? "newest"} className="field">
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
          <option value="name">Name A–Z</option>
          <option value="status">Status</option>
        </select>
        <div className="flex gap-2">
          <button className="btn btn-dark !py-2.5 text-sm">Apply</button>
          {qs && <Link href="/admin/leads" className="btn btn-ghost !py-2.5 text-sm">Reset</Link>}
        </div>
      </form>

      {error && <p role="alert" className="mt-4 text-sm text-red-700">Couldn&apos;t load leads: {error}</p>}
      <p className="mt-5 text-sm text-muted">{rows.length} {rows.length === 1 ? "lead" : "leads"}{rows.length === 500 ? " (showing the first 500; narrow your filters)" : ""}</p>
      <LeadsTable rows={rows} openId={sp.id} />
    </div>
  );
}
