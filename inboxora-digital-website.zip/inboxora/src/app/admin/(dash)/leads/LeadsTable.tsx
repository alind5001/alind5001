"use client";

import { Fragment, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { LEAD_STATUSES, type Lead } from "@/lib/types";
import { deleteLead, updateLead } from "@/app/admin/actions";

const ref = (l: Lead) => `${{ contact: "ENQ", audit: "AUD", booking: "CALL" }[l.source]}-${l.id.slice(0, 8).toUpperCase()}`;
const STATUS_TONE: Record<string, string> = {
  New: "bg-blue/10 text-blue",
  Contacted: "bg-slate-100 text-slate-700",
  "Discovery Call Scheduled": "bg-violet/10 text-violet",
  "Proposal Sent": "bg-amber-100 text-amber-800",
  Negotiation: "bg-orange-100 text-orange-800",
  Won: "bg-emerald-100 text-emerald-800",
  Lost: "bg-red-100 text-red-700",
};

export function LeadsTable({ rows, openId }: { rows: Lead[]; openId?: string }) {
  const [open, setOpen] = useState<string | null>(openId ?? null);
  if (rows.length === 0) {
    return <div className="mt-4 rounded-[var(--radius-card)] border border-dashed border-line bg-white p-12 text-center text-muted">No leads match these filters yet.</div>;
  }
  return (
    <div className="mt-3 overflow-x-auto rounded-[var(--radius-card)] border border-line bg-white">
      <table className="w-full min-w-[1100px] text-left text-sm">
        <thead className="border-b border-line bg-mist text-xs text-muted">
          <tr>
            {["Lead ID", "Name", "Email", "Business", "Website", "Country", "Interested service", "Budget", "Received", "Status", "Internal notes", ""].map((h) => (
              <th key={h} scope="col" className="px-3 py-3 font-semibold">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {rows.map((l) => (
            <Fragment key={`${l.source}-${l.id}`}>
              <tr className={open === l.id ? "bg-blue/[0.03]" : ""}>
                <td className="whitespace-nowrap px-3 py-3 font-mono text-xs">{ref(l)}</td>
                <td className="whitespace-nowrap px-3 py-3 font-medium">{l.name}</td>
                <td className="px-3 py-3"><a className="text-blue hover:underline" href={`mailto:${l.email}`}>{l.email}</a></td>
                <td className="px-3 py-3">{l.company ?? "—"}</td>
                <td className="max-w-[10rem] truncate px-3 py-3">{l.website ? <a className="hover:underline" href={l.website} target="_blank" rel="noopener noreferrer nofollow">{l.website.replace(/^https?:\/\//, "")}</a> : "—"}</td>
                <td className="px-3 py-3">{l.country ?? "—"}</td>
                <td className="px-3 py-3">{l.service ?? "—"}</td>
                <td className="whitespace-nowrap px-3 py-3">{l.budget ?? "—"}</td>
                <td className="whitespace-nowrap px-3 py-3">{new Date(l.created_at).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}</td>
                <td className="px-3 py-3"><StatusSelect lead={l} /></td>
                <td className="max-w-[12rem] truncate px-3 py-3 text-muted" title={l.notes ?? ""}>{l.notes || "—"}</td>
                <td className="px-3 py-3">
                  <button type="button" className="text-blue hover:underline" aria-expanded={open === l.id} onClick={() => setOpen(open === l.id ? null : l.id)}>
                    {open === l.id ? "Close" : "Details"}
                  </button>
                </td>
              </tr>
              {open === l.id && (
                <tr className="bg-blue/[0.03]">
                  <td colSpan={12} className="px-3 pb-5 pt-1"><LeadDetail lead={l} onDeleted={() => setOpen(null)} /></td>
                </tr>
              )}
            </Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StatusSelect({ lead }: { lead: Lead }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [value, setValue] = useState(lead.status);
  return (
    <select
      aria-label={`Status for ${lead.name}`}
      value={value}
      disabled={pending}
      onChange={(e) => {
        const prev = value;
        const next = e.target.value as Lead["status"];
        setValue(next);
        start(async () => {
          const r = await updateLead(lead.source, lead.id, { status: next });
          if (!r.ok) { setValue(prev); alert(r.error); } else router.refresh();
        });
      }}
      className={`rounded-full border-0 px-2.5 py-1 text-xs font-semibold ${STATUS_TONE[value] ?? ""}`}
    >
      {LEAD_STATUSES.map((s) => <option key={s}>{s}</option>)}
    </select>
  );
}

function LeadDetail({ lead, onDeleted }: { lead: Lead; onDeleted: () => void }) {
  const router = useRouter();
  const [notes, setNotes] = useState(lead.notes ?? "");
  const [saved, setSaved] = useState("");
  const [pending, start] = useTransition();
  return (
    <div className="grid gap-5 rounded-xl border border-line bg-white p-5 md:grid-cols-2">
      <div>
        <h3 className="text-xs font-semibold text-muted">Submission details ({lead.source})</h3>
        <p className="mt-2 whitespace-pre-wrap leading-relaxed">{lead.details || "—"}</p>
      </div>
      <div>
        <label htmlFor={`n-${lead.id}`} className="text-xs font-semibold text-muted">Internal notes</label>
        <textarea id={`n-${lead.id}`} value={notes} onChange={(e) => { setNotes(e.target.value); setSaved(""); }} rows={5} className="field mt-2" placeholder="Calls, next steps, proposal details…" />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="btn btn-dark !py-2 text-sm"
              disabled={pending}
              onClick={() => start(async () => {
                const r = await updateLead(lead.source, lead.id, { notes });
                setSaved(r.ok ? "Notes saved." : r.error);
                if (r.ok) router.refresh();
              })}
            >
              Save notes
            </button>
            {saved && <span role="status" className="text-sm text-muted">{saved}</span>}
          </div>
          <button
            type="button"
            className="text-sm text-red-700 hover:underline"
            disabled={pending}
            onClick={() => {
              if (!confirm(`Delete this lead from ${lead.name}? This can't be undone.`)) return;
              start(async () => {
                const r = await deleteLead(lead.source, lead.id);
                if (r.ok) { onDeleted(); router.refresh(); } else alert(r.error);
              });
            }}
          >
            Delete lead
          </button>
        </div>
      </div>
    </div>
  );
}
