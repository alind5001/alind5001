"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { staffOrError } from "@/lib/admin/auth";
import { LEAD_STATUSES, type LeadSource } from "@/lib/types";

type Result = { ok: true; id?: string } | { ok: false; error: string };

const TABLE: Record<LeadSource, string> = { contact: "contacts", audit: "audit_requests", booking: "bookings" };
const sourceSchema = z.enum(["contact", "audit", "booking"]);
const uuid = z.string().uuid();

function revalidatePublic(paths: string[]) {
  for (const p of paths) revalidatePath(p, p.includes("[") ? "page" : undefined);
}

/* ------------------------------- Leads ---------------------------------- */

export async function updateLead(source: string, id: string, patch: { status?: string; notes?: string }): Promise<Result> {
  const g = await staffOrError("admin");
  if ("error" in g) return { ok: false, error: g.error! };
  const s = sourceSchema.safeParse(source);
  if (!s.success || !uuid.safeParse(id).success) return { ok: false, error: "Invalid lead." };
  const update: Record<string, string> = {};
  if (patch.status !== undefined) {
    if (!(LEAD_STATUSES as readonly string[]).includes(patch.status)) return { ok: false, error: "Invalid status." };
    update.status = patch.status;
  }
  if (patch.notes !== undefined) update.notes = patch.notes.slice(0, 10000);
  const { error } = await g.supabase.from(TABLE[s.data]).update(update).eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/admin/leads");
  revalidatePath("/admin");
  return { ok: true };
}

export async function updateMeetingStatus(id: string, meeting_status: string): Promise<Result> {
  const g = await staffOrError("admin");
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success || !["requested", "scheduled", "completed", "cancelled", "no_show"].includes(meeting_status)) return { ok: false, error: "Invalid input." };
  const { error } = await g.supabase.from("bookings").update({ meeting_status }).eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/admin/leads");
  return { ok: true };
}

export async function deleteLead(source: string, id: string): Promise<Result> {
  const g = await staffOrError("admin");
  if ("error" in g) return { ok: false, error: g.error! };
  const s = sourceSchema.safeParse(source);
  if (!s.success || !uuid.safeParse(id).success) return { ok: false, error: "Invalid lead." };
  const { error, count } = await g.supabase.from(TABLE[s.data]).delete({ count: "exact" }).eq("id", id);
  if (error) return { ok: false, error: error.message };
  if (!count) return { ok: false, error: "Lead not found or not permitted." };
  revalidatePath("/admin/leads");
  revalidatePath("/admin");
  return { ok: true };
}

/* ------------------------------ Uploads --------------------------------- */

const ALLOWED = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif" } as const;
const MAX_BYTES = 5 * 1024 * 1024;

async function sniff(file: File): Promise<keyof typeof ALLOWED | null> {
  const b = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return "image/gif";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  return null;
}

/** Secure image upload: staff only, 5 MB max, PNG/JPEG/WebP/GIF verified by file signature, random file name. */
export async function uploadImage(fd: FormData): Promise<{ ok: true; url: string } | { ok: false; error: string }> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  const file = fd.get("file");
  const folder = String(fd.get("folder") || "misc").replace(/[^a-z0-9-]/gi, "").slice(0, 40) || "misc";
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose an image to upload." };
  if (file.size > MAX_BYTES) return { ok: false, error: "Images must be 5 MB or smaller." };
  const type = await sniff(file);
  if (!type) return { ok: false, error: "Only PNG, JPEG, WebP or GIF images are allowed." };
  const path = `${folder}/${crypto.randomUUID()}.${ALLOWED[type]}`;
  const { error } = await g.supabase.storage.from("media").upload(path, file, { contentType: type, upsert: false, cacheControl: "31536000" });
  if (error) return { ok: false, error: error.message };
  const { data } = g.supabase.storage.from("media").getPublicUrl(path);
  return { ok: true, url: data.publicUrl };
}

export async function deleteImage(url: string): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  const marker = "/storage/v1/object/public/media/";
  const i = url.indexOf(marker);
  if (i === -1) return { ok: true }; // external URL: nothing to remove from storage
  const path = decodeURIComponent(url.slice(i + marker.length));
  const { error } = await g.supabase.storage.from("media").remove([path]);
  return error ? { ok: false, error: error.message } : { ok: true };
}

/* ------------------------------ Portfolio ------------------------------- */

const slug = z.string().trim().toLowerCase().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Slug can only use lowercase letters, numbers and hyphens.");
const lines = z.array(z.string().trim().min(1).max(300)).max(40);

const projectSchema = z.object({
  id: z.string().uuid().optional(),
  slug,
  brand_name: z.string().trim().min(1, "Brand name is required.").max(120),
  website: z.union([z.literal(""), z.string().trim().url("Website must be a full URL (https://…).")]),
  industry: z.string().trim().max(120),
  country: z.string().trim().max(80),
  description: z.string().trim().max(1000),
  services: lines,
  categories: lines,
  images: z.array(z.object({ url: z.string().url(), caption: z.string().max(200), category: z.string().max(80), concept: z.boolean() })).max(40),
  verified_results: z.string().trim().max(4000),
  case_study: z.object({
    overview: z.string().max(3000),
    context: z.string().max(3000),
    objectives: lines,
    strategy: z.string().max(3000),
    workExecuted: lines,
    campaignExamples: lines,
    automationExamples: lines,
  }),
  attribution: z.string().trim().max(200),
  publication_status: z.enum(["draft", "published"]),
  sort_order: z.number().int().min(0).max(10000),
});
export type ProjectInput = z.infer<typeof projectSchema>;

export async function saveProject(input: ProjectInput): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  const p = projectSchema.safeParse(input);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message ?? "Invalid project." };
  const { id, ...row } = p.data;
  const payload = { ...row, website: row.website || null, verified_results: row.verified_results || null };
  const q = id ? g.supabase.from("portfolio_projects").update(payload).eq("id", id).select("id").single() : g.supabase.from("portfolio_projects").insert(payload).select("id").single();
  const { data, error } = await q;
  if (error) return { ok: false, error: error.code === "23505" ? "Another project already uses that slug." : error.message };
  revalidatePublic(["/", "/work", "/work/[slug]", "/services/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/portfolio");
  return { ok: true, id: data.id };
}

export async function deleteProject(id: string): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success) return { ok: false, error: "Invalid project." };
  const { error } = await g.supabase.from("portfolio_projects").delete().eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePublic(["/", "/work", "/work/[slug]", "/services/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/portfolio");
  return { ok: true };
}

/* -------------------------------- Blog ---------------------------------- */

const postSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1, "Title is required.").max(200),
  slug,
  excerpt: z.string().trim().max(400),
  content: z.string().max(100000),
  category: z.string().trim().min(1, "Choose a category.").max(80),
  author: z.string().trim().min(1).max(120),
  featured: z.boolean(),
  featured_image: z.union([z.literal(""), z.string().url()]),
  seo_title: z.string().trim().max(70, "SEO title should be 70 characters or fewer."),
  meta_description: z.string().trim().max(170, "Meta description should be 170 characters or fewer."),
  publication_status: z.enum(["draft", "published"]),
  published_at: z.string().max(40),
});
export type PostInput = z.infer<typeof postSchema>;

export async function savePost(input: PostInput): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  const p = postSchema.safeParse(input);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message ?? "Invalid article." };
  const { id, ...row } = p.data;
  let published_at: string | null = row.published_at ? new Date(row.published_at).toISOString() : null;
  if (row.publication_status === "published" && !published_at) published_at = new Date().toISOString();
  const payload = { ...row, published_at, featured_image: row.featured_image || null, seo_title: row.seo_title || null, meta_description: row.meta_description || null };
  const q = id ? g.supabase.from("blog_posts").update(payload).eq("id", id).select("id").single() : g.supabase.from("blog_posts").insert(payload).select("id").single();
  const { data, error } = await q;
  if (error) return { ok: false, error: error.code === "23505" ? "Another article already uses that slug." : error.message };
  revalidatePublic(["/insights", "/insights/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/blog");
  return { ok: true, id: data.id };
}

export async function deletePost(id: string): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success) return { ok: false, error: "Invalid article." };
  const { error } = await g.supabase.from("blog_posts").delete().eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePublic(["/insights", "/insights/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/blog");
  return { ok: true };
}

export async function setPostStatus(id: string, status: "draft" | "published"): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success) return { ok: false, error: "Invalid article." };
  const patch: Record<string, unknown> = { publication_status: status };
  if (status === "published") {
    const { data } = await g.supabase.from("blog_posts").select("published_at").eq("id", id).single();
    if (!data?.published_at) patch.published_at = new Date().toISOString();
  }
  const { error } = await g.supabase.from("blog_posts").update(patch).eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePublic(["/insights", "/insights/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/blog");
  return { ok: true };
}

export async function setProjectStatus(id: string, status: "draft" | "published"): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success) return { ok: false, error: "Invalid project." };
  const { error } = await g.supabase.from("portfolio_projects").update({ publication_status: status }).eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePublic(["/", "/work", "/work/[slug]", "/services/[slug]", "/sitemap.xml"]);
  revalidatePath("/admin/portfolio");
  return { ok: true };
}

export async function saveCategory(name: string): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  const n = name.trim().slice(0, 60);
  if (!n) return { ok: false, error: "Enter a category name." };
  const s = n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const { error } = await g.supabase.from("blog_categories").insert({ name: n, slug: s });
  if (error) return { ok: false, error: error.code === "23505" ? "That category already exists." : error.message };
  revalidatePath("/admin/blog/categories");
  revalidatePath("/insights");
  return { ok: true };
}

export async function deleteCategory(id: string, name: string): Promise<Result> {
  const g = await staffOrError();
  if ("error" in g) return { ok: false, error: g.error! };
  if (!uuid.safeParse(id).success) return { ok: false, error: "Invalid category." };
  const { count } = await g.supabase.from("blog_posts").select("id", { count: "exact", head: true }).eq("category", name);
  if (count) return { ok: false, error: `${count} article${count === 1 ? " uses" : "s use"} this category. Move them first.` };
  const { error } = await g.supabase.from("blog_categories").delete().eq("id", id);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/admin/blog/categories");
  return { ok: true };
}

/* ------------------------------ Settings -------------------------------- */

const settingsSchemas = {
  contact: z.object({
    businessName: z.string().trim().min(1).max(120),
    email: z.string().trim().email(),
    phone: z.string().trim().min(5).max(30),
    whatsapp: z.string().trim().regex(/^\d{8,15}$/, "WhatsApp number: digits only, with country code (e.g. 917355309230)."),
    location: z.string().trim().max(160),
    operatingModel: z.string().trim().max(80),
  }),
  social: z.object({
    linkedin: z.union([z.literal(""), z.string().url()]),
    instagram: z.union([z.literal(""), z.string().url()]),
    x: z.union([z.literal(""), z.string().url()]),
    facebook: z.union([z.literal(""), z.string().url()]),
  }),
  stats: z.object({
    items: z.array(z.object({ value: z.string().trim().min(1).max(20), label: z.string().trim().min(1).max(80), detail: z.string().trim().max(300) })).min(1).max(4),
    summary: z.string().trim().max(600),
    disclosure: z.string().trim().min(20, "Keep a methodology disclosure alongside any statistic.").max(1200),
  }),
  pricing: z.object({
    packages: z.array(z.object({
      id: z.string().max(40), name: z.string().trim().min(1).max(80), price: z.string().trim().min(1).max(20), period: z.string().max(20),
      description: z.string().max(300), features: z.array(z.string().trim().min(1).max(160)).max(20), cta: z.string().trim().min(1).max(40),
      ctaHref: z.string().trim().regex(/^\/[^\s]*$/, "Button links must be site paths starting with /."), highlighted: z.boolean(),
    })).min(1).max(4),
    notes: z.array(z.string().trim().min(1).max(200)).max(10),
  }),
  services: z.object({
    items: z.array(z.object({
      slug: z.string().regex(/^[a-z0-9-]+$/), title: z.string().trim().min(1).max(120), shortTitle: z.string().trim().min(1).max(80),
      summary: z.string().max(300), bullets: z.array(z.string().trim().min(1).max(120)).max(12), active: z.boolean(), onHome: z.boolean(), order: z.number().int(),
    })).max(30),
  }),
  legal: z.object({ privacy: z.string().max(60000), terms: z.string().max(60000), cookies: z.string().max(60000), updated: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }),
};
export type SettingsKey = keyof typeof settingsSchemas;

export async function saveSettings(key: SettingsKey, value: unknown): Promise<Result> {
  const g = await staffOrError("admin");
  if ("error" in g) return { ok: false, error: g.error! };
  const schema = settingsSchemas[key];
  if (!schema) return { ok: false, error: "Unknown settings section." };
  const p = schema.safeParse(value);
  if (!p.success) {
    const i = p.error.issues[0];
    return { ok: false, error: `${i?.path.join(" › ") || key}: ${i?.message}` };
  }
  if (key === "services") {
    const active = (p.data as z.infer<typeof settingsSchemas.services>).items.filter((s) => s.active && !s.summary.trim());
    if (active.length) return { ok: false, error: `Add a summary before activating: ${active.map((a) => a.title).join(", ")}.` };
  }
  const { error } = await g.supabase.from("site_settings").upsert({ key, value: p.data, updated_by: g.user.id });
  if (error) return { ok: false, error: error.message };
  revalidatePath("/", "layout");
  return { ok: true };
}
