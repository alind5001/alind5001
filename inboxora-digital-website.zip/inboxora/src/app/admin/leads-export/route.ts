import { NextResponse } from "next/server";
import { staffOrError } from "@/lib/admin/auth";
import { leadRef, queryLeads } from "@/lib/admin/leads";

export const dynamic = "force-dynamic";

const cell = (v: unknown) => {
  let s = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // neutralise spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`;
};

export async function GET(req: Request) {
  const g = await staffOrError("admin");
  if ("error" in g) return NextResponse.json({ error: g.error }, { status: 401 });
  const sp = Object.fromEntries(new URL(req.url).searchParams);
  const { rows, error } = await queryLeads(g.supabase, sp, 10000);
  if (error) return NextResponse.json({ error }, { status: 500 });
  const head = ["Lead ID", "Source", "Name", "Email", "Business", "Website", "Country", "Interested Service", "Budget", "Date Received", "Status", "Internal Notes", "Details"];
  const lines = rows.map((l) => [leadRef(l), l.source, l.name, l.email, l.company, l.website, l.country, l.service, l.budget, l.created_at, l.status, l.notes, l.details].map(cell).join(","));
  const csv = "﻿" + [head.map(cell).join(","), ...lines].join("\r\n");
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="inboxora-leads-${new Date().toISOString().slice(0, 10)}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
