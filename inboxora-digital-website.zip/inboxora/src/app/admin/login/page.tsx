import { LogoMark } from "@/components/ui/Logo";
import { LoginForm } from "./LoginForm";
import { isSupabaseConfigured } from "@/lib/env";

type Props = { searchParams: Promise<{ setup?: string; denied?: string; next?: string }> };

export default async function LoginPage({ searchParams }: Props) {
  const sp = await searchParams;
  const configured = isSupabaseConfigured();
  const next = sp.next && sp.next.startsWith("/admin") ? sp.next : "/admin";
  return (
    <main className="grid min-h-screen place-items-center px-5 py-16">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-3">
          <LogoMark className="size-10" />
          <div>
            <p className="font-display font-extrabold tracking-[0.08em]">INBOXORA</p>
            <p className="text-sm text-muted">Admin dashboard</p>
          </div>
        </div>
        <div className="mt-8 rounded-[var(--radius-card)] border border-line bg-white p-7 shadow-[var(--shadow-float)]">
          <h1 className="font-display text-xl font-bold">Sign in</h1>
          {!configured ? (
            <div className="mt-4 rounded-xl bg-amber-50 p-4 text-sm leading-relaxed text-amber-900">
              The admin area needs Supabase. Add <code>NEXT_PUBLIC_SUPABASE_URL</code>, <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> and <code>SUPABASE_SERVICE_ROLE_KEY</code> to your environment, run the database migration, then redeploy. See SETUP.md.
            </div>
          ) : (
            <>
              {sp.denied && (
                <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">This account doesn&apos;t have admin access. Ask the site owner to add you, or sign in with a different account.</p>
              )}
              <LoginForm next={next} signOutFirst={Boolean(sp.denied)} />
            </>
          )}
        </div>
      </div>
    </main>
  );
}
