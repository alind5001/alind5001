"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createBrowserSupabase } from "@/lib/supabase/browser";

export function LoginForm({ next, signOutFirst }: { next: string; signOutFirst: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [mode, setMode] = useState<"signin" | "reset">("signin");
  const [info, setInfo] = useState("");

  useEffect(() => {
    if (signOutFirst) createBrowserSupabase().auth.signOut();
  }, [signOutFirst]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email") || "").trim();
    const password = String(fd.get("password") || "");
    setBusy(true);
    setError("");
    setInfo("");
    const sb = createBrowserSupabase();
    if (mode === "reset") {
      const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/auth/callback?next=/admin/password` });
      setBusy(false);
      if (error) setError(error.message);
      else setInfo("If that email has an account, a reset link is on its way.");
      return;
    }
    const { error } = await sb.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      setError("Email or password is incorrect.");
      return;
    }
    router.replace(next);
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="mt-5 space-y-4">
      <div>
        <label htmlFor="email" className="field-label">Email</label>
        <input id="email" name="email" type="email" autoComplete="username" required className="field" />
      </div>
      {mode === "signin" && (
        <div>
          <label htmlFor="password" className="field-label">Password</label>
          <input id="password" name="password" type="password" autoComplete="current-password" required className="field" />
        </div>
      )}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      {info && <p role="status" className="text-sm text-emerald-700">{info}</p>}
      <button type="submit" className="btn btn-dark w-full" disabled={busy}>
        {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Send reset link"}
      </button>
      <button type="button" className="w-full text-sm text-muted hover:text-navy" onClick={() => { setMode(mode === "signin" ? "reset" : "signin"); setError(""); setInfo(""); }}>
        {mode === "signin" ? "Forgot password?" : "Back to sign in"}
      </button>
    </form>
  );
}
