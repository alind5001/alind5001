# Inboxora Digital — Setup and launch guide

This guide takes the codebase from a zip file to a live site. Budget about an hour.
Everything marked **Required** must be done before launch; **Recommended** items can follow shortly after.

The site already runs without any configuration: public pages render from built-in launch content,
and forms show a friendly "email or WhatsApp us" message until the backend is connected.

---

## 1. Run it locally

Requires Node.js 20 or newer.

```bash
npm install
cp .env.example .env.local      # fill in values as you complete the steps below
npm run dev                     # http://localhost:3000
```

---

## 2. Supabase — database, admin login, file storage (Required)

1. Create a project at https://supabase.com (choose a region close to your visitors, e.g. Mumbai or Singapore).
2. **SQL Editor → New query**: paste all of `supabase/migrations/0001_init.sql` and run it.
   This creates every table, the `leads` view, Row Level Security policies, and the public `media` storage bucket.
3. Run `supabase/seed.sql` the same way. It loads the six client-experience case studies, the ten launch
   articles and the blog categories. (It is safe to re-run; existing rows are not overwritten.)
4. **Authentication → Providers → Email**: keep Email enabled. **Authentication → Settings**: turn **off**
   "Allow new users to sign up" so nobody can create an account on your project.
5. **Authentication → Users → Add user**: create your admin account with a strong password (12+ characters).
6. Make that user the site owner. In the SQL Editor run (replace the email):

   ```sql
   insert into public.admin_users (user_id, email, role)
   select id, email, 'owner' from auth.users where email = 'you@YOUR-DOMAIN.com';
   ```

   Roles: `owner` / `admin` see everything (leads, settings). `editor` can only manage the blog and portfolio.
7. **Authentication → URL Configuration**: set Site URL to `https://YOUR-DOMAIN.com` and add
   `https://YOUR-DOMAIN.com/auth/callback` to Redirect URLs (used by "Forgot password").
8. **Project Settings → API**: copy into your environment:
   - `NEXT_PUBLIC_SUPABASE_URL` — Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` — anon / publishable key
   - `SUPABASE_SERVICE_ROLE_KEY` — service_role / secret key. **Server only. Never put this in a `NEXT_PUBLIC_` variable.**
9. Optional housekeeping: schedule `select public.prune_submission_log();` daily
   (Database → Cron) to delete rate-limit records older than two days.

Admin dashboard: `https://YOUR-DOMAIN.com/admin`

---

## 3. Resend — email notifications (Required)

1. Create an account at https://resend.com and **add your domain** (Domains → Add Domain).
2. Add the DNS records Resend shows (SPF, DKIM, and a DMARC record if you don't have one) at your domain registrar.
   Wait until the domain shows **Verified**.
3. Create an API key with "Sending access".
4. Set:
   - `RESEND_API_KEY`
   - `EMAIL_FROM` — e.g. `Inboxora Digital <hello@YOUR-DOMAIN.com>` (must be on the verified domain)
   - `AGENCY_NOTIFICATION_EMAIL` — where new-lead alerts go

What gets sent: for every enquiry, audit request and call request, an internal notification (reply-to is the visitor)
and a one-time acknowledgement to the visitor. Nobody is added to any mailing list. If Resend isn't configured,
submissions are still saved and the server log notes which emails were skipped.

---

## 4. Domain and business email (Required)

- Replace `hello@YOUR-DOMAIN.com` in **Admin → Settings → Contact** once your domain mailbox exists
  (the code default is in `src/lib/content/site.ts`).
- Set `NEXT_PUBLIC_SITE_URL=https://YOUR-DOMAIN.com` (no trailing slash). It drives canonical URLs, the sitemap,
  Open Graph tags and links in notification emails.

---

## 5. Cloudflare Turnstile — spam protection (Recommended)

Every form already has a honeypot field, a minimum fill time, same-origin checks, per-IP rate limits
(stored in Postgres, so they work on serverless) and duplicate detection. Turnstile adds a CAPTCHA layer.

1. https://dash.cloudflare.com → Turnstile → Add site → your domain, widget mode "Managed".
2. Set `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY`.

---

## 6. Calendly — discovery calls (Recommended)

Until this is set up, `/book-a-call` shows a request form that records a preferred date and time window.
It never displays availability, so there are no fake slots.

1. In Calendly, create a **30-minute** event type ("Discovery call"). Add questions for company and website if you like.
2. Set `NEXT_PUBLIC_CALENDLY_URL` to its public link (e.g. `https://calendly.com/inboxora/discovery-call`).
   The booking page then embeds Calendly: visitors pick a real date and time in their own time zone and get
   Calendly's confirmation email.
3. To store bookings in your dashboard and send the Inboxora confirmation email too, create a
   **Personal Access Token** (Calendly → Integrations → API & Webhooks) and set `CALENDLY_API_TOKEN`.
   The site verifies each booking with Calendly's API before saving it.
4. Optional, paid Calendly plans: create a webhook subscription for `invitee.created` and `invitee.canceled`
   pointing to `https://YOUR-DOMAIN.com/api/calendly/webhook`, and set `CALENDLY_WEBHOOK_SIGNING_KEY`.
   This also catches cancellations.

---

## 7. Google Analytics 4 (Recommended)

Create a GA4 property and web stream, then set `NEXT_PUBLIC_GA_MEASUREMENT_ID` (`G-XXXXXXX`).
GA only loads after a visitor clicks "Accept analytics" in the cookie banner; Google Signals and ad personalisation
are disabled. Visitors can change their choice any time via "Cookie settings" in the footer.

---

## 8. Security salt (Required)

Set `IP_HASH_SALT` to a long random string (`openssl rand -hex 32`). Visitor IPs are only stored as salted hashes.

---

## 9. Deploy to Vercel

1. Push this folder to a private GitHub repository.
2. https://vercel.com → Add New Project → import the repository (framework is detected as Next.js).
3. Add every environment variable from `.env.example` under **Settings → Environment Variables**.
4. Deploy, then add your domain under **Settings → Domains**.
5. Re-deploy after changing any `NEXT_PUBLIC_` variable (those are built into the page code).

---

## 10. Content to review before launch

- **Legal pages** — Admin → Settings → Legal pages. These are starting templates covering India's DPDP Act,
  GDPR, CAN-SPAM and CASL basics. Have them reviewed by a qualified lawyer.
- **Homepage statistics** — Admin → Settings → Homepage statistics. Keep the methodology disclosure accurate.
- **Portfolio** — Admin → Portfolio. Upload real email screenshots only where you have permission to show them.
  Tick "Concept design" on anything that isn't real client work; the site labels it publicly. Add verified results
  only with their source and time period.
- **Platform logos** — the Platforms section shows names, not logos. If you want logos, download them from each
  vendor's official brand/press page and follow their usage guidelines.
- **Brand imagery** — client cards use neutral backgrounds rather than brand logos. Add brand images through the
  portfolio manager only where the brand has given permission.
- **Social links** — Admin → Settings → Social links (empty links are hidden).
- **Future services** — Admin → Settings → Services. Ads, social, CRM, SMS, CRO, Shopify optimisation and marketing
  automation exist but are inactive. Activating one (after adding a summary and bullets) publishes it on the
  services pages, footer and contact form. For a full detail page, add its content to `src/lib/content/services.ts`.

---

## 11. Go-live test (please do this once with real credentials)

The code paths were tested end-to-end against a local stand-in for Supabase (see TESTING.md), but these
integrations can only be confirmed with your live accounts:

1. Submit the contact form → row appears in Admin → Leads; agency notification and visitor acknowledgement both arrive.
2. Submit the audit form → same checks.
3. Book a Calendly test call → Calendly email arrives; with `CALENDLY_API_TOKEN` set the booking appears in Leads.
4. Upload a screenshot in Admin → Portfolio, save, and check it on `/work`.
5. Publish a draft article and confirm it appears on `/insights` within a minute.
6. Open `/admin` in a private window → you should be sent to the login page.
7. Accept analytics in the cookie banner → check GA4 Realtime shows your visit.
8. Submit `https://YOUR-DOMAIN.com/sitemap.xml` in Google Search Console.

---

## Environment variables at a glance

| Variable | Required | Where it comes from |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Yes | Your domain |
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Supabase → Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Supabase → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Supabase → Settings → API (secret) |
| `RESEND_API_KEY` | Yes | Resend → API Keys |
| `EMAIL_FROM` | Yes | An address on your Resend-verified domain |
| `AGENCY_NOTIFICATION_EMAIL` | Yes | Your inbox |
| `IP_HASH_SALT` | Yes | `openssl rand -hex 32` |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` | Recommended | Cloudflare Turnstile |
| `NEXT_PUBLIC_CALENDLY_URL` | Recommended | Calendly event link |
| `CALENDLY_API_TOKEN` | Recommended | Calendly personal access token |
| `CALENDLY_WEBHOOK_SIGNING_KEY` | Optional | Calendly webhook (paid plans) |
| `NEXT_PUBLIC_GA_MEASUREMENT_ID` | Recommended | GA4 data stream |
