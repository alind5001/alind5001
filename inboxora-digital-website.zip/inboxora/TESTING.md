# Test record

Tested on 1 November 2026 with a production build (`next build && next start`).

## How it was tested

- **Database and security policies**: `supabase/migrations/0001_init.sql` and `supabase/seed.sql` were run in an
  in-memory Postgres (PGlite) with stand-ins for Supabase's `auth` and `storage` schemas, then each policy was
  exercised as an anonymous visitor, a signed-in non-staff user, an editor and an owner.
- **Forms, APIs and admin**: run against a local stand-in for Supabase's REST and Auth APIs, using a real browser
  (Playwright/Chromium) and direct HTTP requests.
- **Not testable without your accounts**: real Supabase, Resend delivery, Turnstile verification, the Calendly
  embed/API and GA4. These are built and wired up; confirm them with the go-live test in SETUP.md §11.

## Results

| # | Area | Result |
| --- | --- | --- |
| 1 | All pages (36 sitemap URLs + admin) build and render | Pass |
| 2 | Navigation links | Pass |
| 3 | CTA buttons route to audit, booking, contact and plan-prefilled contact | Pass |
| 4 | Mobile hamburger menu opens and navigates | Pass (fixed a bug where the panel was trapped inside the blurred header) |
| 5 | Contact form: field errors, success state, plan prefill | Pass |
| 6 | Audit form: validation of URL/platform/required fields, success | Pass |
| 7 | Database submissions stored with normalised email and URL | Pass (stand-in) |
| 8 | Admin authentication: redirect when signed out, wrong password rejected, sign in, sign out | Pass (stand-in auth) |
| 9 | Admin overview counts from real data only | Pass |
| 10 | Lead management: list, filter by source, status update, notes, CSV export, delete with confirmation | Pass |
| 11 | Portfolio filtering by category and search | Pass |
| 12 | Portfolio editing and save | Pass; image upload code validated by type check, needs live storage to confirm |
| 13 | Blog search on Insights | Pass |
| 14 | Blog create, Markdown preview, publish | Pass |
| 15 | Email notifications | Code path runs; skipped with a logged notice when Resend is not configured. Needs live Resend |
| 16 | WhatsApp link `https://wa.me/917355309230` | Pass |
| 17 | Telephone link `tel:+917355309230` | Pass |
| 18 | Booking: fallback request form when Calendly is not set (no slots shown); Calendly webhook signature check rejects bad and replayed signatures, accepts valid | Pass; live Calendly needs your account |
| 19 | Cookie banner: shows, "Necessary only", reopen from footer, accept | Pass; GA only loads after consent |
| 20 | SEO: unique titles/descriptions, canonical URLs, robots.txt, sitemap.xml, Open Graph image, JSON-LD | Pass |
| 21–23 | No horizontal scrolling and no console errors at 390px, 820px and 1440px on all 14 public page types | Pass |
| 24 | Error handling: invalid JSON/content type (415), cross-origin posts (403), too-fast submissions, honeypot, duplicate within 10 min (accepted once, not stored twice), rate limit (6th submission in an hour blocked), 404s for unknown pages and inactive services | Pass |
| 25 | Security permissions (RLS): anonymous users cannot read or insert leads, the leads view or the rate-limit log; non-staff users see zero leads and cannot write content; editors manage blog/portfolio/media but cannot read leads or change settings; owners can do everything; nobody can grant themselves admin; invalid lead statuses rejected | Pass |
