-- ============================================================================
-- Inboxora Digital — database schema, security policies and storage
-- Run once in Supabase: SQL Editor → paste → Run (or `supabase db push`).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Roles and helpers
-- ---------------------------------------------------------------------------
create table if not exists public.admin_users (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  email      text not null,
  role       text not null default 'admin' check (role in ('owner', 'admin', 'editor')),
  created_at timestamptz not null default now()
);

-- owner/admin: everything, including leads and settings. editor: blog and portfolio only.
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid() and role in ('owner', 'admin'));
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid());
$$;

revoke all on function public.is_admin() from public;
revoke all on function public.is_staff() from public;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.is_staff() to anon, authenticated;

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- Leads
-- ---------------------------------------------------------------------------
create table if not exists public.contacts (
  id                uuid primary key default gen_random_uuid(),
  name              text not null check (char_length(name) <= 100),
  email             text not null check (char_length(email) <= 254),
  company           text check (char_length(company) <= 150),
  website           text check (char_length(website) <= 300),
  country           text check (char_length(country) <= 80),
  service           text check (char_length(service) <= 120),
  budget            text check (char_length(budget) <= 40),
  message           text check (char_length(message) <= 5000),
  marketing_consent boolean not null default false,
  status            text not null default 'New'
                    check (status in ('New','Contacted','Discovery Call Scheduled','Proposal Sent','Negotiation','Won','Lost')),
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table if not exists public.audit_requests (
  id                     uuid primary key default gen_random_uuid(),
  name                   text not null check (char_length(name) <= 100),
  email                  text not null check (char_length(email) <= 254),
  company                text check (char_length(company) <= 150),
  website                text check (char_length(website) <= 300),
  country                text check (char_length(country) <= 80),
  industry               text check (char_length(industry) <= 80),
  email_platform         text check (char_length(email_platform) <= 80),
  subscriber_count       text check (char_length(subscriber_count) <= 40),
  marketing_challenge    text check (char_length(marketing_challenge) <= 2000),
  additional_information text check (char_length(additional_information) <= 4000),
  marketing_consent      boolean not null default false,
  status                 text not null default 'New'
                         check (status in ('New','Contacted','Discovery Call Scheduled','Proposal Sent','Negotiation','Won','Lost')),
  notes                  text,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

create table if not exists public.bookings (
  id                   uuid primary key default gen_random_uuid(),
  name                 text not null check (char_length(name) <= 100),
  email                text not null check (char_length(email) <= 254),
  company              text check (char_length(company) <= 150),
  website              text check (char_length(website) <= 300),
  scheduled_at         timestamptz,              -- confirmed time (Calendly); null for requests
  timezone             text check (char_length(timezone) <= 64),
  preferred_date       date,                     -- request-form fallback
  preferred_time       text check (char_length(preferred_time) <= 40),
  requirements         text check (char_length(requirements) <= 4000),
  meeting_status       text not null default 'requested'
                       check (meeting_status in ('requested','scheduled','completed','cancelled','no_show')),
  source               text not null default 'request_form' check (source in ('request_form','calendly')),
  calendly_event_uri   text unique,
  calendly_invitee_uri text,
  marketing_consent    boolean not null default false,
  status               text not null default 'New'
                       check (status in ('New','Contacted','Discovery Call Scheduled','Proposal Sent','Negotiation','Won','Lost')),
  notes                text,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);

create index if not exists contacts_created_idx on public.contacts (created_at desc);
create index if not exists contacts_email_idx on public.contacts (email, created_at desc);
create index if not exists audit_created_idx on public.audit_requests (created_at desc);
create index if not exists audit_email_idx on public.audit_requests (email, created_at desc);
create index if not exists bookings_created_idx on public.bookings (created_at desc);
create index if not exists bookings_email_idx on public.bookings (email, created_at desc);

-- Unified lead view for the admin dashboard. security_invoker = RLS of the caller applies.
create or replace view public.leads with (security_invoker = true) as
  select id, 'contact'::text as source, name, email, company, website, country,
         service, budget, message as details, status, notes, created_at
  from public.contacts
  union all
  select id, 'audit', name, email, company, website, country,
         'Free email audit (' || coalesce(email_platform, '?') || ')', null,
         concat_ws(E'\n\n', 'Industry: ' || industry, 'Subscribers: ' || subscriber_count,
                   'Challenge: ' || marketing_challenge, 'Additional: ' || additional_information),
         status, notes, created_at
  from public.audit_requests
  union all
  select id, 'booking', name, email, company, website, null,
         'Discovery call', null,
         concat_ws(E'\n\n',
           case when scheduled_at is not null then 'Scheduled: ' || to_char(scheduled_at at time zone 'UTC', 'YYYY-MM-DD HH24:MI') || ' UTC' end,
           case when preferred_date is not null then 'Requested: ' || preferred_date || ', ' || coalesce(preferred_time, '') end,
           'Time zone: ' || timezone, 'Meeting: ' || meeting_status, requirements),
         status, notes, created_at
  from public.bookings;

-- Rate limiting log (server-side only; holds hashed IPs, never raw IPs).
create table if not exists public.submission_log (
  id         bigint generated always as identity primary key,
  ip_hash    text not null,
  form       text not null,
  created_at timestamptz not null default now()
);
create index if not exists submission_log_lookup on public.submission_log (ip_hash, form, created_at desc);

create or replace function public.prune_submission_log() returns void
language sql security definer set search_path = public as $$
  delete from public.submission_log where created_at < now() - interval '2 days';
$$;
revoke all on function public.prune_submission_log() from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- Content
-- ---------------------------------------------------------------------------
create table if not exists public.portfolio_projects (
  id                 uuid primary key default gen_random_uuid(),
  slug               text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  brand_name         text not null,
  website            text,
  industry           text,
  country            text,
  description        text,
  services           text[] not null default '{}',
  categories         text[] not null default '{}',
  images             jsonb not null default '[]'::jsonb,   -- [{url, caption, category, concept}]
  verified_results   text,                                 -- only results you can verify
  case_study         jsonb not null default '{}'::jsonb,
  attribution        text not null default 'Selected Client Experience — Founder-Led Project Work',
  publication_status text not null default 'draft' check (publication_status in ('draft','published')),
  sort_order         int not null default 100,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists public.blog_categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  slug       text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  created_at timestamptz not null default now()
);

create table if not exists public.blog_posts (
  id                 uuid primary key default gen_random_uuid(),
  title              text not null,
  slug               text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  excerpt            text not null default '',
  content            text not null default '',
  category           text not null default 'Strategy',
  author             text not null default 'Inboxora Digital',
  featured           boolean not null default false,
  featured_image     text,
  seo_title          text,
  meta_description   text,
  publication_status text not null default 'draft' check (publication_status in ('draft','published')),
  published_at       timestamptz,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index if not exists blog_posts_pub_idx on public.blog_posts (publication_status, published_at desc);

create table if not exists public.site_settings (
  key        text primary key check (key in ('contact','social','stats','pricing','services','legal')),
  value      jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users (id) on delete set null
);

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array['contacts','audit_requests','bookings','portfolio_projects','blog_posts','site_settings'] loop
    execute format('drop trigger if exists %1$s_touch on public.%1$s', t);
    execute format('create trigger %1$s_touch before update on public.%1$s for each row execute function public.touch_updated_at()', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------
alter table public.admin_users        enable row level security;
alter table public.contacts           enable row level security;
alter table public.audit_requests     enable row level security;
alter table public.bookings           enable row level security;
alter table public.submission_log     enable row level security;
alter table public.portfolio_projects enable row level security;
alter table public.blog_categories    enable row level security;
alter table public.blog_posts         enable row level security;
alter table public.site_settings      enable row level security;

-- admin_users: a signed-in user can see their own row; admins see all. Changes only via SQL editor.
drop policy if exists admin_users_read on public.admin_users;
create policy admin_users_read on public.admin_users for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Leads: admins only. No INSERT policy — public submissions go through the server
-- (validated, rate-limited) using the service role, which bypasses RLS.
do $$
declare t text;
begin
  foreach t in array array['contacts','audit_requests','bookings'] loop
    execute format('drop policy if exists %1$s_admin_select on public.%1$s', t);
    execute format('drop policy if exists %1$s_admin_update on public.%1$s', t);
    execute format('drop policy if exists %1$s_admin_delete on public.%1$s', t);
    execute format('create policy %1$s_admin_select on public.%1$s for select to authenticated using (public.is_admin())', t);
    execute format('create policy %1$s_admin_update on public.%1$s for update to authenticated using (public.is_admin()) with check (public.is_admin())', t);
    execute format('create policy %1$s_admin_delete on public.%1$s for delete to authenticated using (public.is_admin())', t);
  end loop;
end $$;

-- submission_log: no policies at all → only the service role can read/write.

-- Portfolio: public sees published; staff manage everything.
drop policy if exists portfolio_public_read on public.portfolio_projects;
create policy portfolio_public_read on public.portfolio_projects for select to anon, authenticated
  using (publication_status = 'published' or public.is_staff());
drop policy if exists portfolio_staff_write on public.portfolio_projects;
create policy portfolio_staff_write on public.portfolio_projects for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- Blog
drop policy if exists blog_public_read on public.blog_posts;
create policy blog_public_read on public.blog_posts for select to anon, authenticated
  using ((publication_status = 'published' and published_at <= now()) or public.is_staff());
drop policy if exists blog_staff_write on public.blog_posts;
create policy blog_staff_write on public.blog_posts for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

drop policy if exists blog_cat_read on public.blog_categories;
create policy blog_cat_read on public.blog_categories for select to anon, authenticated using (true);
drop policy if exists blog_cat_write on public.blog_categories;
create policy blog_cat_write on public.blog_categories for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- Settings: public content (contact details, pricing, stats); admins edit.
drop policy if exists settings_read on public.site_settings;
create policy settings_read on public.site_settings for select to anon, authenticated using (true);
drop policy if exists settings_write on public.site_settings;
create policy settings_write on public.site_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Table privileges (RLS still applies on top of these)
revoke all on public.contacts, public.audit_requests, public.bookings, public.submission_log, public.admin_users from anon;
grant select, update, delete on public.contacts, public.audit_requests, public.bookings to authenticated;
grant select on public.leads to authenticated;
revoke all on public.leads from anon;

-- ---------------------------------------------------------------------------
-- Storage: public "media" bucket for portfolio screenshots and blog images
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 5242880, array['image/png','image/jpeg','image/webp','image/gif'])
on conflict (id) do update
  set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists media_public_read on storage.objects;
create policy media_public_read on storage.objects for select to anon, authenticated
  using (bucket_id = 'media');
drop policy if exists media_staff_insert on storage.objects;
create policy media_staff_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and public.is_staff());
drop policy if exists media_staff_update on storage.objects;
create policy media_staff_update on storage.objects for update to authenticated
  using (bucket_id = 'media' and public.is_staff());
drop policy if exists media_staff_delete on storage.objects;
create policy media_staff_delete on storage.objects for delete to authenticated
  using (bucket_id = 'media' and public.is_staff());
