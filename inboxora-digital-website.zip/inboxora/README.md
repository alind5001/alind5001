# Inboxora Digital website

Production website for Inboxora Digital, an e-commerce email marketing agency.
Next.js 15 (App Router, TypeScript, Tailwind CSS 4) · Supabase · Resend · Calendly · GA4 (consent-gated).

**Start here: [SETUP.md](SETUP.md)** — connecting Supabase, Resend, Calendly, Turnstile and GA4, and deploying to Vercel.
Test results: [TESTING.md](TESTING.md).

## What's included

**Public site**: Home · About · Services (+7 service pages) · Industries · Our Work (+6 case studies, filter, search,
lightbox) · Pricing · Free Email Audit · Contact · Book a Discovery Call · Insights (10 articles, categories, search,
featured, related, sharing) · Privacy, Terms and Cookie policies · sitemap, robots, Open Graph image, structured data.

**Admin** (`/admin`): overview from real data, lead management (search, filter, sort, status, notes, CSV export,
delete), portfolio manager with screenshot uploads, blog editor with Markdown preview and SEO fields, category
manager, and settings for contact details, social links, homepage statistics, pricing, services (including hidden
future services) and legal pages.

**Backend**: Postgres tables with Row Level Security, server-validated form APIs, spam protection (honeypot, timing,
Turnstile, per-IP rate limits, duplicate detection), Resend notifications, Calendly booking verification and signed
webhooks, secure image uploads.

## Project map

```
src/app/(site)/        public pages
src/app/admin/         admin dashboard, server actions, CSV export
src/app/api/           form endpoints and Calendly webhook
src/components/        UI, forms, portfolio, blog components
src/lib/content/       launch content: services, industries, case studies, articles, legal templates, defaults
src/lib/data.ts        public data access (database first, built-in content as fallback)
supabase/migrations/   schema, RLS and storage policies
supabase/seed.sql      launch content for the database (regenerate with `npm run seed:generate`)
```

## Commands

```bash
npm run dev         # local development
npm run build       # production build
npm run start       # serve the production build
npm run typecheck   # TypeScript check
npm run seed:generate   # rebuild supabase/seed.sql from src/lib/content
```

## Content principles built into the site

- Client brands are labelled "Selected Client Experience — Founder-Led Project Work", with no implied endorsement.
- The 20–25% figure always appears with its methodology disclosure.
- Previews without real screenshots are labelled "Concept design".
- No invented testimonials, metrics, availability slots, addresses or certifications.
